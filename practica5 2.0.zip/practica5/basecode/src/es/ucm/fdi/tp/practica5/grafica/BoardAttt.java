package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica5.attt.AdvancedTTTMove;
import es.ucm.fdi.tp.practica5.attt.AdvancedTTTRandomPlayer;
import es.ucm.fdi.tp.practica5.connectn.ConnectNMove;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;
import es.ucm.fdi.tp.practica5.ttt.TicTacToeRules;

public class BoardAttt extends BoardUI{
	private TicTacToeRules rules;
	private static AdvancedTTTMove movimiento;
	private int lastRow;
	private int lastCol;
	
	public BoardAttt(HashMap<Piece, Color> pc, HashMap<Piece, PlayerMode> pm,
			Controller2 c, StatusListener list, int windowIndex) {
		super(pc, pm, c, list, windowIndex);
		lastRow = -1;
		lastCol = -1;
	}

	public void deseleccionar(){
		lastRow = -1;
		lastCol = -1;
		list.selectOrigen();
	}
	
	@Override
	public void setRules(int dim, int numObs) {
		rules = new TicTacToeRules();
	}

	@Override
	public GameRules getRules() {
		return rules;
	}

	public void setMove(AdvancedTTTMove move){
		this.movimiento = move;
	}

	public static AdvancedTTTMove getMove(){
		return movimiento;
	}
	
	@Override
	public void cosasDeMover(int row, int col) {
	
		Piece p = board.getPosition(lastRow, lastCol);

		setMove(new AdvancedTTTMove (lastRow, lastCol, row, col, p)); //seteamos el movimiento que vamos a hacer.
		
		ManualPlayer player = new ManualPlayer(); //Creamos el jugador correspondiente al movimiento que vamos a hacer.
		c.makeMove(player, turno); //Llamamos a makeMove (esto va a hacer que game haga el movimiento que le devuelva el Player
											//Y el player le va a devolver el movimiento que hemos seteado.
		update(pc, pm);
		
	}

	@Override
	public boolean gameIsDone() {	
		return false;
	}

	@Override
	public void movimientoAleatorio() {
		AdvancedTTTRandomPlayer player = new AdvancedTTTRandomPlayer();
		c.makeMove(player, turno);
		update(pc, pm);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		List<GameMove> moves = rules.validMoves(board, pieces, turno);
		
		if(windowIndex == c.getWindowIndex()){
			list.selectOrigen();
		}
		
		if(pm.get(turno) == Main.PlayerMode.MANUAL){
		Square square = (Square) e.getSource();


			// Si es una lastRos/lastCol de verdad
			if (lastRow != -1) {
	
				// Si la pieza que se mueve no es obs/null.
				// Si la casilla a la que movemos no es de la que venimos
				// Si la casilla a la que vamos est?vac闊�
				// Si la casilla a la que vamos est锟� "cerca"
				if (moves.contains(movimiento) && (square.getRow() != lastRow || square.getCol() != lastCol)) {
	
					list.showDestination(square.getRow(), square.getCol());
					cosasDeMover(square.getRow(), square.getCol());
					
				} else {
					c.onError("Movimiento no permitido.");
					list.selectOrigen();
				}
	
				lastRow = -1;
				lastCol = -1;
	
				// Si no tenemos ninguna seleccionada y seleccionamos una ficha de
				// que es su turno
			} else if (lastRow == -1 && pieces.contains(board.getPosition(square.getRow(), square.getCol()))
					&& board.getPosition(square.getRow(), square.getCol()).equals(turno)) {
				
				lastRow = square.getRow();
				lastCol = square.getCol();
				list.selectDestiny(lastRow, lastCol);
			} else {
				c.onError("Seleccione una casilla de origen v閱爄da." + System.getProperty("line.separator"));
			}
		}else if(pm.get(turno) == Main.PlayerMode.RANDOM){
			movimientoAleatorio();
		}else if(pm.get(turno) == Main.PlayerMode.AI){
			movimientoAi();
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
