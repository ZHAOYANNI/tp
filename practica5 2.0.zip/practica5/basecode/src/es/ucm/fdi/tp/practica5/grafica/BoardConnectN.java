package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.HashMap;

import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica5.connectn.ConnectNMove;
import es.ucm.fdi.tp.practica5.connectn.ConnectNRandomPlayer;
import es.ucm.fdi.tp.practica5.connectn.ConnectNRules;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;

public class BoardConnectN extends BoardUI{
	private ConnectNRules rules;
	private static ConnectNMove movimiento;

	
	public BoardConnectN(HashMap<Piece, Color> pc,
			HashMap<Piece, PlayerMode> pm, Controller2 c, StatusListener list,
			int windowIndex) {
		super(pc, pm, c, list, windowIndex);

	}

	@Override
	public void setRules(int dim, int numObs) {
		ConnectNRules rules = new ConnectNRules(dim);
		this.rules = rules;	
	}

	@Override
	public GameRules getRules() {
		return rules;
	}
	public void setMove(ConnectNMove move){
		this.movimiento = move;
	}

	public static ConnectNMove getMove(){
		return movimiento;
	}
	@Override
	public void cosasDeMover(int row, int col) {
		setMove(new ConnectNMove (row, col, turno)); //seteamos el movimiento que vamos a hacer.
		
		ManualPlayer player = new ManualPlayer(); //Creamos el jugador correspondiente al movimiento que vamos a hacer.
		c.makeMove(player, turno); //Llamamos a makeMove (esto va a hacer que game haga el movimiento que le devuelva el Player
									//Y el player le va a devolver el movimiento que hemos seteado.
		update(pc, pm);
	}

	@Override
	public boolean gameIsDone() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void movimientoAleatorio() {
		ConnectNRandomPlayer player = new ConnectNRandomPlayer();
		c.makeMove(player, turno);
		update(pc,pm);
	}

	@Override
	public void mouseClicked(MouseEvent e) {

		if(windowIndex == c.getWindowIndex()){
			
			if(pm.get(turno) == Main.PlayerMode.MANUAL){
				Square square = (Square) e.getSource();
				if (board.getPosition(square.getRow(), square.getCol()) == null) {
					list.showDestination(square.getRow(), square.getCol());
					cosasDeMover(square.getRow(), square.getCol());
				} else {
					c.onError("Movimiento no permitido.");
					list.selectOrigen();
				}
			}else if(pm.get(turno) == Main.PlayerMode.RANDOM){
				movimientoAleatorio();
			}else if(pm.get(turno) == Main.PlayerMode.AI){
				movimientoAi();
			}
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
