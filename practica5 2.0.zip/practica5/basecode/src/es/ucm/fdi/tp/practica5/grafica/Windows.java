package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;
import javax.swing.plaf.PanelUI;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Windows extends JFrame implements PanelDer.SettingListener, BoardUI.StatusListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4192014945426749947L;
	protected BoardUI ui;
	protected PanelDer der;
	private StatusPanel status;
	protected PlayerInfor playerInfor;
	private List<Piece> pieces;
	private HashMap<Piece, Color> pc;
	protected HashMap<Piece, Main.PlayerMode> pm;
	private Board boardPlz;
	private Controller2 c;
	private int dim;
	private int numObs;
	private boolean hasRandom;
	private boolean hasAi;
	protected Piece viewPiece;
	private String gameDesc;
	private int i;
	private int windowIndex;
	private boolean primer;
	private boolean enMovimiento;
	
	public Windows(Controller c, Piece viewPiece, List<Piece> pieces, int dim, int numObs,
			boolean hasRandom, boolean hasAi, String gameDesc) {
		pc = new HashMap();
		pm = new HashMap();
		
		if(viewPiece != null){
			StringBuilder sb = new StringBuilder(gameDesc);
			for(int x = gameDesc.length()-1; x > gameDesc.length()-4; x--){
				sb.deleteCharAt(x);
			}
			
			gameDesc = sb.toString();
		}
		
		if(viewPiece == null){
			this.windowIndex = 0;
		} else{
			this.windowIndex = pieces.indexOf(viewPiece);
		}
		
		this.dim = dim;
		this.numObs = numObs;
		this.hasRandom = hasRandom;
		this.hasAi = hasAi;
		this.viewPiece = viewPiece;
		this.gameDesc = gameDesc;
		this.c = (Controller2) c;
		
		enMovimiento = false;
		primer = true;
		i = -1;
		for (int i = 0; i < pieces.size(); i++) {
			pc.put(pieces.get(i), new Color((int)(Math.random() * 0x1000000)));
		}
		for (int i = 0; i < pieces.size(); i++) {
			pm.put(pieces.get(i), Main.PlayerMode.MANUAL);
		}
		boardPlz = ((Controller2)c).getBoard();//Este es el tablero que cojo de Controller2 y que es el bueno.

		
		ui = new BoardAtaxx(pc, pm, (Controller2) c, this, windowIndex);
		this.pieces = pieces;
		ui.setRules(dim, numObs);
		ui.setPieces(pieces);
		
		playerInfor = new PlayerInfor(pieces, pm, pc, boardPlz);
		status = new StatusPanel();
		gameStart(gameDesc);
		der = new PanelDer(this, pc, pm, hasRandom, hasAi);
		ui.setBoard(boardPlz);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		if(viewPiece != null)
			der.initComponents((Controller2)c, viewPiece, pieces, this, viewPiece);
		else 
			der.initComponents((Controller2)c, viewPiece, pieces, this, pieces.get(0));
		add(der, BorderLayout.EAST);

	}
	
	public void newBoard(List<Piece> pieces, Board board){
	
		ui.setTurno(pieces.get(0));
		ui.setPieces(pieces);
		ui.setBoard(board);

		repaint();
	}

	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		status.append("Bienvenido a " + gameDesc + System.getProperty("line.separator"));
	}

	public void onGameOver(Board board, State state, Piece winner) {
		
		if (state == Game.State.Won) {
			c.onInfo(winner + " is the winner!");
		} else if (state == Game.State.Draw) {
			status.append("empate");
			c.onInfo("The game ended in a draw");
		} else if (state == Game.State.Stopped) {
			c.onInfo("The game was ended");
		}
	}

	public void ColorChangeChoose(Piece p, Color c) {
		this.pc.put(p, c);
		actualiza(p);
	}

	public void PlayerModeChange(Piece p, PlayerMode m) {
		if(!primer){
			int index = 0;
			if(p != null)
				index = pieces.indexOf(p);
			if ((viewPiece == null) || (viewPiece != null && index == windowIndex)){
					if(m == Main.PlayerMode.RANDOM){
						this.pm.put(pieces.get(index), Main.PlayerMode.RANDOM);
					
			   	 	}else if(m == Main.PlayerMode.AI){
			   	 		this.pm.put(pieces.get(index), Main.PlayerMode.AI);
			   	 	}else
			   	 		this.pm.put(pieces.get(index), Main.PlayerMode.MANUAL);
				c.changePM();
				actualiza(p);
				((BoardAtaxx) ui).deseleccionar();	
			}else{
				status.append("Error, no se puede modificar el modo de otro jugador. ");
			}	
		}else {
			status.append("Error, no se puede modificar el modo en primer turno.");
		}
	}
	
	public PlayerMode getMode(Piece p){
		return pm.get(p);
	}

	public void AIMoveChoose(Piece p) {
		if(!enMovimiento){
			if(p.equals(ui.getTurno()))
				ui.movimientoAi();
			else 
				status.append("Error. No se puede hacer un movimiento inteligente si no es tu turno. ");
		}else
			status.append("Error. No se puede hacer un movimiento inteligente durante la ejecuci��n de un "
					+ "movimiento. ");
	}

	public void RandomMoveChoose(Piece p) {
		if(!enMovimiento){
			if(p.equals(ui.getTurno()))
				ui.movimientoAleatorio();
			else 
				status.append("Error. No se puede hacer un movimiento aleatorio si no es tu turno.");
		}else
			status.append("Error. No se puede hacer un movimiento aleatorio durante la ejecuci��n de un "
					+ "movimiento. ");
	}

	public void actualiza(Piece turn) {
			der.actualiza(pm, turn);
			playerInfor.actualiza();
			ui.update(pc, pm);
	}
	
	public void updateBoard(){
		ui.update(pc, pm);
	}

	public void gameStart(String gameDesc){
		status.append("Bienvenido a " + gameDesc);
	}
	
	public void changePm(HashMap<Piece,Main.PlayerMode> pm){
		this.pm.putAll(pm);
	}
	
	@Override
	public void changeTurn(Piece p) {
		if(p != null){
			if(viewPiece != null){
				if(windowIndex != c.getWindowIndex()){
					status.append("Turn of " + p);
				} else{
					status.append("Turn of " + p + " (YOU)");
				}
			} else{
				status.append("Turn of " + p);
			}
			i++;
			if(i == pieces.size()){
				primer = false;
			}
		}
	}

	@Override
	public void selectOrigen() {
		status.append("Click on an origin piece.");
	}
	@Override
	public void selectDestiny(int i, int j) {
		status.append("You have selected (" + i + ", " + j + ") as your origin piece.");
		enMovimiento = true;
		status.append("Click on the destination position. ");
	}
	@Override
	public void showDestination(int i, int j){
		status.append("You have selected (" + i + ", " + j + ") as your destination piece.");
		enMovimiento = false;
	}
	
}
