package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

public class AutomaticMove extends JPanel {
	private JButton AI;
	private JButton btnRandom;
	public AutomaticMove(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Automatic Moves", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	public void initComponent(HashMap<Piece, Main.PlayerMode> pm, SettingListener list, Piece p,
			boolean hasRandom, boolean hasAi){
		if(hasAi){
			AI = new JButton("Intelligent");
			AI.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					list.AIMoveChoose(p);
				}
			});
			add(AI);
		}
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		if(hasRandom){
			btnRandom = new JButton("Random");
			btnRandom.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					list.RandomMoveChoose(p);
				}
			});
			add(btnRandom);
			
		}
	}
	
	public void actualiza(HashMap<Piece, Main.PlayerMode> pm, Piece turn, boolean hasRandom, boolean hasAi){
		if(hasAi && hasRandom){
			if(pm.get(turn)!=Main.PlayerMode.MANUAL){
				AI.setEnabled(false);
				btnRandom.setEnabled(false);
			}else{
				AI.setEnabled(true);
				btnRandom.setEnabled(true);
			}
		}else if(hasRandom && !hasAi){
			if(pm.get(turn)!=Main.PlayerMode.MANUAL){
				btnRandom.setEnabled(false);
			}else{
				btnRandom.setEnabled(true);
			}
		}else if (!hasRandom && hasAi){
			if(pm.get(turn)!=Main.PlayerMode.MANUAL){
				AI.setEnabled(false);
			}else{
				AI.setEnabled(true);
			}
		}
	}
}