package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PlayerMode extends JPanel{

	public PlayerMode(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Player Modes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
	
	public void setBoton(){
		
		JComboBox Piece = new JComboBox();
		Piece.setModel(new DefaultComboBoxModel(new String[] {"O", "X", "B", "T"}));
		add(Piece);
		
		JComboBox Modo = new JComboBox();
		Modo.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Random", "Intelligent"}));
		add(Modo);
		
		JButton btnSet = new JButton("Set");
		add(btnSet);
	}
}
