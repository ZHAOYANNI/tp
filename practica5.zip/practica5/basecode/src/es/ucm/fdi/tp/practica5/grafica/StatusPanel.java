package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class StatusPanel extends JPanel{

	public StatusPanel(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Status Menssages", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
	}
	
	public void setText(){
		JTextArea txtrPrueba = new JTextArea();
		txtrPrueba.setEditable(false);
		add(new JScrollPane(txtrPrueba), BorderLayout.CENTER);
	}
}
