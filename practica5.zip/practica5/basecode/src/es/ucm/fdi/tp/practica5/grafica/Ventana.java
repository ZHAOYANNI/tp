package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JToolBar;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JSpinner;

import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JDesktopPane;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.border.TitledBorder;
import javax.swing.DefaultComboBoxModel;

import java.awt.CardLayout;
import java.awt.Component;

import javax.swing.table.DefaultTableModel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.*;
public class Ventana extends JFrame {

	private JPanel contentPane;
	private statusPanel status;
	private player player;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setTitle(" ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 370);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel tablero = new JPanel();
		contentPane.add(tablero);
		BoardUI tablas = new BoardAtaxx();
		tablero.add(tablas);

		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.EAST);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		status = new statusPanel();
		panel.add(status);
		status.setTit();
		JTextArea txtrPrueba = new JTextArea();
		txtrPrueba.setEditable(false);
		status.add(new JScrollPane(txtrPrueba), BorderLayout.CENTER);
		
		
		player = new player();
		panel.add(player);
		player.setTit();
		
		
		JTable table= new JTable();
		table.setBackground(Color.WHITE);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Player", "Mode", "#Piece"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		player.add(new JScrollPane(table));
		
		JPanel Piece_color = new JPanel();
		panel.add(Piece_color);
		Piece_color.setBorder(new TitledBorder(null, "Piece Colors", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"O", "X", "B", "T"}));
		Piece_color.add(comboBox);
		
		JButton btnChoose = new JButton("Choose Color");
		Piece_color.add(btnChoose);
		
		JPanel player_modes = new JPanel();
		panel.add(player_modes);
		player_modes.setBorder(new TitledBorder(null, "Player Modes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		player_modes.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JComboBox Piece = new JComboBox();
		Piece.setModel(new DefaultComboBoxModel(new String[] {"O", "X", "B", "T"}));
		player_modes.add(Piece);
		
		JComboBox Modo = new JComboBox();
		Modo.setModel(new DefaultComboBoxModel(new String[] {"Manual", "Random", "Intelligent"}));
		player_modes.add(Modo);
		
		JButton btnSet = new JButton("Set");
		player_modes.add(btnSet);
		
		JPanel automatic_moves = new JPanel();
		panel.add(automatic_moves);
		automatic_moves.setBorder(new TitledBorder(null, "Automatic Moves", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JButton btnNewButton_1 = new JButton("Intelligent");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		automatic_moves.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnRandom = new JButton("Random");
		automatic_moves.add(btnRandom);
		automatic_moves.add(btnNewButton_1);
		
		JPanel Salir = new JPanel();
		panel.add(Salir);
		
		JButton btnQuit = new JButton("Quit");
		Salir.add(btnQuit);
		
		JButton btnRes = new JButton("Restart");
		Salir.add(btnRes);
	}
}
