package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class PlayerInfor extends JPanel{

	public PlayerInfor(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Player Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
	}
	
	public void setTable(){
		JTable table= new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"Player", "Mode", "#Piece"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		add(new JScrollPane(table));
	}
}
