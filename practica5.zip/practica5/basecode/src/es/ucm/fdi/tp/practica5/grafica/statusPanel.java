package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class statusPanel extends JPanel{

	public statusPanel(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Status Menssages", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
	}
	
}
