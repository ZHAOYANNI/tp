package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class BoardUI extends JPanel implements MouseListener{
	private JLabel[][] squares;
	private Board board;
	private List<Piece> pieces;
	private int lastRow; //Guarda ��ltima fila clicada
	private int lastCol; //Guarda ��ltima columna clicada
	//private Piece lastPiece;//Guarda ��ltima pieza clicada
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendr��a los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardUI(){
		lastRow = -1;
		lastCol = -1;
		//lastPiece = null;
		pieces = new ArrayList();
	}
	
	public void setPieces(List<Piece> pieces){
		
		
		
	}
	
	public void setPiecesAux(){
		Piece o = new Piece("O");
		pieces.add(o);
		Piece x = new Piece("X");
		pieces.add(x);
	}
	
	public void llenarBoardAux(Board board){//Lleno el tablero con las piezas que me sale del rabo para probar cosas
		Piece obs = new Piece("OBS");
		
		for(int i = 0; i < board.getRows(); i++){
			for(int j = 0; j < board.getCols(); j++){
				if(i+j == 2){
					board.setPosition(i, j, pieces.get(0));
				} else if(i+j == 5){
					board.setPosition(i, j, pieces.get(1));
				} else if(i == 2 && j == 2){
					board.setPosition(i, j, obs);
				} else {
					board.setPosition(i, j, null);
				}
			}
		}
	}
	
	public void setBoard(Board board){
		
		if(board != this.board){
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
				for (int i=0; i<board.getRows(); i++) {
					for (int j=0; j<board.getCols(); j++) {
						squares[i][j] = new Square(i,j);
						squares[i][j].addMouseListener(this);
						paintSquare(board.getPosition(i, j), i, j);
						/*if((i + j) % 2 == 0){
							squares[i][j].setBackground(Color.BLACK);//Meramente para guiarme m�s f�cilmente a la hora de hacer pruebas
							//squares[i][j].setOpaque(true);
						} else if(i + j == 3){
							squares[i][j].setBackground(Color.RED);
							//squares[i][j].setOpaque(true);
						}*/
						add(squares[i][j]);
					}
				}
		} else{
			update();
		}
	}

	public void setColors(PieceColorMap colorMap){};
	
	public void update(){//Queda ver en qu?momentos se llama a esto dentro del programa.
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}
	
	//De esta queda bastante, entre otras cosas que el color se pueda cambiar
	public void paintSquare(Piece p, int i, int j){

		Piece obs = new Piece("OBS");
		
		if(pieces.get(0).equals(p)){
			squares[i][j].setBackground(Color.RED);
		} else if(pieces.get(1).equals(p)){
			squares[i][j].setBackground(Color.BLUE);
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else {//Si es una casilla vac��a
			squares[i][j].setBackground(Color.PINK);
		}
		
		squares[i][j].setOpaque(true);
		
	}
	
	public int abs(int num){
		if(num >= 0){
			return num;
		}
		return -num;
	}
	
	public void cosasDeMover(int row, int col){//Voy a necesitar saber a d�nde me muevo (s?de d�nde vengo por lastRow, lastCol)
		
		//(board.getPosition(lastRow, lastCol) != null){
			Piece p = board.getPosition(lastRow, lastCol);
			board.setPosition(row, col, p);
			//squares[row][col].setBackground(Color.RED);
			
			if(abs(row-lastRow) > 1 || abs(col-lastCol) > 1){//Si se ha movido dos casillas
				//squares[lastRow][lastCol].setBackground(Color.WHITE);
				board.setPosition(lastRow, lastCol, null);
			}
			
			//Aqu?va a ir el c��digo que usar?para convertir las de alrededor
			convertirAdyacentes(row, col);
			
			update();
	}
	
	//��sta es la funci��n que va a convertir las piezas adyacentes a la que est?en (row, col)
	public void convertirAdyacentes(int row, int col){
		
		Piece obs = new Piece("OBS");
		
		
		for(int i = -1; i < 2; i++){
			for(int j = -1; j < 2; j++){
				if(row+i >= 0 && row+i < board.getRows() && col+j >= 0 && col+j < board.getCols()){
					if(board.getPosition(row+i, col+j) != null && !obs.equals(board.getPosition(row+i, col+j))
							/*&& board.getPosition(row, col).equals(board.getPosition(row+i, col+j))*/){
						board.setPosition(row+i, col+j, board.getPosition(row, col));
					}
				}
			}
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		Piece obs = new Piece("OBS");
		Square square = (Square)e.getSource();
		square.squareWasClicked(square.getRow(), square.getCol());
		System.out.println(board.getPosition(square.getRow(), square.getCol()));
		
		//Si es una lastRos/lastCol de verdad
		if(lastRow != -1){
			
			//Si la pieza que se mueve no es obs/null.
			//Si la casilla a la que movemos no es de la que venimos
			//Si la casilla a la que vamos est?vac�a
			if(pieces.contains(board.getPosition(lastRow, lastCol)) && (square.getRow() != lastRow || square.getCol() != lastCol)
					&& board.getPosition(square.getRow(), square.getCol()) == null){
				
				//si la segunda casilla clicada est?"cerca" de la primera
				if(abs(lastRow-square.getRow()) <= 2 && abs(lastCol-square.getCol()) <= 2){
					cosasDeMover(square.getRow(), square.getCol());
				} else { //En caso de que no ponemos como �ltima seleccionada a "ninguna"
					//Tocar?poner un dialog box de movimiento no permitido
				}
			
			}
			
			lastRow = -1;
			lastCol = -1;
			
		} else{
			lastRow = square.getRow();
			lastCol = square.getCol();
		}
			
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}

/*
 * Voy a crear una lista de piezas. Asignar a distintas piezas del tablero estas piezas y probar a ver si pinta las cosas
 * distinto en funci��n de la pieza en la casilla y si las mueve bien.
 * 
 * 
 * Toca implementar turnos y tal.
 * Toca hacer m�s claro qu?est?seleccionado y hacer m�s intuitivo el proceso de selecci�n/deselecci�n
 */
