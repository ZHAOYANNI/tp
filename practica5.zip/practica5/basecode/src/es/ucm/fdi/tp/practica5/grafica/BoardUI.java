package es.ucm.fdi.tp.practica5.grafica;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public abstract class BoardUI extends JPanel{
	private JLabel[][] squares;
	private Board board;
	
	public BoardUI(){
		
	}
	
	public void setBoard(Board board){
		removeAll(); // descartamos squares antiguos
		this.board = board;
		squares = new JLabel[board.getRows()][board.getCols()];
		setLayout(new GridLayout(board.getRows(), board.getCols()));
			for (int i=0; i<board.getRows(); i++) {
				for (int j=0; j<board.getCols(); j++) {
					squares[i][j] = new Square(i,j);
				}
			}
	}

	public void setColors(PieceColorMap colorMap){};
	
	public void update(){
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
			// y aqu�� configuras squares[i][j] para que pinte algo que represente 'p'
			}
		}
		repaint();
	}
}
