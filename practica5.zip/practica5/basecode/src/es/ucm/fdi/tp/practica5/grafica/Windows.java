package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

import java.awt.*;
import java.util.List;


public class Windows extends JPanel implements GameObserver{

	private BoardUI ui;
	private PanelDer der;
	private StatusPanel status;
	private PlayerInfor playerInfor;

	public Windows(Controller c,Piece viewPiece,List<Piece> pieces) {
		playerInfor = new PlayerInfor(pieces);
		status = new StatusPanel();
		ui = new BoardAtaxx();
		der = new PanelDer();
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		der.initComponents(this,c, viewPiece, pieces);
		add(der, BorderLayout.EAST);
		

		Board board = new FiniteRectBoard(5,5);
		ui.setPiecesAux();
		ui.llenarBoardAux(board);
		ui.setBoard(board);
	}
	
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces,
			Piece turn) {
		status.append("bienvenido a " + gameDesc+ System.getProperty("line.separator"));
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		ui.update();
		status.append("ha ganado " + winner+ System.getProperty("line.separator"));
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		ui.update();
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		ui.update();
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		ui.update();
		status.append("turno de" + turn+ System.getProperty("line.separator"));
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	};
	
	
}
