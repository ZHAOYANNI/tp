package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

import java.awt.*;


public class Windows extends JPanel {

	private BoardUI ui;
	private PanelDer der;
	public Windows(Controller c,Piece viewPiece) {
		ui = new BoardAtaxx();
		der = new PanelDer(c,viewPiece);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		add(der, BorderLayout.EAST);
		Board board = new FiniteRectBoard(5,5);
		ui.setBoard(board);
	}
}
