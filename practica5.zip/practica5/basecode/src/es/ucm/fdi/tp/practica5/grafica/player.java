package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class player extends JPanel{

	public player(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Player Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout(0, 0));
	}
}
