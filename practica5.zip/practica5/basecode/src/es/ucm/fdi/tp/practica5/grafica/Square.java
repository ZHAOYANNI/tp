package es.ucm.fdi.tp.practica5.grafica;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

public class Square extends JLabel{
	private int row, col;
	
	public Square(int row, int col) {
		this.row = row;
		this.col = col;
		addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				squareWasClicked(Square.this.row, Square.this.col);
			}
		});
	}
	
	private void squareWasClicked(int row, int col){
		
		
	}
}
