package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                JFrame jf = new JFrame();
	                jf.setTitle("Ataxx 3x3" );
	                jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	                jf.add(new Windows(null, null));
	                jf.setSize(600, 400);
	                jf.setVisible(true);
	            }
	        });
	}

}
