package es.ucm.fdi.tp.practica5.grafica;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Salir extends JPanel {

	public Salir(){
		
	}
	
	public void setBoton(GameObserver g, Controller c,Piece viewPiece){
		JButton btnQuit = new JButton("Quit");
		add(btnQuit);
		 btnQuit.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	g.onError("Are you sure?");
		    	}
		   	});
		 
		if(viewPiece == null){
			JButton btnRes = new JButton("Restart");
			add(btnRes);
			 btnRes.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	c.restart();
		    	}
		   	});
		}
	}
}
