package es.ucm.fdi.tp.practica5.grafica;

public class BoardAtaxx extends BoardUI{

}
