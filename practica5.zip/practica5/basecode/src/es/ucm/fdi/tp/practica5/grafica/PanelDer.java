package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;


public class PanelDer extends JPanel {
	
	private StatusPanel status;
	private PlayerInfor player;
	private PieceColor pieceColor;
	private PlayerMode playerMode;
	private AutomaticMove move;
	private Salir salir;
	
	  public PanelDer(Controller c, Piece viewPiece) {
	        initComponents(c,viewPiece);
	    }
	  
	  public void initComponents(Controller c, Piece viewPiece){
		player = new PlayerInfor();
		status = new StatusPanel();
		pieceColor = new PieceColor();
		playerMode = new PlayerMode();
		move = new AutomaticMove();
		salir = new Salir();
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.add(status);
		status.setTit();
		/*JTextArea txtrPrueba = new JTextArea();
		txtrPrueba.setEditable(false);
		status.add(new JScrollPane(txtrPrueba), BorderLayout.CENTER);*/
		status.setText();
		
		panel.add(player);
		player.setTit();
		player.setTable();
		
		panel.add(pieceColor);
		pieceColor.setTit();
		pieceColor.setBoton();
		
		panel.add(playerMode);
		playerMode.setTit();
		playerMode.setBoton();
		
		
		panel.add(move);
		move.setTit();
		move.setBoton();
		
		
		panel.add(salir);
		salir.setBoton(c,viewPiece);
		
		add(panel);
		
	}
}
