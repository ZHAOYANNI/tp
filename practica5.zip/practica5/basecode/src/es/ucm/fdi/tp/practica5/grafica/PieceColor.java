package es.ucm.fdi.tp.practica5.grafica;

import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class PieceColor extends JPanel {
	
	public PieceColor(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Piece Colors", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	public void setBoton(List<Piece> pieces){
		Vector<Piece> v = new Vector(); 
		for(int i =0; i < pieces.size();i++){
			v.add(pieces.get(i));
		}
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(v));
		add(comboBox);
		
		JButton btnChoose = new JButton("Choose Color");
		add(btnChoose);
	}
}
