package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PieceColor extends JPanel {
	
	public PieceColor(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Piece Colors", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	public void setBoton(){
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"O", "X", "B", "T"}));
		add(comboBox);
		
		JButton btnChoose = new JButton("Choose Color");
		add(btnChoose);
	}
}
