package es.ucm.fdi.tp.practica6.net;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.control.commands.Command;
import es.ucm.fdi.tp.basecode.bgame.control.commands.PlayCommand;
import es.ucm.fdi.tp.basecode.bgame.control.commands.QuitCommand;
import es.ucm.fdi.tp.basecode.bgame.control.commands.RestartCommand;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica6.responses.Response;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Client extends Controller implements Observable<GameObserver>{
	private static final Logger log = Logger.getLogger(Server.class.getSimpleName());
	private String host;
	private int port;
	private List<GameObserver> observers;
	private Piece localPiece;
	private GameFactory gameFactory;
	private Connection connectionToServer;
	private boolean gameOver;
	
	
	public Client(String host, int port) throws Exception{
		super(null, null);
		this.host = host;
		this.port = port;
		this.observers = new ArrayList<GameObserver>();
		connect();
	}
	
	public GameFactory getGameFactory(){
		return gameFactory;
	}
	
	public Piece getPlayerPiece(){
		return localPiece;
	}
	
	public void addObserver(GameObserver o){
		observers.add(o);
	}
	
	public void removeObserver(GameObserver o){
		int i = observers.indexOf(o);
		observers.remove(i);
	}
	
	@Override
	public void makeMove(Player p){
		forwardCommand(new PlayCommand(p));
	}
	
	@Override
	public void stop(){
		forwardCommand(new QuitCommand());
	}
	
	@Override
	public void restart(){
		forwardCommand(new RestartCommand());
	}
	
	private void forwardCommand(Command cmd){
		if(!gameOver){
			try{
			connectionToServer.sendObject(cmd);
			} catch(IOException e){
				log.severe("Error.");
			}//Send cmd to the server
		}
	}
	
	private void connect() throws Exception{
		connectionToServer = new Connection(new Socket(host, port));
		connectionToServer.sendObject("Connect");
		
		Object response = connectionToServer.getObject(); //Leer el primer objeto en la respuesta del servidor.
							  //Si es un Exception en ontces la lanzamos.
							  //En ese caso el serer ha rechazado la petici�?.
		if(response instanceof Exception){
			throw (Exception)response;
		}
		
		try{
			gameFactory = (GameFactory) connectionToServer.getObject();//Estas cosas las cogemos del object que nos manda el server
			localPiece = (Piece) connectionToServer.getObject();
		} catch(Exception e){
			throw new GameError("Unknown server response " + e.getMessage());
		}
	}
	
	public void start(){
		this.observers.add(new GameOver());//Creamos una instancia an髇ima de GameObserver
								//y reg韘trala como observador en GameCLient.
								//Esta instancia tiene que cambiar gameOver a true
								//y cerrar la conexi�? con el servidor en su m閠odo
								//onGameOver(). As�? podemos salir del bucle al acabar el juego
		gameOver = false;
		while(!gameOver){
			try{
				Response r = (Response) connectionToServer.getObject(); //Read a response

				for(GameObserver o: observers){
					//Execute the response on the observer o
					r.run(o);
				}
			}catch(ClassNotFoundException | IOException e){
				
			}
		}
	}
	
	private class GameOver implements GameObserver{

		@Override
		public void onGameStart(Board board, String gameDesc,
				List<Piece> pieces, Piece turn) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onGameOver(Board board, State state, Piece winner) {
			gameOver = true;
			try{
				connectionToServer.stop();
			}catch(IOException e){
				log.severe("Error.");
			}
			
		}

		@Override
		public void onMoveStart(Board board, Piece turn) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onMoveEnd(Board board, Piece turn, boolean success) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onChangeTurn(Board board, Piece turn) {
			// TODO Auto-generated method stub
	
		}

		@Override
		public void onError(String msg) {
			// TODO Auto-generated method stub
			
		}
		
	}
	

}

/*
 * Les llega bien a los clientes el tablero cada vez que el servidor se lo manda pero no lo actualizan. 
 * No deja hacer el segundo tipo de movimiento (cuando tienes que mover una ficha de un sitio a otro)
 * Una vez hemos hecho un movimiento si cambias el tablero de tama�o se representa mal y se atasca el juego
 */
