package es.ucm.fdi.tp.practica6.grafica;

import es.ucm.fdi.tp.basecode.attt.AdvancedTTTMove;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class AtttGraphicalPlayer extends BoardUI.GraphicalPlayer {
	private int lastRow = -1;
	private int lastCol = -1;
	private int contPiece = 0;

	public void deseleccionar(){
		lastRow = -1;
		lastCol = -1;
	}
	@Override
	public void clickedInCell(int row, int col, Piece turn, Piece clicked) {

		if(contPiece <= 3){ 
			move = new AdvancedTTTMove(lastRow, lastCol, row, col, turn);
			contPiece+=1;
		} else {
			if (lastRow != -1) {
					// Si la pieza que se mueve no es obs/null.
				// Si la casilla a la que movemos no es de la que venimos
				// Si la casilla a la que vamos est?vac闊�
				// Si la casilla a la que vamos est锟� "cerca"
				if (row != lastRow || col != lastCol) {
					move = new AdvancedTTTMove(lastRow, lastCol, row, col, turn);
					lastRow = -1;
					lastCol = -1;
				} 
	
				// Si no tenemos ninguna seleccionada y seleccionamos una ficha de
				// que es su turno
			} else if (lastRow == -1 || clicked.equals(turn)) {
				lastRow = row;
				lastCol = col;
			}
		}
	}
}
