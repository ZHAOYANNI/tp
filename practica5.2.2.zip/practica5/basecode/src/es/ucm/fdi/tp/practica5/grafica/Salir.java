package es.ucm.fdi.tp.practica5.grafica;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Salir extends JPanel {

	private JButton btnQuit;
	private JButton btnRes;
	private Controller c;
	
	public void initComponent(Controller c,Piece viewPiece, Piece turn, 
			HashMap<Piece, Main.PlayerMode> pm){
		this.c = c;
		btnQuit = new JButton("Quit");
		add(btnQuit);
		 btnQuit.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	 
		    	int n = JOptionPane.showConfirmDialog(null, "Are you sure?", "Quit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    	
		    	if(n == 0){
		    		c.stop();
		    		System.exit(0);
		    	}
		    	}
		   	});
		 
		if(viewPiece == null){
			btnRes = new JButton("Restart");
			add(btnRes);
			 btnRes.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	c.restart();
		    	}
		   	});
				if(pm.get(turn) !=(Main.PlayerMode.MANUAL)){
					btnRes.setEnabled(false);
				}
		}
	}
	
	public void actualiza(HashMap<Piece, Main.PlayerMode> pm, Piece turn,Piece viewPiece){
		btnRes.setEnabled(
				viewPiece == null && pm.get(turn).equals(Main.PlayerMode.MANUAL));
	}
}
