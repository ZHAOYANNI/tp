package es.ucm.fdi.tp.practica5.ataxx;

public class AtaxxFactoryExt extends AtaxxFactory {

}
