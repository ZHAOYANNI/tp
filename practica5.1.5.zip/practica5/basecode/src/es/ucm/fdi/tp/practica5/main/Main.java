package es.ucm.fdi.tp.practica5.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Windows;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                JFrame jf = new JFrame();
	                jf.setTitle("Ataxx 3x3" );
	                jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	                List<Piece> pieces = new ArrayList();
	                pieces.add(new Piece ("X"));
	                pieces.add(new Piece ("O"));
	                pieces.add(new Piece ("P"));
	                jf.add(new Windows(null, null,pieces, 5, 2, pieces.get(0), true, false));
	                jf.setSize(600, 400);
	                jf.setVisible(true);
	            }
	        });
	}

}
