package es.ucm.fdi.tp.practica5.ttt;

import es.ucm.fdi.tp.practica5.connectn.ConnectNFactoryExt;

public class TicTacToeFactoryExt extends ConnectNFactoryExt {

}
