package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public class BoardAtaxx extends BoardUI{
	
	private int lastRow; //Guarda última fila clicada
	private int lastCol; //Guarda última columna clicada
	private AtaxxMove movimiento;
	private AtaxxRules rules;
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendría los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardAtaxx(HashMap<Piece, Color>pc, HashMap<Piece,Main.PlayerMode>pm){
		super(pc, pm);
		lastRow = -1;
		lastCol = -1;
	}
	
	public void setRules(int dim, int numObs){
		AtaxxRules rules = new AtaxxRules(dim, numObs);
		this.rules = rules;
	}
	
	public AtaxxRules getRules(){
		return rules;
	}
	
	private int abs(int num){
		if(num >= 0){
			return num;
		}
		return -num;
	}
	
	public void cosasDeMover(int row, int col){//Voy a necesitar saber a d髇de me muevo (s?de d髇de vengo por lastRow, lastCol)
			Piece p = board.getPosition(lastRow, lastCol);
			movimiento = new AtaxxMove(lastRow, lastCol, row, col, p);
			movimiento.execute(board, pieces);
			
			update(pc,pm);
	}
	
	//ésta es la función que va a convertir las piezas adyacentes a la que est?en (row, col)
	
	public void turnoSiguiente() {
		Piece p = rules.nextPlayer(board, pieces, turno);
		turno = p;
		
		/*status.append("Es el turno de " + p + System.getProperty("line.separator"));
		status.append("Seleccione la casilla de origen." + System.getProperty("line.separator"));*/
	}
	
	public boolean gameIsDone(){
		return(rules.soloQuedaUno(board, pieces) || rules.nadieMovible(board, pieces));
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		Piece obs = new Piece("*");
		Square square = (Square)e.getSource();
		//Si es una lastRos/lastCol de verdad
		if(lastRow != -1){

			if(pieces.contains(board.getPosition(lastRow, lastCol)) && (square.getRow() != lastRow || square.getCol() != lastCol)
					&& board.getPosition(square.getRow(), square.getCol()) == null
					&& abs(lastRow-square.getRow()) <= 2 && abs(lastCol-square.getCol()) <= 2){
				
				/*status.append("Has seleccionado la casilla (" + square.getRow() + ", " + square.getCol() 
				+ ") como casilla de destino." + System.getProperty("line.separator"));*/
				
				cosasDeMover(square.getRow(), square.getCol());
				if(!gameIsDone()){
					turnoSiguiente();
				} else {
					String wonnered;
					if(rules.quienGana(board, pieces) == null){
						wonnered = "Ha habido un empate.";
					} else {
						wonnered = rules.quienGana(board, pieces) + " wonnered";
					}
					
					onError(wonnered);
				}
			
			} else {
				onError("Movimiento no permitido.");
			}
			
			lastRow = -1;
			lastCol = -1;
			
			//Si no tenemos ninguna seleccionada y seleccionamos una ficha de que es su turno
		} else if(lastRow == -1 && pieces.contains(board.getPosition(square.getRow(), square.getCol()))
				&& board.getPosition(square.getRow(), square.getCol()).equals(turno)){
			//turnoSiguiente();
			//status.append("Turno de "+ turno +System.getProperty("line.separator")) ;
			lastRow = square.getRow();
			lastCol = square.getCol();
			/*status.append("Has seleccionado la casilla (" + lastRow + ", " + lastCol + ") como casilla de origen." 
					+ System.getProperty("line.separator"));
			status.append("Seleccione su casilla de destino." + System.getProperty("line.separator"));*/
		} else {
			onError("Seleccione una casilla de origen v醠ida." + System.getProperty("line.separator"));
		}
			
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}
	

}

/*
 *
 * Toca hacer m醩 claro qu� est� seleccionado y hacer m醩 intuitivo el proceso de selecci髇/deselecci髇
 * 
 * 
 * Los parsers ir醤 en el main y tal. Me toca crear en windows una funci髇 que cree un tablero en fuci髇 de 
 * los datos acerca de 閘 (dimensi髇, num Piezas, nombre Piezas, obst醕ulos) y luego meterlo en el setter de BoardUI
 * 
 * LO 贚TIMO QUE HE ESTADO HACIENDO HA SIDO IR PONIENDO COSAS EN MAIN PARA VER SI LOS TABLEROS VAN BIEN CUANDO SE 
 * LOS PASAS YA HECHOS (PARA CUANDO YA TENGAMOS ARGS Y TODA LA PESCA)
 * 
 * PARA LAS COSAS DE BoardUI EN VEZ DE COPIAR/PEGAR LAS FUNCIONES DE ATAXX TENGO QUE LLAMARLAS
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general. (cambio turno, etc)
 * 
 * Pasar a BoardUI el GameObserver de Windows en vez de crear uno nuevo.
 * 
 * CUANDO ACTUA WINDOWS TIENEN QUE ACTUAL PANEL DERECHA Y BOARD (POR EJEMPLO CUANDO CAMBIAMOS EL COLOR DE UNA FICHA)
 * 
 * Voy a hacer el muy necesario cambio de que BoardUI pase a ser BoardAtaxx y viceversa
 */
