package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public abstract class BoardUI extends JPanel implements MouseListener, GameObserver{
	protected JLabel[][] squares;
	protected Board board;
	protected List<Piece> pieces;
	protected Piece turno;
	protected StatusPanel status; //Panel de texto del estado de la partida
	private GameMove movimiento;
	private GameRules rules;
	protected HashMap<Piece, Color>pc;
	protected HashMap<Piece,Main.PlayerMode>pm;
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendría los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardUI(HashMap<Piece, Color>pc, HashMap<Piece,Main.PlayerMode>pm){
		pieces = new ArrayList();
		this.pc = pc;
		this.pm = pm;
	}
	
	public abstract void setRules(int dim, int numObs);
	
	public abstract GameRules getRules();

	public void setTurno(Piece turno){
		this.turno = turno;
	}
	public void setList(List<Piece> pieces){
		this.pieces = pieces;
	}
	
	public void setStatusPanel(StatusPanel status){
		this.status = status;
	}
	
	public void setBoard(Board board){
		
		if(board != this.board){
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
				for (int i=0; i<board.getRows(); i++) {
					for (int j=0; j<board.getCols(); j++) {
						squares[i][j] = new Square(i,j);
						
						squares[i][j].addMouseListener(this);
						
						add(squares[i][j]);
						paintSquare(board.getPosition(i, j), i, j);

					}
				}
		} else{
			update(this.pc, this.pm);
		}
		setTurno(pieces.get(0));
	}
	
	public void update(HashMap<Piece, Color>pc, HashMap<Piece,Main.PlayerMode>pm){//Queda ver en qu?momentos se llama a esto dentro del programa.
		this.pc = pc;
		this.pm = pm;
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}
	
	//Pinta un cuadrado.
	//Queda actualizarla para que acepte pintar listas de distintos tamaños
	public void paintSquare(Piece p, int i, int j){
		Piece obs = new Piece("*");
		
		if(p!=null && !p.equals(obs)){
			squares[i][j].setBackground(pc.get(p));
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else {//Si es una casilla vacía
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		squares[i][j].setOpaque(true);	
	}
	
	public abstract void cosasDeMover(int row, int col);
	
	public abstract void turnoSiguiente(); 
	
	public abstract boolean gameIsDone();

	@Override
	public abstract void mouseClicked(MouseEvent e); 

	@Override
	public abstract void mouseEntered(MouseEvent e) ;

	@Override
	public abstract void mouseExited(MouseEvent e) ;
	
	@Override
	public abstract void mousePressed(MouseEvent e);

	@Override
	public abstract void mouseReleased(MouseEvent e) ;

	@Override
	public abstract void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn);

	@Override
	public abstract void onGameOver(Board board, State state, Piece winner);

	@Override
	public abstract void onMoveStart(Board board, Piece turn);

	@Override
	public abstract void onMoveEnd(Board board, Piece turn, boolean success);

	@Override
	public abstract void onChangeTurn(Board board, Piece turn) ;

	@Override
	public abstract void onError(String msg); 

}

/*
 *
 * Toca hacer m醩 claro qu� est� seleccionado y hacer m醩 intuitivo el proceso de selecci髇/deselecci髇
 * 
 * 
 * Los parsers ir醤 en el main y tal. Me toca crear en windows una funci髇 que cree un tablero en fuci髇 de 
 * los datos acerca de 閘 (dimensi髇, num Piezas, nombre Piezas, obst醕ulos) y luego meterlo en el setter de BoardUI
 * 
 * LO 贚TIMO QUE HE ESTADO HACIENDO HA SIDO IR PONIENDO COSAS EN MAIN PARA VER SI LOS TABLEROS VAN BIEN CUANDO SE 
 * LOS PASAS YA HECHOS (PARA CUANDO YA TENGAMOS ARGS Y TODA LA PESCA)
 * 
 * PARA LAS COSAS DE BoardUI EN VEZ DE COPIAR/PEGAR LAS FUNCIONES DE ATAXX TENGO QUE LLAMARLAS
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general. (cambio turno, etc)
 * 
 * Pasar a BoardUI el GameObserver de Windows en vez de crear uno nuevo.
 * 
 * CUANDO ACTUA WINDOWS TIENEN QUE ACTUAL PANEL DERECHA Y BOARD (POR EJEMPLO CUANDO CAMBIAMOS EL COLOR DE UNA FICHA)
 * 
 * Voy a hacer el muy necesario cambio de que BoardUI pase a ser BoardAtaxx y viceversa
 */
