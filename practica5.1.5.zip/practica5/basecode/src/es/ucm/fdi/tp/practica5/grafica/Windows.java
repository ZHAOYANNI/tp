package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Random;


public class Windows extends JPanel implements GameObserver, PanelDer.SettingListener{

	private BoardUI ui;
	private PanelDer der;
	private StatusPanel status;
	private PlayerInfor playerInfor;
	private List<Piece> pieces;
	private HashMap<Piece, Color> pc;
	private HashMap<Piece, Main.PlayerMode> pm;

	public Windows(Controller c,Piece viewPiece,List<Piece> pieces, int rows, int numObs, Piece turn,
			boolean hasRandom, boolean hasAi) {
		pc = new HashMap();
		pm = new HashMap();
		for(int i = 0; i < pieces.size(); i++){
			pc.put(pieces.get(i), new Color((int)(Math.random() * 0x1000000)));
		}
		for(int i = 0; i < pieces.size(); i++){
			pm.put(pieces.get(i), Main.PlayerMode.MANUAL);
		}
		
		ui = new BoardAtaxx(pc,pm);
		this.pieces = pieces; 
		ui.setList(this.pieces);
		ui.setRules(rows, numObs);
		Board board = ui.getRules().createBoard(pieces);
		ui.setStatusPanel(status);
		ui.setBoard(board);
		playerInfor = new PlayerInfor(pieces,pm,pc, board);
		status = new StatusPanel();
		der = new PanelDer(this, pc, pm, hasRandom, hasAi);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		der.initComponents(this,c, viewPiece, pieces, this, turn);
		add(der, BorderLayout.EAST);
		

		
	}
	
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces,
			Piece turn) {
		status.append("bienvenido a " + gameDesc+ System.getProperty("line.separator"));
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		ui.update(pc,pm);
		if(state == Game.State.Won){
			status.append("ha ganado " + winner+ System.getProperty("line.separator"));
		}else if (state == Game.State.Draw){
			status.append("empate");
		}else if (state == Game.State.Stopped){
			status.append("ha sido interrupido el juego");
		}
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		ui.update(pc,pm);
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		ui.update(pc,pm);
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		ui.update(pc,pm);
		status.append("turno de" + turn+ System.getProperty("line.separator"));
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}

	@Override
	public void ColorChangeChoose(Piece p, Color c) {
		this.pc.put(p, c);
		actualiza(p);
	}

	@Override
	public void PlayerModeChange(Piece p, PlayerMode m) {
		if(p != null){
			if(m == Main.PlayerMode.RANDOM){
				this.pm.put(p, Main.PlayerMode.RANDOM);
			
	   	 	}else if(m == Main.PlayerMode.AI){
	   	 		this.pm.put(p, Main.PlayerMode.AI);
	   	 	}else
	   	 		this.pm.put(p, Main.PlayerMode.MANUAL);
		}else{
			if(m == Main.PlayerMode.RANDOM){
				this.pm.put(pieces.get(0), Main.PlayerMode.RANDOM);
	   	 	}else if(m == Main.PlayerMode.AI){
	   	 		this.pm.put(pieces.get(0), Main.PlayerMode.AI);
	   	 	}else
	   	 		this.pm.put(pieces.get(0), Main.PlayerMode.MANUAL);
		}
		actualiza(p);
		
	}

	@Override
	public void AIMoveChoose(Piece p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void RandomMoveChoose(Piece p) {
		// TODO Auto-generated method stub
		
	}
	
	public void actualiza( Piece turn){
		
		der.actualiza(pm, turn);
		playerInfor.actualiza();
		ui.update(pc,pm);
	}
}
