package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

import java.util.HashMap;
import java.util.List;
import java.util.Vector;

public class PlayerInfor extends JPanel{
	private AbstractTableModel tabla;
	private JTable table;
	private HashMap<Piece, Main.PlayerMode> pm;
	private HashMap<Piece, Color> pc;
	
	
	public PlayerInfor(List<Piece> pieces,HashMap<Piece, Main.PlayerMode> pm, HashMap<Piece, Color> pc, 
			Board board){
		setBorder(new TitledBorder(null, "Player Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
		table= new JTable();
		this.pm = pm;
		this.pc = pc;
		tabla = new AbstractTableModel(){
			@Override
			public int getRowCount() {
				return pieces.size();
			}

			@Override
			public int getColumnCount() {
				return 3;
			}

			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				if(columnIndex == 0){
					return pieces.get(rowIndex);
				}else if (columnIndex == 1){
					return pm.get(pieces.get(rowIndex));
				}else {
					return board.getPieceCount(pieces.get(rowIndex));
				}
			}
			
		};
		
		table.setModel(tabla);
		table.getColumnModel().getColumn(0).setHeaderValue("Player");
		table.getColumnModel().getColumn(1).setHeaderValue("Mode");
		table.getColumnModel().getColumn(2).setHeaderValue("#Piece");
		table.setOpaque(true);
		table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
			@Override
			public Component getTableCellRendererComponent(JTable tabla, Object value, boolean isSelected,
					boolean hasFocus, int row, int col){
				Component l = super.getTableCellRendererComponent(tabla, value, isSelected, hasFocus, row, col);
				if(row == 0){
					l.setBackground(pc.get(pieces.get(0)));
				}else if (row == 1){
					l.setBackground(pc.get(pieces.get(1)));
				}else if(row == 2){
					l.setBackground(pc.get(pieces.get(2)));
				}else{
					l.setBackground(pc.get(pieces.get(3)));
				}
				return l;
			}
		});
		add( new JScrollPane(table));
	}
	
	public void actualiza(){
		table.updateUI();
		}
	
}
