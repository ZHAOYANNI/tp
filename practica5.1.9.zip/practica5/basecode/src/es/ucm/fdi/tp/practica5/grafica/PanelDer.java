package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;


public class PanelDer extends JPanel {
	
	
	private PieceColor pieceColor;
	private PlayerMode playerMode;
	private AutomaticMove move;
	private Salir salir;
	private SettingListener list;
	private boolean hasAi;
	private boolean hasRandom;
	private HashMap<Piece, Color> pc;
	private HashMap<Piece, Main.PlayerMode> pm;
	private Piece viewPiece;
	
	  public PanelDer(SettingListener list, HashMap<Piece, Color> pc, HashMap<Piece, Main.PlayerMode> pm,
			  boolean hasAi, boolean hasRandom) {
		  this.list = list;
		  this.pc = pc;
		  this.pm = pm;
		  this.hasAi = hasAi;
		  this.hasRandom = hasRandom;
		  this.viewPiece = viewPiece;
	    }
	  
	  public interface SettingListener{
			public void ColorChangeChoose(Piece p, Color c);
			public void PlayerModeChange(Piece p, Main.PlayerMode m);
			public void AIMoveChoose(Piece p);
			public void RandomMoveChoose(Piece p);
	  }
	  
	  public void initComponents(Controller2 c, Piece viewPiece, List<Piece> pieces,
			  SettingListener list, Piece turn){
		pieceColor = new PieceColor();
		playerMode = new PlayerMode();
		move = new AutomaticMove();
		salir = new Salir();
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		panel.add(pieceColor);
		pieceColor.setTit();
		pieceColor.setBoton(pieces,list);
		
		panel.add(playerMode);
		playerMode.setTitulo();
		playerMode.initComponent(pieces, list, hasRandom, hasAi);
		
		
		panel.add(move);
		move.setTit();
		move.initComponent(pm,turn, list, hasRandom, hasAi);
		
		
		panel.add(salir);
		salir.initComponent(c,viewPiece, turn, pm);
		
		add(panel);
		
	}
	  
	  public void actualiza(HashMap<Piece, Main.PlayerMode> pm, Piece turn){
		  this.pm = pm;
		  move.actualiza(pm, turn, hasRandom, hasAi);
		  salir.actualiza(pm, turn, viewPiece);
	  }
}
