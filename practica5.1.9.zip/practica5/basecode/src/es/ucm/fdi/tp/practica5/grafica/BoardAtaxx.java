package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;

import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public class BoardAtaxx extends BoardUI {

	private int lastRow; // Guarda última fila clicada
	private int lastCol; // Guarda última columna clicada
	private StatusPanel status; // Panel de texto del estado de la partida
	private static AtaxxMove movimiento;
	private AtaxxRules rules;

	// LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	// Si hay alguna seleccionada tendría los valores de esta.
	// Lo mismo para lastPiece;

	public BoardAtaxx(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm, Controller2 c, 
			StatusListener list) {
		super(pc, pm, c, list);
		lastRow = -1;
		lastCol = -1;
	}

	public void setRules(int dim, int numObs) {
		AtaxxRules rules = new AtaxxRules(dim, numObs);
		this.rules = rules;
	}

	public AtaxxRules getRules() {
		return rules;
	}

	public void setStatusPanel(StatusPanel status) {
		this.status = status;
	}
	
	public void setMove(AtaxxMove move){
		this.movimiento = move;
	}
	
	public static AtaxxMove getMove(){
		return movimiento;
	}
	
	private int abs(int num) {
		if (num >= 0) {
			return num;
		}
		return -num;
	}

	//A esta funci髇 la llamamos cuando movemos una pieza del tablero nosotros
	//S髄o viene aqu� si el movimiento es v醠ido.
	public void cosasDeMover(int row, int col) {
		Piece p = board.getPosition(lastRow, lastCol); //Cogemos la pieza que vamos a mover.
		setMove(new AtaxxMove(lastRow, lastCol, row, col, p)); //seteamos el movimiento que vamos a hacer.
		
		ManualPlayer player = new ManualPlayer(); //Creamos el jugador correspondiente al movimiento que vamos a hacer.
		c.makeMove(player, turno); //Llamamos a makeMove (esto va a hacer que game haga el movimiento que le devuelva el Player
									//Y el player le va a devolver el movimiento que hemos seteado.
		update(pc, pm); //Actualizamos el tablero porque ya se ha hecho el movimiento.

	}
	
	@Override
	public void movimientoAleatorio(){
		AtaxxRandomPlayer player = new AtaxxRandomPlayer();
		c.makeMove(player, turno);
		update(pc, pm);
	}
	
	@Override
	public void movimientoAi(){
		Player player = new AiPlayer();
		c.makeMove(player, turno);
		update(pc, pm);
	}

	public boolean gameIsDone() {
		return (rules.soloQuedaUno(board, pieces) || rules.nadieMovible(board, pieces));
	}

	@Override
	public void mouseClicked(MouseEvent e) {
			Piece obs = new Piece("*");
			if(pm.get(turno) == Main.PlayerMode.MANUAL){
			Square square = (Square) e.getSource();

	
				// Si es una lastRos/lastCol de verdad
				if (lastRow != -1) {
		
					// Si la pieza que se mueve no es obs/null.
					// Si la casilla a la que movemos no es de la que venimos
					// Si la casilla a la que vamos est?vac韆
					// Si la casilla a la que vamos est� "cerca"
					if (pieces.contains(board.getPosition(lastRow, lastCol))
							&& (square.getRow() != lastRow || square.getCol() != lastCol)
							&& board.getPosition(square.getRow(), square.getCol()) == null
							&& abs(lastRow - square.getRow()) <= 2 && abs(lastCol - square.getCol()) <= 2) {
		
						cosasDeMover(square.getRow(), square.getCol());
					} else {
						c.onError("Movimiento no permitido.");
						list.selectOrigen();
					}
		
					lastRow = -1;
					lastCol = -1;
		
					// Si no tenemos ninguna seleccionada y seleccionamos una ficha de
					// que es su turno
				} else if (lastRow == -1 && pieces.contains(board.getPosition(square.getRow(), square.getCol()))
						&& board.getPosition(square.getRow(), square.getCol()).equals(turno)) {
					list.selectDestiny();
					lastRow = square.getRow();
					lastCol = square.getCol();
				} else {
					c.onError("Seleccione una casilla de origen v醠ida." + System.getProperty("line.separator"));
				}
			}else if(pm.get(turno) == Main.PlayerMode.RANDOM){
				movimientoAleatorio();
			}else if(pm.get(turno) == Main.PlayerMode.AI){
				movimientoAi();
			}

	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}

/*
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general.
 * (cambio turno, etc)
 * 
 * Pasar a BoardUI el GameObserver de Windows en vez de crear uno nuevo.
 * 
 * CUANDO ACTUA WINDOWS TIENEN QUE ACTUAL PANEL DERECHA Y BOARD (POR EJEMPLO
 * CUANDO CAMBIAMOS EL COLOR DE UNA FICHA)
 */
