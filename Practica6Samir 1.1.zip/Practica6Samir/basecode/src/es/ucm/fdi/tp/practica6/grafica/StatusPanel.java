package es.ucm.fdi.tp.practica6.grafica;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class StatusPanel extends JPanel{
	private JTextArea textPrueba;
	
	public StatusPanel(){
		setBorder(new TitledBorder(null, "Status Menssages", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
		textPrueba = new JTextArea();
		textPrueba.setEditable(false);
		textPrueba.setRows(50);
		add(new JScrollPane(textPrueba), BorderLayout.CENTER);
	}
	
	public void append(String txt){
		textPrueba.append(txt + System.getProperty("line.separator"));
		textPrueba.setCaretPosition(textPrueba.getDocument().getLength());
	}
}
