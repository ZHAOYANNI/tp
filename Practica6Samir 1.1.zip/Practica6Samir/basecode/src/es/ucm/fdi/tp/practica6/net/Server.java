package es.ucm.fdi.tp.practica6.net;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.control.commands.Command;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Server extends Controller implements GameObserver{
	
	private int port;
	private int numPlayers;
	private int numOfConnectedPlayers;
	private GameFactory gameFactory;
	private List<Connection> clients;
	private Board board;
	
	volatile private ServerSocket server;
	volatile private boolean stopped;
	volatile private boolean gameOver;
	
	private JTextArea infoArea;
	
	public Server(GameFactory gameFactory, List<Piece> pieces, int port) throws IOException{
		super(new Game(gameFactory.gameRules()), pieces);
		
		this.port = port;
		this.numPlayers = pieces.size();
		this.numOfConnectedPlayers = 0;
		this.clients = new ArrayList<Connection>();
		
		this.server = new ServerSocket(port);
		this.stopped = false;
		this.gameOver = false;
		
		game.addObserver(this);
	}
	
	@Override
	public synchronized void makeMove(Player player){
	try{
		super.makeMove(player);
	} catch(GameError e){}
	
	}
	
	@Override
	public synchronized void stop(){
		try{super.stop();} catch(GameError e){}
	}
	
	@Override
	public synchronized void restart(){
		try{super.restart();}catch(GameError e){}
	}
	
	@Override
	public void start(){
		controlGUI();
		try {
			startServer();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void controlGUI(){
		try{
			SwingUtilities.invokeAndWait(new Runnable(){
				@Override
				public void run(){ constructGUI();}
			});
		} catch(InvocationTargetException | InterruptedException e){
			throw new GameError("Something went wrong when constructing the GUI");
		}
	}
	
	private void constructGUI(){
		JFrame window = new JFrame("Game Server");
		JTextArea infoArea = new JTextArea(5, 20);
		infoArea.setEditable(false);
		window.add(infoArea);
		this.infoArea = infoArea;
		
		JButton quitButton = new JButton("Stop Server");
		quitButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//Parar el server y salir de la app
			}
		});
		window.add(quitButton);
		window.setPreferredSize(new Dimension(640, 480));
		window.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		window.pack();
		window.setVisible(true);
	}
	
	private void log(String msg){
		SwingUtilities.invokeLater(new Runnable(){
			@Override
			public void run(){
				infoArea.append(msg + System.getProperty("line.separator"));
			}
		});
	}
	
	private void startServer() throws IOException{
		
		//port = 0;
		
		server = new ServerSocket(port);
		stopped = false;
		
		while(!stopped){
			try{
				Socket s = server.accept(); //acepta una conexi�n a un socket s
				//log corresponding message
				log("Connection was successfull.");//Me queda ver cu�l es el mensage correspondiente
				handleRequest(s);//call handleRequest(s) to handle the request
			} catch(IOException e){
				if(!stopped){
					log("error while waiting for a connection: " + e.getMessage());
				}
			} catch (InterruptedException e) {
				log("Connection was interrupted. " + e.getMessage());
			}
		}
	}
	
	private void handleRequest(Socket s) throws InterruptedException{
		try{
			Connection c = new Connection(s);
			
			Object clientRequest = c.getObject();
			if(!(clientRequest instanceof String) && !((String)clientRequest).equalsIgnoreCase("Connect")){
				c.sendObject(new GameError("Invalid Request"));
				c.stop();
				return;
			}
			
			//1) Si el ya se han conectado el num m�ximo de clientes respondemos con GameError adecuado
			if(numOfConnectedPlayers == numPlayers){
				throw new GameError("Error: No more players can connect to the game.");
			}
			//2) Incrementamos el n�m de clientes conectados y a�adimos 'c' a la lista de clientes.
			numPlayers++;
			clients.add(c);
			//3) Enviamos "OK" al cliente seguido de la GameFactory Y el Piece a usar
			//Asignamos al i�simo cliente la i�sima pieca de la lista
			Thread t1 = new ThreadEx("OK");
			Thread t2 = new ThreadEx(gameFactory);
			Thread t3 = new ThreadEx(pieces.get(numPlayers-1));
			
			t1.start();
			t1.join();
			t2.start();
			t2.join();
			t3.start();
			t3.join();
		
			//4) Si hay un num suficiente de clientes empezamos el juego
			//(la primera vez con start() luego con restart()
			if(numOfConnectedPlayers == numPlayers){
				onGameStart(board, gameFactory.gameRules().gameDesc(), pieces, pieces.get(0));
				start();
			}
			
			//5) Invocamos a startClientListener(c) para iniciar una hebra para escuchar al cliente
			startClientListener(clients.get(numPlayers-1));
		}catch (IOException | ClassNotFoundException e){}
		
	}
	
	private void startClientListener(Connection c){
		gameOver = false;
		Thread t = new Thread();; //Iniciar una hebra para ejecutar el bucle de abajo

		t.start();
		while(!stopped && !gameOver){
			try{
				Command cmd;
				//1. read a Command (Recibir Object del client y castearlo a Command
				cmd = (Command)c.getObject();
				//2. Execute the commando ejecutar cml.exec, pas�ndole el Controller, GameServer.this (no s� cu�l es ese m�todo
				cmd.execute(this);
				//Ah� se ejecuta sobre el juego que observa el servidor -> Se va a llamar a 
				//onMoveStart y esas cosas porque el servidor observa el juego.
				//En los onMoveStart, etc, del Server se avisa a los clientes de lo que
				//ha pasado y se les pasa los datos necesarios.
				
			} catch(ClassNotFoundException | IOException e){
				if(!stopped && !gameOver){
					//stop the game(not the server);
					stop();
				}
			}
		}
	}
	
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn){
		try {
			this.board = board;
			forwardNotification(new GameStartResponse(board, gameDesc, pieces, turn));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void onGameOver(Board board, State state, Piece winner){
		try {
			forwardNotification(new GameOverResponse(board, state, winner));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop();
	}
	
	public void onMoveStart(Board board, Piece turn){
		try {
			forwardNotification(new MoveStartResponse(board, turn));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void onMoveEnd(Board board, Piece turn, boolean success){
		try {
			forwardNotification(new MoveEndResponse(board, turn, success));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void onChangeTurn(Board board, Piece turn){
		try {
			forwardNotification(new ChangeTurnResponse(board, turn));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void onError(String msg) {
		try {
			forwardNotification(new ErrorResponse(msg));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void forwardNotification(Response r) throws IOException{
		for(Connection c: clients){
			c.sendObject(r);
		}
	}
	
	public interface Response extends java.io.Serializable{
		public void run(GameObserver o);
	}
	
	public class GameStartResponse implements Response{
		private Board board;
		private String gameDesc;
		private List<Piece> pieces;
		private Piece turn;
		
		public GameStartResponse(Board board, String gameDesc, List<Piece> pieces, Piece turn){
			this.board = board;
			this.gameDesc = gameDesc;
			this.pieces = pieces;
			this.turn = turn;
		}
		
		@Override
		public void run(GameObserver o){
			o.onGameStart(board, gameDesc, pieces, turn);
		}
	}
	
	public class GameOverResponse implements Response{
		private Board board;
		private State state;
		private Piece winner;
		
		public GameOverResponse(Board board, State state, Piece winner){
			this.board = board;
			this.state = state;
			this.winner = winner;
		}
		
		@Override
		public void run(GameObserver o){
			o.onGameOver(board, state, winner);
		}
	}
	
	public class MoveStartResponse implements Response{
		private Board board;
		private Piece turn;
		
		public MoveStartResponse(Board board, Piece turn){
			this.board = board;
			this.turn = turn;
		}
		
		@Override
		public void run(GameObserver o){
			o.onMoveStart(board, turn);
		}
	}
	
	public class MoveEndResponse implements Response{
		private Board board;
		private Piece turn;
		private boolean success;
		
		public MoveEndResponse(Board board, Piece turn, Boolean success){
			this.board = board;
			this.turn = turn;
			this.success = success;
		}
		
		@Override
		public void run(GameObserver o){
			o.onMoveEnd(board, turn, success);
		}
	}
	
	public class ChangeTurnResponse implements Response{
		private Board board;
		private Piece turn;
		
		public ChangeTurnResponse(Board board, Piece turn){
			this.board = board;
			this.turn = turn;
		}
		
		@Override
		public void run(GameObserver o){
			o.onChangeTurn(board, turn);
		}
	}
	
	public class ErrorResponse implements Response{
		private String msg;
		
		public ErrorResponse(String msg){
			this.msg = msg;
		}
		
		@Override
		public void run(GameObserver o){
			o.onError(msg);
		}
	}
	
	public class ThreadEx extends Thread{
		private Object obj;
		
		public ThreadEx(Object obj){
			this.obj = obj;
		}
		
		public void run(){
			try {
				clients.get(numPlayers-1).sendObject(obj);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
		
}
