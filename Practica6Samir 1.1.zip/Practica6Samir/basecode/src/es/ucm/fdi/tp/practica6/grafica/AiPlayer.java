package es.ucm.fdi.tp.practica6.grafica;

import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.Utils;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.*;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRules;

public class AiPlayer extends Player{

	private Player player;
	public AiPlayer(){
		player = new DummyAIPlayer(new AtaxxRandomPlayer(), 1000);
	}

	@Override
	public GameMove requestMove(Piece p, Board board, List<Piece> pieces,
			GameRules rules) {
		return player.requestMove(p, board, pieces, rules);
	}
}
