package es.ucm.fdi.tp.practica5.attt;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Controller2;
import es.ucm.fdi.tp.practica5.grafica.Windows;
import es.ucm.fdi.tp.practica5.ttt.TicTacToeFactoryExt;

public class AdvancedTTTFactoryExt extends TicTacToeFactoryExt {

	public AdvancedTTTFactoryExt(){
		super();
	}
	
	public AdvancedTTTFactoryExt(List<Piece> pieces){
		super(pieces);
	}
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {

				String gameDesc = new String("AdvancedTicTAcToe ");
				if(viewPiece != null){
					gameDesc += " (" + viewPiece + ")";
				}
				Windows window = new Windows(c, viewPiece, pieces, dim, 0, true, true, gameDesc);
				window.setTitle(gameDesc);
				window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				((Controller2)c).addWindow(window);
				window.setSize(600, 400);
				window.setVisible(true);
			}
		});
	}
}
