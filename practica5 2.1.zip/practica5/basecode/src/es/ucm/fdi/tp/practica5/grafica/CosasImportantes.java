package es.ucm.fdi.tp.practica5.grafica;

public class CosasImportantes {

}

/*
 * Vale. He cambiado bastantes cosas. Muchas. Te voy a ir dejando comentado TODO lo que crea que es importante.
 * Voy a intentar dejarlo comentado de manera que cuando veas algo y su comentario entiendas c髆o funciona y por qu� tiene
 * que funcionar as�.
 * 
 * Luego aqu� te voy a dejar las cosas importantes que quedan por hacer, las cosas que a lo mejor no entiendo mucho
 * (de las clases que has hecho, c髆o funcionan, etc), y las cosas tontas o raras que fallan.
 * 
 * Vale, para empezar te explico un poco por encima c髆o van el controlador y Game. 
 * Lo m醩 importante de esta pr醕tica es que Game lo hace todo.
 * El m閠odo makeMove de Controller2 s髄o llama al de Game para que haga el movimiento.
 * Game tiene su tablero y todo. 
 * El m閠odo makeMove de Game crea un GameMove a partir del tablero, turno, piezas, rules y Persona.
 * El movimiento lo crea llamando a Persona.requestMove(...). Por eso vamos a necesitar una clase para cada tipo de persona.
 * 
 * (Por eso he creado ManualPlayer, en ella te dejo comentado lo que hace).
 * Y por eso vamos a necesitar un RandomPlayer (ya hay uno en el baseCode, a lo mejor podemos usar ese)
 * Y un AIPlayer (esa la tenemos que hacer nosotros).
 * Una vez est閚 hechas esas clases hay que hacer que los listeners que tenemos hagan lo que tienen que hacer.
 * (Eso 鷏timo est� mejor explicado en ManualPlayer)
 * 
 * Controller2 es una clase que he tenido que hacer que extiende controller. 
 * Tiene un array de ventanas que vamos a necesitar para la multiview.
 * Para la single view s髄o usarmos array[0]
 * 
 * Tambi閚 tiene un tablero que he necesitado para met閞selo a BoardUI.
 * Lo he necesitado porque el tablero que le met韆mos a BoardUI lo cre醔amos en Windows,
 * entonces era distinto al que hab韆 en game, porque los obst醕ulos son aleatorios y cre醔amos dos tableros.
 * Eso hac韆 que hubiera problemas al mover porque el tablero que ve韆s no era el que se usaba al mover.
 * 
 * He intentado meter ese teclado a BoardUI desde otro sitio porque como lo he hecho (lo seteo en el Controller cuando me lo
 * manda Game, en Windows hago getBoard() y hago ui.setBoard() con el que acabo de coger) me parece muy feo, pero no he podido
 * por una u otra raz髇. No pierdas tiempo en intentar mejorar eso.
 * 
 * Controller2 tiene un GameObserver. Los game observers hay que a馻dirlos a Game con la funci髇 addObserver de Game.
 * Esto es porque en makeMove de Game, aparte de hacerse el movimiento llamando al execute(...) de la pr醕tica 4
 * tambi閚 se van llamando a todos los Observers que tiene Game a medida que van pasando las cosas.
 * 
 * Por eso, los onGameStart, onMoveStart, etc no tienen que hacer las cosas. Es decir, onChangeTurn no tiene que 
 * pasar de turno porque eso ya lo ha hecho Game, y si pasamos ah� habremos pasado 2 turnos.
 * Lo que tiene que hacer onChangeTurn es actualizar Controller, Board, etc para que tengan el turno nuevo.
 * 
 * Ese viene a ser el funcionamiento de la pr醕tica. Un esquema muy sencillo es este:
 * 
 * 1) Tenemos una interfaz que nos muestra c髆o est� la partida.
 * 2) Clicamos algo de mover (Aleatorio, Inteligente, Lo hacemos nosotros el movimiento)
 * 3) El listener crea un Player que se corresponda con el tipo de movimiento.
 * 4) El listener llama a makeMove del Controller2 con turn y con el Player.
 * 4) Game hace todo.
 * 4*) Mientras Game hace todo los Observers van actualizando los datos que tengan que actualizar.
 * 5) Se repinta el tablero.
 * 6) Se comprueba si se ha acabado la partida. 
 * 7) Se ha acabado -> Lo que sea. (Ganador, empate...)
 * 7*) No se ha acabado -> Volvemos a estar en el paso 1.
 * 
 * Aparte de este comentario tan largo mira el de ManualPlayer para ver c髆o hay que hacer lo de los movimientos 
 * Y mira tambi閚 startGame del Main, que tambi閚 te he puesto ah� cosas.
 * 
 * 
 * Problemas:
 * 
 * Aunque no usemos en BoardUI el tablero que creamos en Windows, si no lo creamos la ventana se ve vac韆 en blanco.
 * Al empezar la partida todas las piezas son del mismo color.        
 *   solucionada
 * Al empezar la partida se llama dos veces a onGameStart(una lo hace Game, esa es la buena. La otra no s� d髇de est�)
 * (Si la encuentras no la borres, com閚tala y dime d髇de est�, que a lo mejor es importante).
 *    solucionada, está en windows, no tienes que llamar a c.onGameStart.
 * Tenemos que volver a hacer los status.append(), supongo que en Windows (aunque creo que mejor lo podemos hacer en controlador)
 *    solucionada, no me deja en controlador, así que he hecho un listener en boardUI y windows lo implementa. 
 * Cuando le damos a Quit salta la ventana que tiene que saltar pero todav韆 no hace nada.
 * Reset no hace nada.
 *    sí hace algo, pero el tablero no actualiza.
 * Ahora mismo la partida no acaba. (El problema es que AtaxxRules updateState siempre devuelve que la partida no ha acabado)
 *    media solucionada, he pensado que podemos pasar un boolean como parametro y si este parametro está en true, 
 *    al hacer un clic en el tablero, salta una ventana de dialogo diciendo que no se puede. 
 * COMPRUEBA PRIMERO ATAXXRULES, UPDATESTATE, QUE PARECE QUE LOS DATOS LE LLEGAN BIEN
 * Y LOS USA BIEN PERO LUEGO DEVUELVE LO QUE NO ES
 * 
 * No se ve la parte de #Piece en la tabla de playerInfor. 
 *  Creo que el GameObserver de Windows sobra, pero eso no es muy prioritario todav韆.
 *  
 *  Una 鷏tima cosa. Si vas a hacer couts o lo que sea para comprobar si las cosas funcionan, en el cout pon
 *  tambi閚 la clase y m閠odo en el que est�, que si no encontrarlos luego para borrarlos es horrible.
 *  
 *
 * 
 */
