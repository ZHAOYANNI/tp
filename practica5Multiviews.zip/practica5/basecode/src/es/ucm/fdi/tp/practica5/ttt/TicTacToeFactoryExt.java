package es.ucm.fdi.tp.practica5.ttt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.ConsolePlayerFromListOfMoves;
import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.AIAlgorithm;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.views.GenericConsoleView;
import es.ucm.fdi.tp.practica5.connectn.ConnectNFactoryExt;
import es.ucm.fdi.tp.practica5.grafica.Controller2;
import es.ucm.fdi.tp.practica5.grafica.Windows;

public class TicTacToeFactoryExt extends ConnectNFactoryExt {
	
	private List<Piece> pieces;
	
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame jf = new JFrame();
				String gameDesc = new String("TiCTacToe");
				jf.setTitle(gameDesc);
				jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				Windows window = new Windows(c, viewPiece, pieces, dim, 0, true, true, gameDesc);
				((Controller2)c).addWindow(window);
				jf.add(window);
				jf.setSize(600, 400);
				jf.setVisible(true);
				//La raz髇 por la que no le paso a Windows el tablero por aqu� es porque no podemos cambiar los argumentos
				//de createSwingView. Por lo dem醩 esta funci髇 no requiere explicaci髇. Lo siento por traerte aqu�, lol.
			}
		});
	}
	
	@Override
	public GameRules gameRules() {
		return new TicTacToeRules();
	}

	@Override
	public Player createConsolePlayer() {
		// unlink ConnectN, we use the console player that shows a list of
		// possible move, etc.
		return new ConsolePlayerFromListOfMoves(new Scanner(System.in));
	}
	
	@Override
	public Player createAIPlayer(AIAlgorithm alg) {
		return new DummyAIPlayer(createRandomPlayer(), 1000);
	}

	/**
	 * Por defecto, hay dos jugadores, X y O.
	 */
	@Override
	public List<Piece> createDefaultPieces() {
		List<Piece> pieces = new ArrayList<Piece>();
		pieces.add(new Piece("X"));
		pieces.add(new Piece("O"));

		return pieces;
	}

	@Override
	public void createConsoleView(Observable<GameObserver> g, Controller c) {
		new GenericConsoleView(g, c);
	}
}
