package es.ucm.fdi.tp.practica6.grafica;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Square extends JLabel{
	private int row, col;

	//La idea es que en Square (podr�a ser en board y probablemente lo acabar?siendo)
	//Se guarde el �ltimo cuadrado clicado y la pieza que ten�a para saber si el siguiente click tiene que mover o no
	//TIENE QUE SER EN BOARD PORQUE EN SQUARE S�LO PODEMOS GUARDAR LOS CLICKS EN DICHO SQUARE
	
	public Square(int row, int col) {
		this.row = row;
		this.col = col;
	}
	
	public int getRow(){
		return this.row;
	}
	
	public int getCol(){
		return this.col;
	}
	
	public void squareWasClicked(int row, int col){
		System.out.println("se ha clicado en " + row + col);
		
	}
	
	public int abs(int num){
		if(num >= 0){
			return num;
		}
		return -num;
	}
	
}
