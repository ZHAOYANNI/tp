package es.ucm.fdi.tp.practica6.grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.Utils;
import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica6.grafica.Main.PlayerMode;

public class GameWindow extends JFrame implements PanelDer.SettingListener, BoardUI.StatusListener, GameObserver {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4192014945426749947L;
	protected BoardUI ui;
	protected PanelDer der;
	private StatusPanel status;
	protected PlayerInfor playerInfor;
	private List<Piece> pieces;
	private HashMap<Piece, Color> pc = new HashMap<>();
	protected HashMap<Piece, Main.PlayerMode> pm = new HashMap<>();
	private Board board;
	private Controller c;
	private boolean hasRandom;
	private Player random;
	private boolean hasAi;
	private Player ai;
	protected Piece viewPiece;
	private String gameDesc;
	private int windowIndex;
	private int moves = 0;
	private boolean enMovimiento;
	private Piece turn;
	
	public GameWindow(Controller c, BoardUI.GraphicalPlayer graphicalPlayer, Piece viewPiece,
			Player random, Player ai, String gameDesc, GameRules rules) {
		this.hasRandom = random != null;
		this.random = random;
		this.hasAi = ai != null;
		this.ai = ai;
		this.viewPiece = viewPiece;
		this.gameDesc = gameDesc;
		this.c = c;
		ui = new BoardUI(pc, pm, c, this, viewPiece, graphicalPlayer, rules);		
	}
	
	public void setPieces(List<Piece> pieces, Board board) {
		if (this.pieces != null && this.pieces.equals(pieces)) return;
		
		this.board = board;
		this.pieces = pieces;
		
		if(viewPiece == null){
			this.windowIndex = 0;
		} else{
			this.windowIndex = pieces.indexOf(viewPiece);
		}
		
		enMovimiento = false;
		for (int i = 0; i < pieces.size(); i++) {
			pc.put(pieces.get(i), Utils.randomColor());
		}
		for (int i = 0; i < pieces.size(); i++) {
			pm.put(pieces.get(i), Main.PlayerMode.MANUAL);
		}
		this.pieces = pieces;
		ui.setPieces(pieces);
		
		playerInfor = new PlayerInfor(pieces, pm, pc, board);
		status = new StatusPanel();
		gameStart(gameDesc);
		der = new PanelDer(this, pc, pm, hasRandom, hasAi);
		ui.setBoard(board);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		der.initComponents(c, viewPiece, pieces, this, viewPiece == null ? pieces.get(0) : viewPiece);
		add(der, BorderLayout.EAST);
	}
	
	public void repaintBoard(Board board){
		ui.setTurno(turn);
		ui.setPieces(pieces);
		ui.setBoard(board);
		repaint();
	}

	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		setPieces(pieces, board);
		status.append("Bienvenido a " + gameDesc + System.getProperty("line.separator"));
	}

	public void onGameOver(Board board, State state, Piece winner) {
		repaintBoard(board);

		if (state == Game.State.Won) {
			onError(winner + " is the winner!");
		} else if (state == Game.State.Draw) {
			status.append("empate");
			onError("The game ended in a draw");
		} else if (state == Game.State.Stopped) {
			onError("The game was ended");
		}		
	}

	public void ColorChangeChoose(Piece p, Color c) {
		this.pc.put(p, c);
		actualiza(p);
	}

	public void PlayerModeChange(Piece p, PlayerMode m) {
		if (moves <= 1){
			int index = 0;
			if(p != null)
				index = pieces.indexOf(p);
			if ((viewPiece == null) || (viewPiece != null && index == windowIndex)){
					if(m == Main.PlayerMode.RANDOM){
						this.pm.put(pieces.get(index), Main.PlayerMode.RANDOM);
			   	 	}else if(m == Main.PlayerMode.AI){
			   	 		this.pm.put(pieces.get(index), Main.PlayerMode.AI);
			   	 	}else
			   	 		this.pm.put(pieces.get(index), Main.PlayerMode.MANUAL);
				actualiza(p);
			}else{
				status.append("Error, no se puede modificar el modo de otro jugador. ");
			}	
		}else {
			status.append("Error, no se puede modificar el modo en primer turno.");
		}
	}
	
	public PlayerMode getMode(Piece p){
		return pm.get(p);
	}

	public void makeAutoMove(Player player, String name, Piece p) {
		if(!enMovimiento){
			if(p.equals(turn))
				c.makeMove(player);
			else 
				status.append("Error. No se puede hacer un movimiento " + name + " si no es tu turno. ");
		}else
			status.append("Error. No se puede hacer un movimiento " + name + "  durante la ejecuci��n de un "
					+ "movimiento. ");
	}
	public void actualiza(Piece turn) {
			der.actualiza(pm, turn);
			playerInfor.actualiza();
			ui.update(pc, pm);
	}
	
	public void updateBoard(){
		ui.update(pc, pm);
	}

	public void gameStart(String gameDesc){
		status.append("Bienvenido a " + gameDesc);
	}
	
	public void changePm(HashMap<Piece,Main.PlayerMode> pm){
		this.pm.putAll(pm);
	}
	
	@Override
	public void changeTurn(Piece p) {
		if(p != null){
			if(viewPiece != null){
				if (!viewPiece.equals(turn)){
					status.append("Turn of " + p);
				} else{
					status.append("Turn of " + p + " (YOU)");
				}
			} else{
				status.append("Turn of " + p);
			}
		}
	}

	@Override
	public void selectOrigen() {
		status.append("Click on an origin piece.");
	}
	@Override
	public void selectDestiny(int i, int j) {
		status.append("You have selected (" + i + ", " + j + ") as your origin piece.");
		enMovimiento = true;
		status.append("Click on the destination position. ");
	}
	@Override
	public void showDestination(int i, int j){
		status.append("You have selected (" + i + ", " + j + ") as your destination piece.");
		enMovimiento = false;
	}

	@Override
	public void makeAIMove(Piece p) {
		makeAutoMove(ai, "inteligente", p);
		
	}

	@Override
	public void makeRandomMove(Piece p) {
		makeAutoMove(random, "aleatorio", p);		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		this.turn = turn;
		this.moves ++;
		
		// TODO Auto-generated method stub
		if(getMode(turn) == Main.PlayerMode.AI){
			SwingUtilities.invokeLater(new Runnable(){
				public void run(){
					c.makeMove(ai);
				}
			});
		} else if (getMode(turn) == Main.PlayerMode.RANDOM) {
			SwingUtilities.invokeLater(new Runnable(){
				public void run(){
					c.makeMove(random);
				}
			});
		}
		
		repaintBoard(board);
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);		
	}
	
	public void onInfo(String msg){
		JOptionPane.showMessageDialog(null, msg, "Informaci��n", JOptionPane.INFORMATION_MESSAGE);
	}
}
