package es.ucm.fdi.tp.practica6.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;

import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRules;
import es.ucm.fdi.tp.practica6.grafica.BoardUI.StatusListener;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class AtaxxGraphicalPlayer extends BoardUI.GraphicalPlayer {

	private int lastRow; 
	private int lastCol; 
	//private StatusListener list;
	
	public void deseleccionar(){
		lastRow = -1;
		lastCol = -1;
	}
	
	@Override
	public void clickedInCell(int row, int col, Piece turn, Piece clicked) {

			Piece obs = new Piece("*");
				if (lastRow != -1) {
					if (row != lastRow || col != lastCol) {
		
						//list.showDestination(row, col);
						move = new AtaxxMove(lastRow, lastCol, row, col, turn);
						lastRow = -1;
						lastCol = -1;
						
					} else {
						//list.selectOrigen();
					}
		
					// Si no tenemos ninguna seleccionada y seleccionamos una ficha de
					// que es su turno
				} else if (lastRow == -1 && clicked.equals(turn) ) {
					
					lastRow = row;
					lastCol = col;
					//list.selectDestiny(lastRow, lastCol);
				} else {

				}
			}

}

