package es.ucm.fdi.tp.practica5.grafica;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**
 * clase que sirve para dar color a las piezas y darles formas
 * */
public class Square extends JLabel{
	/**fila y columna de cada square*/
	private int row, col;

	/**
	 * constructor 
	 * @param row
	 *        la fila de la casilla donde est�� el square
	 * @param col
	 *        la columna de la casilla donde est�� el square
	 *  */
	public Square(int row, int col) {
		this.row = row;
		this.col = col;
	}
	
	/**
	 * devuelve la fila de square
	 * */
	public int getRow(){
		return this.row;
	}
	
	/**
	 * devuelve la columna de square*/
	public int getCol(){
		return this.col;
	}
}
