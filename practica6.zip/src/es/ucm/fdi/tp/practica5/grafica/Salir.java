package es.ucm.fdi.tp.practica5.grafica;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**
 * panel que nos permite salir del juego o reiniciar un juego*/
public class Salir extends JPanel {

	/**JButton que nos permite salir del juego*/
	private JButton btnQuit;
	/**JButton que nos permite reiniciar un juego si estamos en vista ��nica*/
	private JButton btnRes;
	/**Controlador del juego que controla el juego*/
	private Controller c;
	
	/**
	 * inicializa los componentes
	 * @param c
	 *        controlador que nos permite preguntar a usuario si est�� seguro de querer salir del juego
	 * @param turn 
	 *         el siguiente jugador a jugar
	 * @param pm
	 *         HashMap donde la clave es una pieza y el valor es el tipo de jugador de esa pieza
	 * */
	public void initComponent(final Controller c,final Piece viewPiece, Piece turn, 
			final HashMap<Piece, Main.PlayerMode> pm){
		this.c = c;
		btnQuit = new JButton("Quit");
		add(btnQuit);
		 btnQuit.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	 
		    	int n = JOptionPane.showConfirmDialog(null, "Are you sure?", "Quit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		    	
		    	if(n == 0){
		    		c.stop();
		    		System.exit(0);
		    	}
		    	}
		   	});
		 
		if(viewPiece == null){
			btnRes = new JButton("Restart");
			add(btnRes);
			 btnRes.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	c.restart();
		    	}
		   	});
				if(pm.get(turn) !=(Main.PlayerMode.MANUAL)){
					btnRes.setEnabled(false);
				}
		}
	}
	
	/**
	 * actualiza el panel
	 * @param pm
	 *          HashMap donde la clave es una pieza y el valor es el tipo de jugador de la pieza
	 * @param turn 
	 *          el siguiente jugador a jugar
	 * @param viewPiece
	 *          nos informa si estamos en vantana ��nica o ventanas m��ltiples*/
	public void actualiza(final HashMap<Piece, Main.PlayerMode> pm, Piece turn,Piece viewPiece){
		if(viewPiece == null){
			if(pm.get(turn) != Main.PlayerMode.MANUAL)
			btnRes.setEnabled(false);
		}else
			return;
	}
}
