package es.ucm.fdi.tp.practica6.grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**
 * Es la panel derecha, donde podemos elegir el color de la pieza, el modo de un jugador, 
 * y podemos saber si un jugador puede hacer un movimiento aleatorio o un movimiento 
 * inteligente
 * */
public class PanelDer extends JPanel {
	
	
	/**JPanel que sirve para hacer el cambio del color de las piezas*/
	private PieceColor pieceColor;
	/**JPanel que sirve para hacer el cambio del tipo del jugador*/
	private PlayerMode playerMode;
	/**JPanel que sirve para hacer un movimiento autom��tico*/
	private AutomaticMove move;
	/**JPanel con opciones de salir del juego o reiniciar un juego*/
	private Salir salir;
	/**Interfaz de escuchadores*/
	private SettingListener list;
	/**Booleano que indica si hay jugador inteligente*/
	private boolean hasAi;
	/**Booleano que indica si hay jugador aleatorio*/
	private boolean hasRandom;
	/**Hashmap que relaciona cada jugador con un color*/
	private HashMap<Piece, Color> pc = new HashMap<Piece, Color>();
	/**Hashmap que relaciona cada jugador con su tipo*/
	private HashMap<Piece, Main.PlayerMode> pm = new HashMap<Piece, Main.PlayerMode>();
	
	/**
	 * constructor
	 * */
	  public PanelDer(SettingListener list, HashMap<Piece, Color> pc, HashMap<Piece, Main.PlayerMode> pm,
			  boolean hasAi, boolean hasRandom) {
		  this.list = list;
		  this.pc = pc;
		  this.pm = pm;
		  this.hasAi = hasAi;
		  this.hasRandom = hasRandom;
	    }
	  
	  /**
	   * lista de listener
	   * */
	  public interface SettingListener{
		  /**
		   * permite cambiar el color de una pieza
		   * @param p
		   *        la pieza que queremos cambiar el color
		   * @param c
		   *        el color que queremos dar a la pieza
		   * */
			public void ColorChangeChoose(Piece p, Color c);
			  /**
			   * permite cambiar el modo de un jugador
			   * @param p
			   *        la pieza que queremos cambiar el modo de juego
			   * @param m
			   *        el modo de juego que queremos dar a la pieza
			   * */		
			public void PlayerModeChange(Piece p, Main.PlayerMode m);
			/**
			 * genera un movimiento inteligente
			 * @param p
			 *        la pieza que queremos generar un movimiento inteligente
			 **/
			public void makeAIMove(Piece p);
			/**
			 * genera un mobimiento aleatorio
			 * @param p
			 *        la pieza que queremos generar un movimiento aleatorio
			 **/
			public void makeRandomMove(Piece p);
	  }
	  
	  /**
	   * inicializamos los elemntos
	   * @param c
	   *         es el controlador que nos permite infotmar de los errores y preguntar a los jugadores si est��n
	   *         esguros de querer salir el juego o si quiere reiniciar el juego en caso de ventana ��nica
	   * @param viewPiece
	   *         nos dice si est�� en caso de ventana ��nica o ventana m��ltiple
	   * @param pieces
	   *         lista de jugadores
	   * @param list
	   *         lista de listeners que nos permite hacer cambios como cambiar el color
	   * @param turn
	   *          nos informa cu��l es el jugador siguiente a jugar
	   **/  
	  public void initComponents(Controller c, Piece viewPiece, List<Piece> pieces,
			  SettingListener list, Piece turn){
		pieceColor = new PieceColor();
		playerMode = new PlayerMode();
		move = new AutomaticMove();
		salir = new Salir();
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		panel.add(pieceColor);
		pieceColor.setTit();
		pieceColor.setBoton(pieces,list);
		
		panel.add(playerMode);
		playerMode.setTitulo();
		playerMode.initComponent(pieces, list, hasRandom, hasAi);
		
		
		panel.add(move);
		move.setTit();
		move.initComponent(pm,list, turn, hasRandom, hasAi);
		
		
		panel.add(salir);
		salir.initComponent(c,viewPiece, turn, pm);
		
		add(panel);
		
	}
	  /**
	   * Actualiza los paneles
	   * @param pm
	   *         HashMap donde la clave es una pieza y el valor es un modo de juego
	   * @param turn
	   *         el siguiente jugador a jugar
	   * @param viewPiece
	   *         la pieza que nos dice a qui��n pertenece la ventana
	   **/
	  public void actualiza(HashMap<Piece, Main.PlayerMode> pm, Piece turn, Piece viewPiece){
		  this.pm = pm;
		  move.actualiza(pm, turn, hasRandom, hasAi);
		  salir.actualiza(pm, turn, viewPiece);
	  }
}
