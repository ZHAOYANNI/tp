package es.ucm.fdi.tp.practica6.net;

import java.awt.BorderLayout;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.JFrame;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.control.commands.Command;
import es.ucm.fdi.tp.basecode.bgame.control.commands.PlayCommand;
import es.ucm.fdi.tp.basecode.bgame.control.commands.QuitCommand;
import es.ucm.fdi.tp.basecode.bgame.control.commands.RestartCommand;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica6.ataxx.ChatMessage;
import es.ucm.fdi.tp.practica6.responses.Response;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
/**
 * inicia el juego como un cliente*/
public class Client extends Controller implements Observable<GameObserver>{
	private static final Logger log = Logger.getLogger(Server.class.getSimpleName());
	
	/**nombre de host*/
	private String host;
	/**nombre de host*/
	private int port;

	/**una lista de observadores**/
	protected List<GameObserver> observers;

	/**una lista de observadores**/
	private Piece localPiece;
	/**la factoría del juego que está llevando a cabo*/
	private GameFactory gameFactory;
	/**crea una conección entre el servidor y el cliente*/
	private Connection connectionToServer;

	/**indica si el juego está terminado*/
	private boolean gameOver;
	/**crea un chat antes de empezar el juego*/
	private GraphicalConsole chat;
	

	/**el constructor
	 * @param host
	 *        el nombre de host
	 * @param port
	 *        el número del puerto que quiere conectar el jugador*/
	public Client(String host, int port) throws Exception{
		super(null, null);
		this.host = host;
		this.port = port;
		this.observers = new ArrayList<GameObserver>();
		this.gameOver = true;
		connect();
	}
	
	/**devuelve la factoría del juego
	 * @return devuelve la factoría*/
	public GameFactory getGameFactory(){
		return gameFactory;
	}
	
	/**devulve la pieza que usa el cliente
	 * @return la pieza que usa el cliente*/
	public Piece getPlayerPiece(){
		return localPiece;
	}
	
	/**devulve la pieza que usa el cliente
	 * @return la pieza que usa el cliente*/
	public Connection getConnection(){
		return connectionToServer;
	}
	
	/**añade un observador del juego a la lista de observadores
	 * @param o 
	 *        el observador que vamos a añadir*/
	public void addObserver(GameObserver o){
		observers.add(o);
	}
	
	/**elimina un observador de la lista de observadores
	 * @param o
	 *        el observador que vamos a eliminar*/
	public void removeObserver(GameObserver o){
		int i = observers.indexOf(o);
		observers.remove(i);
	}
	
	@Override
	public void makeMove(Player p){
		forwardCommand(new PlayCommand(p));
	}
	
	@Override
	public void stop(){
		forwardCommand(new QuitCommand());
	}
	
	@Override
	public void restart(){
		forwardCommand(new RestartCommand());
	}
	

	/**envia un comando al servidor
	 * @param cmd
	 *        el comando que vamos a enviar*/
	private void forwardCommand(Command cmd){
		if(!gameOver){
			try{
			connectionToServer.sendObject(cmd);
			} catch(IOException e){
				log.severe("Error.");
			}//Send cmd to the server
		}
	}
	
	/**conecta un cliente al servidor*/
	private void connect() throws Exception{
		connectionToServer = new Connection(new Socket(host, port));
		connectionToServer.sendObject("Connect");
		
		
		Object response = connectionToServer.getObject(); 
				  								//Si es un Exception en ontces la lanzamos.
												//En ese caso el serer ha rechazado la petici�?.
		if(response instanceof Exception){
			throw (Exception)response;
		}
		
		
		try{
			gameFactory = (GameFactory) connectionToServer.getObject();//Estas cosas las cogemos del object que nos manda el server
			localPiece = (Piece) connectionToServer.getObject();
				
			
		} catch(Exception e){
			throw new GameError("Unknown server response " + e.getMessage());
		}
		
	}
	
	/**
	 * empieza el juego*/
	public void start(){
		
		chat = new GraphicalConsole("Chat", this, localPiece);
		displayInFrame(chat);
		this.observers.add(new GameOver());
		gameOver = false;
		while(!gameOver){
			try{
				
				Object obj = connectionToServer.getObject();
				
				if(obj instanceof Response){
					Response r = (Response)obj;
					for(GameObserver o: observers){
						r.run(o);
					}
				} else if(obj instanceof ChatMessage){
					ChatMessage s = (ChatMessage)obj;
					chat.showText(s);
				}
				
			}catch(ClassNotFoundException | IOException e){
				
			}
		}
	}
	

	/**clase que implemente GameObserver y sólo sobreescribe la función onGameOver*/
	private class GameOver implements GameObserver{

		@Override
		public void onGameStart(Board board, String gameDesc,
				List<Piece> pieces, Piece turn) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onGameOver(Board board, State state, Piece winner) {
			gameOver = true;
			try{
				stop();
				connectionToServer.stop();
				forwardCommand(new QuitCommand());
			}catch(IOException e){
				log.severe("Error.");
			}
			
		}

		@Override
		public void onMoveStart(Board board, Piece turn) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onMoveEnd(Board board, Piece turn, boolean success) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onChangeTurn(Board board, Piece turn) {
			// TODO Auto-generated method stub
	
		}

		@Override
		public void onError(String msg) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	/**crea una ventana para el chat
	 * @param jp
	 *        JPanel donde añadiremos las cosas*/
	 private static void displayInFrame(JPanel jp) {
	        JFrame jf = new JFrame("Chat");
	        jf.setLayout(new BorderLayout());
	        jf.setSize(600, 400);
	        jf.setLocationRelativeTo(null);
	        jf.add(jp);
	        jf.setVisible(true);
	  }
}
