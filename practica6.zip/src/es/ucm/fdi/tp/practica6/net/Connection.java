package es.ucm.fdi.tp.practica6.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**clase que conecta el servidor con el cliente*/
public class Connection {

	/**el socket*/
	private Socket s;
	/**para enviar los objetos serializados*/
	private ObjectOutputStream out;
	/**para recibir los objetos serializados*/
	private ObjectInputStream in;
	
	/**constructor
	 * @param s
	 *        el socket que necesitamos para establecer una coneccion entre el servidor
	 *        y el cliente*/
	public Connection (Socket s) throws IOException{
		this.s = s;
		this.out = new ObjectOutputStream(s.getOutputStream());
		this.in = new ObjectInputStream(s.getInputStream());
	}
	
	/**enviar un objeto
	 * @param o
	 *        el objeto que vamos a enviar*/
	public void sendObject(Object o) throws IOException{
		out.writeObject(o);
		out.flush();
		out.reset();
	}
	
	/**recibir un objeto
	 * */
	public Object getObject() throws ClassNotFoundException, IOException{
		return in.readObject();
	}
	
	/**detiene la coneccion*/
	public void stop() throws IOException{
		s.close();
	}
}