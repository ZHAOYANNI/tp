package es.ucm.fdi.tp.practica6.net;

import javax.swing.*;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.*;
import es.ucm.fdi.tp.practica6.ataxx.ChatMessage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * A graphical console
 */
public class GraphicalConsole extends JPanel {

	/**el nombre de la ventana*/
    protected String name;
    /**indica a cu��l cliente pertenece esta ventana*/
    private Client c;
    /**indica cual pieza utiliza el jugaor*/
    private Piece p;

    private JScrollPane jspOutput;
    /**donde escribimos el mensaje que queremos enviar*/
    private JTextField jtInput;
    /**donde escribimos el mensaje que queremos enviar*/
    private JTextArea jtaOutput;

    /**
     * Creates a new graphical console
     */
    public GraphicalConsole(String name, Client c, Piece p) {
        initComponents();
        this.name = name;
        this.c = c;
        this.p = p;
    }

    @Override
    public String getName() {
        return name;
    }

    /**
     * Writes something in the output area. Automatically adds
     * a newline right after it.
     *
     * @param text to write; to generate intermediate newlines, use "\n".
     */
    public void showText(ChatMessage msg) {
        jtaOutput.append(msg.getPiece() + ": " + msg.getText() + "\n");
        // scrolls to display the last line written
        Point lastPoint = new Point(0,
                (int) jtaOutput.getSize().getHeight() - 1);
        jspOutput.getViewport().setViewPosition(lastPoint);
    }


    /**
     * Closes this window (and all others).
     */
    public void closeWindow() {
        System.exit(0);
    }

    /**
     * Process a text-event (text written + enter or clicked on "send")
     */
    private void processTextEvent() {
        String text = jtInput.getText();
        handleTextEntry(text);
        jtInput.setText("");
    }

    /**recibe el mensaje
     * @param text 
     *        el mensaje recibido*/
    protected void handleTextEntry(String text) {
        // by default, do nothing
    	try {
    		ChatMessage msg = new ChatMessage(text, this.p);
			c.getConnection().sendObject(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    /**
     * this[BorderLayout]
     *           jtInput jbConfirm
     *           jspOutput
     *               jtaOutput
     */
    private void initComponents() {
        GridBagConstraints gridBagConstraints;

        jtInput = new JTextField();
        JButton jbConfirm = new JButton();
        jspOutput = new JScrollPane();
        jtaOutput = new JTextArea();

        setLayout(new GridBagLayout());

        jtInput.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                processTextEvent();
            }
        });
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new Insets(3, 3, 3, 3);
        add(jtInput, gridBagConstraints);

        jbConfirm.setText("  !  ");
        jbConfirm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                processTextEvent();
            }
        });
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(3, 3, 3, 3);
        add(jbConfirm, gridBagConstraints);

        jtaOutput.setColumns(20);
        jtaOutput.setRows(5);
        jtaOutput.setFont(new Font("monospaced", Font.PLAIN, 10));
        jtaOutput.setEditable(false);
        jspOutput.setViewportView(jtaOutput);

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = GridBagConstraints.BOTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new Insets(3, 3, 3, 3);
        add(jspOutput, gridBagConstraints);
    }
}