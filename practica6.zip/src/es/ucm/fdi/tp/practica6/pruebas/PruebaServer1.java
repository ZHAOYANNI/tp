package es.ucm.fdi.tp.practica6.pruebas;

import es.ucm.fdi.tp.practica6.grafica.Main;

public class PruebaServer1 {
	
	public static void main(String[] args) {
			String[] as = { "-am", "server", "-g", "cn", "-o", "1", "-d", "5x5", "-p","X,O" };
			Main.main(as);
		}

}
