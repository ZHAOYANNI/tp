package es.ucm.fdi.tp.practica6.grafica;

import es.ucm.fdi.tp.practica6.attt.AdvancedTTTMove;
import es.ucm.fdi.tp.practica6.bgame.model.Board;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.grafica.BoardUI.StatusListener;

/**Crea un jugador manual del juego Advanced Tic-Tac-Toe*/
public class AtttGraphicalPlayer extends BoardUI.GraphicalPlayer {
	/**Fila de la ��ltima pieza seleccionada*/
	private int lastRow = -1;
	/**Columna de la ��ltima pieza seleccionada*/
	private int lastCol = -1;
	/**Cuenta el n��mero de piezas de un jugador*/
	private int contPiece = 0;

	/**Deseleccion una pieza
	 * */
	public void deseleccionar(){
		lastRow = -1;
		lastCol = -1;
	}
	@Override
	public void clickedInCell(Board board, int row, int col, Piece turn, Piece clicked,
			StatusListener status) {

		if(contPiece <= 3){ 
			move = new AdvancedTTTMove(lastRow, lastCol, row, col, turn);
			contPiece+=1;
		} else {
			if (lastRow != -1) {
					// Si la pieza que se mueve no es obs/null.
				// Si la casilla a la que movemos no es de la que venimos
				// Si la casilla a la que vamos est?vac闊�
				// Si la casilla a la que vamos est锟� "cerca"
				if (row != lastRow || col != lastCol) {
					move = new AdvancedTTTMove(lastRow, lastCol, row, col, turn);
					lastRow = -1;
					lastCol = -1;
					status.showDestination(row, col);
				} else{
					status.selectOrigen();
				}
	
				// Si no tenemos ninguna seleccionada y seleccionamos una ficha de
				// que es su turno
			} else if (lastRow == -1 || turn.equals(clicked)) {
				lastRow = row;
				lastCol = col;
				status.selectDestiny(lastRow, lastCol);
			}
		}
	}
}
