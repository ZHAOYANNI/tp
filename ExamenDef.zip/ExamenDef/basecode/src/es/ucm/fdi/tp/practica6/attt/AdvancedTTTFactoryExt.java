package es.ucm.fdi.tp.practica6.attt;

import java.lang.reflect.InvocationTargetException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.practica6.attt.AdvancedTTTFactory;
import es.ucm.fdi.tp.practica6.attt.AdvancedTTTRules;
import es.ucm.fdi.tp.practica6.bgame.control.Controller;
import es.ucm.fdi.tp.practica6.bgame.control.Player;
import es.ucm.fdi.tp.practica6.bgame.model.GameObserver;
import es.ucm.fdi.tp.practica6.bgame.model.Observable;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.grafica.AtttGraphicalPlayer;
import es.ucm.fdi.tp.practica6.grafica.GameWindow;
/**Factor��a para crear el juego Advanced Tic-Tac-Toe en vista window. 
 * */
public class AdvancedTTTFactoryExt extends AdvancedTTTFactory {
	private static final long serialVersionUID = 5960871297350559244L;
	
	public AdvancedTTTFactoryExt(){
		super();
	}
	
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {

					String gameDesc = new String("AdvancedTicTAcToe ");
					if(viewPiece != null){
						gameDesc += " (" + viewPiece + ")";
					}
					GameWindow window = new GameWindow(c, new AtttGraphicalPlayer(), 
							viewPiece, random, ai, gameDesc, new AdvancedTTTRules());
					g.addObserver(window);
					window.setTitle(gameDesc);
					window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					window.setSize(600, 400);
					window.setVisible(true);
				}
			});
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
