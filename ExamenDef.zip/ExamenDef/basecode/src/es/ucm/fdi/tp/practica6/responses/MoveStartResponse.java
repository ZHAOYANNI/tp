package es.ucm.fdi.tp.practica6.responses;

import es.ucm.fdi.tp.practica6.bgame.model.Board;
import es.ucm.fdi.tp.practica6.bgame.model.GameObserver;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;

/**respuesta de un moveStart*/
public class MoveStartResponse implements Response{
	/**la tabla donde desarrollamos el juego*/
	private Board board;
	/**el jugador que va a jugar*/
	private Piece turn;
	
	/**constructor
	 * @param board 
	 *        la tabla donde desarrollamos el juego
	 * @param turn 
	 *        el jugador que va a jugar*/
	public MoveStartResponse(Board board, Piece turn){
		this.board = board;
		this.turn = turn;
	}
	
	@Override
	public void run(GameObserver o){
		o.onMoveStart(board, turn);
	}
}
