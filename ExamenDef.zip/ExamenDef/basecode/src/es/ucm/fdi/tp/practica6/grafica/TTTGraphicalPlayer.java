package es.ucm.fdi.tp.practica6.grafica;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.HashMap;

import es.ucm.fdi.tp.practica6.bgame.model.Board;
import es.ucm.fdi.tp.practica6.bgame.model.GameRules;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.connectn.ConnectNMove;
import es.ucm.fdi.tp.practica6.grafica.BoardUI.StatusListener;
import es.ucm.fdi.tp.practica6.grafica.Main.PlayerMode;

/**crea un jugador manual para el juego Tic-Tac-Toe*/
public class TTTGraphicalPlayer extends BoardUI.GraphicalPlayer{

	@Override
	public void clickedInCell(Board board, int row, int col, Piece turn,
			Piece clicked, StatusListener status) {
		if(board.getPosition(row, col) == null){
			status.showDestination(row, col);
			move = new ConnectNMove(row, col, turn);
		}else{
			status.showError();
			status.selectOrigen();
		}
		
	}
} 
