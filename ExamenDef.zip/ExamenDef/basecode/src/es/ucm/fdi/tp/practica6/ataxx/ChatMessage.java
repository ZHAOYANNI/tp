package es.ucm.fdi.tp.practica6.ataxx;

import es.ucm.fdi.tp.practica6.bgame.model.Piece;

/**muestra los mensajes en una ventana de chat*/
public class ChatMessage implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	/**el texto a enviar*/
	private String text;
	/**el jugador que va a mandar el mensaje */
	private Piece p;
	
	/**constructor
	 * @param text 
	 *        el mensaje a enviar
	 * @param p
	 *        el jugador que ha mandado el mensaje*/
	public ChatMessage(String text, Piece p){
		this.text = text;
		this.p = p;
	}
	
	/**devuelve el mensaje que a va a ser enviado
	 * @return el mensaje que va a ser enviado*/
	public String getText(){
		return this.text;
	}
	
	/**@return el jugador que va a mandar el mensaje*/
	public Piece getPiece(){
		return this.p;
	}

}
