package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.practica5.bgame.model.GameObserver;
import es.ucm.fdi.tp.practica5.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;
/**
 * panel donde permite cambiar el modo de los jugadores
 * */
public class PlayerMode extends JPanel{
    
	/**el jugador que queremos cambiar su tipo*/
	private Piece p;
	/**indica el tipo del jugador que ha elegido*/
	private Main.PlayerMode m;

	/**Constructor*/
	public PlayerMode(){
		super();
	}
	
	/**configura el t��tulo*/
	public void setTitulo(){
		setBorder(new TitledBorder(null, "Player Modes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
	
	/**
	 *  * inicializa los comonentes
	 * @param pieces
	 *          lista de jugadores
	 * @param list
	 *          lista de listeners
	 * @param hasRandom
	 *          booleano que nos informa si tiene jugador aleatorio
	 * @param hasAi
	 *          booleano que nos informa si tiene jugador inteligente*/
	public void initComponent(final List<Piece> pieces, SettingListener list, 
			boolean hasRandom, boolean hasAi){
		Vector<Piece> v = new Vector();
		for(int i =0; i < pieces.size();i++){
			v.add(pieces.get(i));
		}
		
		final JComboBox<Piece> pieceChooser = new JComboBox();
		pieceChooser.setModel(new DefaultComboBoxModel(v));
		add(pieceChooser);
		pieceChooser.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	 	p = (Piece)pieceChooser.getSelectedItem();
		     }
		   	});
		Vector<Main.PlayerMode> x = new Vector();
		x.add(Main.PlayerMode.MANUAL);
		if(hasRandom)
			x.add(Main.PlayerMode.RANDOM);
		if(hasAi)
			x.add(Main.PlayerMode.AI);
		
		final JComboBox<Main.PlayerMode> modeChooser = new JComboBox();
		modeChooser.setModel(new DefaultComboBoxModel(x));
		add(modeChooser);
		modeChooser.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	  m = (Main.PlayerMode)modeChooser.getSelectedItem();
		     }
		   	});
		
		JButton btnSet = new JButton("Set");
		add(btnSet);
		btnSet.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	list.PlayerModeChange(p, m);
		    	}
		   	});
	}
}
