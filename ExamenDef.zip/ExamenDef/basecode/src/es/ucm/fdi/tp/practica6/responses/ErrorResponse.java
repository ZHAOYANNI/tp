package es.ucm.fdi.tp.practica6.responses;

import es.ucm.fdi.tp.practica6.bgame.model.GameObserver;

/**respuesta a un error*/
public class ErrorResponse implements Response{
	/**el mensaje que queremos informar al jugador*/
	private String msg;
	
	/**Constructor
	 * @param msg
	 *        un mensaje que queremos informar al jugador*/
	public ErrorResponse(String msg){
		this.msg = msg;
	}
	
	@Override
	public void run(GameObserver o){
		o.onError(msg);
	}
}
