package es.ucm.fdi.tp.practica5.attt;

import java.util.ArrayList;
import java.util.Scanner;

import es.ucm.fdi.tp.practica5.bgame.control.ConsolePlayer;
import es.ucm.fdi.tp.practica5.bgame.control.Player;
import es.ucm.fdi.tp.practica5.bgame.model.GameMove;
import es.ucm.fdi.tp.practica5.bgame.model.GameRules;
import es.ucm.fdi.tp.practica5.connectn.ConnectNMove;
import es.ucm.fdi.tp.practica5.ttt.TicTacToeFactory;

/**
 * A factory for Advanced Tic-Tac-Toe. See {@link AdvancedTTTRules} for the game
 * rules.
 * 
 * <p>
 * Factoria para el juego Tic-Tac-Toe avanzado. Vease {@link AdvancedTTTRules}
 * para ver las reglas del juego.
 */
public class AdvancedTTTFactory extends TicTacToeFactory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public GameRules gameRules() {
		return new AdvancedTTTRules();
	}

	/*
	@Override
	public Player createConsolePlayer() {
		ArrayList<GameMove> possibleMoves = new ArrayList<GameMove>();
		possibleMoves.add(new AdvancedTTTMove());
		return new ConsolePlayer(new Scanner(System.in), possibleMoves);
	}
   */
	
	@Override
	public Player createRandomPlayer() {
		return new AdvancedTTTRandomPlayer();
	}

}
