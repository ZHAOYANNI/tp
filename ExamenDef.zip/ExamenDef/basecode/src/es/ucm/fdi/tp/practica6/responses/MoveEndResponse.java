package es.ucm.fdi.tp.practica6.responses;

import es.ucm.fdi.tp.practica6.bgame.model.Board;
import es.ucm.fdi.tp.practica6.bgame.model.GameObserver;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;

/**respuesta de un moveEnd*/
public class MoveEndResponse implements Response{
	/**la tabla donde desarrollamos el juego*/
	private Board board;
	/**el jugador que va a jugar*/
	private Piece turn;
	/**indica si ha tenido ��xito*/
	private boolean success;
	
	/**constructor
	 * @param board 
	 *        la tabla donde desarrollamos el juego
	 * @param turn 
	 *        el jugador que va a jugar
	 * @param success
	 *        indica si ha tenido ��xito*/
	public MoveEndResponse(Board board, Piece turn, Boolean success){
		this.board = board;
		this.turn = turn;
		this.success = success;
	}
	
	@Override
	public void run(GameObserver o){
		o.onMoveEnd(board, turn, success);
	}
}
