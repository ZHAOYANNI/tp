package es.ucm.fdi.tp.practica6.responses;

import java.io.Serializable;
import java.util.List;

import es.ucm.fdi.tp.practica6.bgame.model.Board;
import es.ucm.fdi.tp.practica6.bgame.model.GameObserver;
import es.ucm.fdi.tp.practica6.bgame.model.Piece;


/**respuesta de un gameStart*/

public class GameStartResponse implements Response, Serializable{
	
	private static final long serialVersionUID = 2L;
	/**la tabla donde desarrollamos el juego*/
	private Board board;
	/**la descripci��n del juego*/
	private String gameDesc;
	/**la lista de jugadores*/
	private List<Piece> pieces;
	/**el siguiente jugador a jugar*/
	private Piece turn;
	
	/**
	 * constructor
	 * @param board
	 *        la tabla donde desarrollamos el juego
	 * @param gameDesc
	 *        la descripci��n del juego
	 * @param pieces
			  la lista de jugadores
	   @param turn 
	          el siguiente jugador a jugar
	 * */
	public GameStartResponse(Board board, String gameDesc, List<Piece> pieces, Piece turn){
		this.board = board;
		this.gameDesc = gameDesc;
		this.pieces = pieces;
		this.turn = turn;
	}
	
	@Override
	public void run(GameObserver o){
		o.onGameStart(board, gameDesc, pieces, turn);
	}
}
