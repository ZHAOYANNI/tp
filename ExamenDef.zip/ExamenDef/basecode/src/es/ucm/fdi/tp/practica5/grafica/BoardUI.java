
package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import es.ucm.fdi.tp.practica5.bgame.control.Controller;
import es.ucm.fdi.tp.practica5.bgame.control.Player;
import es.ucm.fdi.tp.practica5.bgame.model.Board;
import es.ucm.fdi.tp.practica5.bgame.model.GameMove;
import es.ucm.fdi.tp.practica5.bgame.model.GameRules;
import es.ucm.fdi.tp.practica5.bgame.model.Piece;
/**
 * JPanel donde contiene el tablero donde va a desarrollar el juego
 * */
public class BoardUI extends JPanel {
	 
	private static final long serialVersionUID = 1L;
	/**una matriz de JLabler donde situaremos piezas*/
	protected JLabel[][] squares;
	/**la tabla que necesitamos para jugar un juego*/
	protected Board board;
	/**lista de jugadores*/
	protected List<Piece> pieces;
	/**el siguiente jugador que toca a jugar*/
	protected Piece turno;
	/**reglas del juego*/
	private GameRules rules;
	/**indica a cu��l jugador pertenece la ventana*/
	protected Piece viewPiece;
	/**el controlador del juego*/
	protected Controller c;
	/**Hashmap que relaciona cada jugador con su color*/
	protected HashMap<Piece, Color>pc;
	/**Hashmap que relaciona cada jugador con su tipo*/
	protected HashMap<Piece, Main.PlayerMode>pm;
	/**escucha el tablero*/
	protected StatusListener statusListener;
	/**un jugador manual*/
	protected GraphicalPlayer graphicalPlayer;

	/**clase que extiende de Player, crea un jugador manual*/
	public abstract static class GraphicalPlayer extends Player {
		/**el movimiento que va a realizar*/
		protected GameMove move = null;
		/**
		 * Handles mouse-clicks in board cells. Disabled for non-manual players
		 * @param row clicked
		 * @param col clicked
		 * @param turn of current player
		 * @param clicked piece
		 * @return string to display to user to explain what is expected
		 */
		public abstract void clickedInCell(Board board, int row, int col, Piece turn, Piece clicked,
				StatusListener status);
		
		/**indica si el movimiento es v��lido o no
		 * @return true si el movimiento es v��lido. */
		public boolean hasValidMove(List<? extends GameMove> moves) {
			if (move == null) return false;
			for (GameMove m : moves) {
				if (m.toString().equals(move.toString())) return true;
			}
			return false;
		}
		@Override
		public GameMove requestMove(Piece p, Board board, List<Piece> pieces,
				GameRules rules) {
			return move;
		}
		/**pone el movimiento en null*/
		public void resetMove() {
			move = null;
		}
	}
	
	/**
	 * Interfaz de listener
	 * */
	public interface StatusListener{
		/**
		 * pide al jugador elige una pieza de orige
		 * */
		public void selectOrigen();
		/**
		 * pide al jugadore elige una posici��n como destino
		 * @param i
		 *        la fila de la ��ltima pieza elegida
		 * @param j
		 *        la columna de la ��ltima pieza elegida
		 * */
		public void selectDestiny(int i, int j);
		/**
		 * demuestra el destino elegido
		 * @param i
		 *        la fila de la casilla elegida
		 * @param j
		 *        la columna de la casilla elegida*/
		public void showDestination(int i, int j);
		/**
		 * informa el turno de jugador
		 * @param p
		 *       el siguiente jugador a jugar
		 **/
		public void changeTurn(Piece p);
		/**Informa al jugador que el movimiento no est�� permitido*/
		public void showError();
	}
	 
	/**
	 * Constructor
	 * @param pc
	 *        hashmap que relaciona cada jugador con su color
	 * @param pm
	 *        hashmap que relaciona cada jugador con su tipo
	 * @param c
	 *        controlador del juego
	 * @param list
	 *        statusListener que muestra mensajes en el statusPanel
	 * @param graphicalPlayer 
	 *        jugador manual de cada juego
	 * @param rules
	 *        reglas del juego que est�� llevando a cabo
	 * */
	public BoardUI(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm, Controller c, 
			StatusListener list, Piece viewPiece, GraphicalPlayer graphicalPlayer, GameRules rules) {
		this.pc = pc;
		this.pm = pm;
		this.c = c;
		this.rules = rules;
		this.statusListener = list;
		this.viewPiece = viewPiece;
		this.graphicalPlayer = graphicalPlayer;
	}

	/**inicia la lista de jugadores
	 * @param pieces
	 *        la lista de jugadores*/
	public void setPieces(List<Piece> pieces) {
		this.pieces = pieces;
	}
	
	/**
	 * iniciar el atributo turno
	 * @param turno
	 *        el siguiente jugador a jugar*/
	public void setTurno(Piece turno) {
		this.turno = turno;
		statusListener.changeTurn(turno);
		if (viewPiece == null || turno.equals(viewPiece)){
			statusListener.selectOrigen();
		}
		
	}
	
	/**
	 * Inicializa el tablero
	 * @param board
	 *          si el board no ha cambiado, actualizamos, en otro caso, copiamos el board
	 **/
	public void setBoard(Board board) {
		if (board == null) throw new IllegalArgumentException();
		if (board != this.board) {
			removeAll();
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
			for (int i = 0; i < board.getRows(); i++) {
				for (int j = 0; j < board.getCols(); j++) {
					Square s = new Square(i, j);
					s.addMouseListener(new MouseAdapter() {

						@Override
						public void mouseClicked(MouseEvent e) {
							if (viewPiece != null && !viewPiece.equals(turno)) return;
							graphicalPlayer.clickedInCell(board,s.getRow(), s.getCol(), turno,
									board.getPosition(s.getRow(), s.getCol()), BoardUI.this.statusListener);
							if (graphicalPlayer.hasValidMove(rules.validMoves(BoardUI.this.board, pieces, turno))) {
								c.makeMove(graphicalPlayer);
							
								graphicalPlayer.resetMove();
							} else {
								return;
							}
						}
					});
					squares[i][j] = s;
					paintSquare(board.getPosition(i, j), i, j);
					add(s);
				}
			}
			update();
		} else {
			update();
		}
		if(turno == null)
			setTurno(pieces.get(0));
	}

	/**
	 * Actualizamos el tablero
	 * */
	public void update() {
																				
		for (int i = 0; i < board.getRows(); i++) {
			for (int j = 0; j < board.getCols(); j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
		
	}

	/**
	 * Pinta un cuadrado para representar una pieza
	 * @param p
	 *        la pieza que vamos pintar
	 * @param i
	 *        la fila de la pieza
	 * @param j
	 *        la columna de la pieza*/
	public void paintSquare(Piece p, int i, int j) {

		Piece obs = new Piece("*");

		if(p!=null && !p.equals(obs)){
			squares[i][j].setBackground(pc.get(p));
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else {
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		squares[i][j].setOpaque(true);
	}
}