package es.ucm.fdi.tp.practica6.ataxx;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import es.ucm.fdi.tp.practica6.bgame.model.*;
import es.ucm.fdi.tp.practica6.bgame.model.Game.State;

/**
* Reglas del juego Ataxx.
* <ul>
* <li>El juego se juega en un tablero NxN (con N>=5, N impar).</li>
* <li>El n�mero de jugadores est?entre 2 y 4.</li>
* <li>Los jugadores juegan en el orden proporcionado, cada uno moviendo
*  una de sus piezas a una casilla libre a una o dos casillas de distancia.
*  La partida acaba cuando nadie puede moverse o el tablero est?lleno.
*  El ganador es el que tenga m�s piezas en el momento en el que acaba la partida.
*  En caso de que dos o m�s jugadores tenga el m�ximo n�mero de fichas al acabar la partida,
*   �sta termina en empate.
* </li>
* </ul>
*
*/
public class AtaxxRules implements GameRules{

	private int dim;
	private int numObst;
	protected final Pair<State, Piece> gameInPlayResult = new Pair<State, Piece>(State.InPlay, null);
	
	/**
	 * Constructor de la clase AtaxxRules.
	 * 
	 * @param dim Dimensi�n del tablero.
	 * @param obst N�mero de obst�culos en el tablero.
	 */
	public AtaxxRules(int dim, int obst) {
		if (dim < 5) {
			throw new GameError("Dimensi�n debe ser al menos 5: " + dim);
		} else {
			if(dim%2 == 1){
				this.dim = dim;
			}else{
				throw new GameError("Dimensi�n debe ser un n�mero impar: " + dim);
			}
		}
		numObst = obst;
	}
	/**
	 * Devuelve una string con la descripci�n del juego.
	 * 
	 * @return Una String con la descripci�n de la partida actual.
	 */
	public String gameDesc(){
		return "Ataxx " + dim + "x" + dim + " n�mero de obst�culos: " + numObst;
	}
	
	
	/**
	 * Funci�n que crea un tablero con las caracter�sticas correspondientes(dimensi�n, fichas y obst�culos).
	 * 
	 * @return Devuelve el tablero que se ha creado.
	 */
	public Board createBoard(List<Piece> pieces) {
		Board board = new FiniteRectBoard(dim, dim);
		board.setPosition(0, 0, pieces.get(0));
		board.setPosition(0, dim-1, pieces.get(1));
		board.setPosition(dim-1, 0, pieces.get(1));
		board.setPosition(dim-1, dim-1, pieces.get(0));
		if(pieces.size() >= 3){
			board.setPosition((dim-1)/2,0,pieces.get(2));
			board.setPosition((dim-1)/2,dim-1,pieces.get(2));
			if(pieces.size()==4){
				board.setPosition(0,(dim-1)/2,pieces.get(3));
				board.setPosition(dim-1,(dim-1)/2,pieces.get(3));
			}
		}
		Piece p = new Piece("*");
		crearObs(board, p);
		return board;
	}
	
	/**
	 * Funci�n que devuelve el jugador que juega el primer turno.
	 * 
	 * @return Devuelve el jugador que juega primero.
	 */
	public Piece initialPlayer(Board board, List<Piece> playersPieces) {
		return playersPieces.get(0);
	}
	
	/**
	 * Funci�n que devuelve la cantidad m�nima de jugadores.
	 * 
	 * @return Entero con la cantidad m�nima de jugadores.
	 */
	public int minPlayers() {
		return 2;
	}
	
	/**
	 * Funci�n que devuelve la cantidad m�xima de jugadores.
	 * 
	 * @return Entero con la cantidad m�xima de jugadores.
	 */
	public int maxPlayers() {
		return 4;
	}
	
	/**
	 * Funci�n que devuelve el estado en el que se encuentra la partida.
	 * Puede devolver las siguientes tres opciones:
	 * 
	 * La partida ha acabado y ha ganado la ficha p.
	 * La partida ha acabado en empate.
	 * La partida no ha acabado.
	 */
	public Pair<State, Piece> updateState(Board board, List<Piece> playersPieces, Piece lastPlayer){
		Piece p;
		if(board.isFull() || nadieMovible(board, playersPieces) || soloQuedaUno(board, playersPieces)){
			p = quienGana(board, playersPieces);
			if(p == null){
				return new Pair<State, Piece>(State.Draw, null);
			}else{
				return new Pair<State, Piece>(State.Won, p);
			}
		}
		return gameInPlayResult;
	}
	
	/**
	 * Funci�n que devuelve el jugador que va despu�s del actual.
	 * 
	 * @return El jugador que va despu�s en la lista al que acaba de jugar.
	 */
	public Piece nextPlayer(Board board, List<Piece> playersPieces, Piece lastPlayer) {
		
		int i = playersPieces.indexOf(lastPlayer);
		i++;
		Piece p = playersPieces.get((i)%playersPieces.size());
		boolean mover = movible(board,p);
		if(mover){
			return p;
		}else{
			while(!mover){
				i++;
				 p = playersPieces.get((i)%playersPieces.size());
				 mover = movible(board,p);
			}
			 return p;
		}				
	}
	
	@Override
	public double evaluate(Board board, List<Piece> playersPieces, Piece turn, Piece p) {
		return 0;
	}

	@Override
	public List<GameMove> validMoves(Board board, List<Piece> playersPieces, Piece p) {
		List<GameMove> moves = new ArrayList<GameMove>();
		
		for (int i = 0; i < board.getRows(); i++) {
			for (int j = 0; j < board.getCols(); j++) {
				if(p.equals(board.getPosition(i, j))){
					for(int x = -2; x < 3; x++){
						for(int y = -2; y < 3; y++){
							if(i+x>=0 && j+y >= 0 && i+x < board.getRows() && j+y < board.getCols()
									&& board.getPosition(i+x, j+y) == null){
								moves.add(new AtaxxMove(i, j, i+x, j+y, p));
								
							}
						}
					}
				}
			}
		}
		return moves;
	}
	
/**
 * Funci�n que devuelve si una ficha se puede mover.
 * 	
 * @param board Tablero sobre el que se desarrolla la partida.
 * 
 * @param row Fila en la que se encuentra la ficha.
 * @param col Columna en la que se encuentra la ficha.
 * 
 * @return Devuelve true si la ficha se puede mover y false si no.
 */
public boolean piezaMovible(Board board, int row, int col){
		
		for(int i = -2; i < 3; i++){
			for(int j = -2; j < 3; j++){
				if(row+i>=0 && col+j>=0 && row+i<board.getRows() && col+j<board.getCols() 
						&& board.getPosition(row + i, col+j) == null)
					return true;
			}
		}
		return false;
	}
	
    /**
     * Funci�n que devuelve si un jugador se puede mover o no.
     * 
     * @param board Tablero sobre el que se desarrolla la partida.
     * 
     * @param p Jugador que queremos saber si puede realizar un movimiento.
     * 
     * @return Devuelve true si el jugador puede realizar alg�n movimiento y false si no.
     */
	public boolean movible(Board board, Piece p){
		
		for(int i = 0; i < dim; i++){
			for(int j = 0; j < dim; j++){
				if( p.equals(board.getPosition(i, j))){
					if(piezaMovible(board, i, j)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	/**
	 * Funci�n que devuelve si nadie se puede mover.
	 * 
	 * @param board Tablero sobre el cual se desarrolla la partida.
	 * 
	 * @param playersPieces Lista de jugadores que est�n jugando.
	 * 
	 * @return Devuelve true si nadie puede realizar un movimiento y false en caso contrario.
	 */
	public boolean nadieMovible(Board board, List<Piece> playersPieces){
		Piece p;
		for(int i = 0; i < playersPieces.size(); i++){
			p = playersPieces.get(i);
			if(movible(board, p))
				return false;
		}
		return true;
	}
	
	/**
	 * Funci�n que devuelve la cantidad de piezas que tiene un jugador.
	 * 
	 * @param board Tablero sobre el que se desarrolla la partida.
	 * 
	 * @param p Jugador cuyas fichas estamos contando.
	 * 
	 * @return Un entero con la cantidad de piezas que tiene el jugador.
	 */
	public int contaPieza(Board board, Piece p){
		int n = 0;
		for(int i = 0; i < dim; i++){
			for(int j = 0; j < dim; j++){
				if(p.equals(board.getPosition(i, j)))
					n++;
			}
		}
		return n;
	}
	
	/**
	 * Funci�n que devuelve qui�n gana la partida.
	 * 
	 * @param board Tablero sobre el cual se desarrolla la partida.
	 * 
	 * @param playersPieces Lista con los jugadores que est�n jugando.
	 * 
	 * @return Devuelve el jugador que ha ganado o null en caso de empate.
	 */
	public Piece quienGana(Board board, List<Piece> playersPieces){
		int max = 0;
		Piece p;
		int cont; 
		Piece gana = null;
		for(int i = 0; i < playersPieces.size(); i++){
			p = playersPieces.get(i);
			cont = contaPieza(board, p);
			if(cont>max){
				max = cont;
				gana = p;
			}
			else if(cont == max){
				gana = null;
			}
		}
		return gana;
	}
	
	/**
	 * Funci�n que comprueba si una casilla vac�a es accesible por un jugador.
	 * 
	 * @param board Tablero sobre el cual se desarrolla la partida.
	 * 
	 * @param f Fila de la casilla en blanco.
	 * @param c Columna de la casilla en blanco.
	 * 
	 * @param p Jugador en cuesti�n.
	 * 
	 * @return True si la casilla es alcanzable por el jugador y false si no.
	 */
	public boolean tieneVecino(Board board, int f, int c, Piece p){
		for(int i = -2; i < 3; i++){
			for(int j = -2; j < 3;j++){
				if(f+i >= 0&& f+i< dim && c+j >=0 && c+j<dim && !(i==0 && j==0)){
					if(p.equals(board.getPosition(f+i, c+j)))
						return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Funci�n que crea los obst�culos del tablero de manera sim�trica.
	 * 
	 * @param board Tablero sobre el que se desarrolla la partida.
	 * 
	 * @param p Pieza especial usada como obst�culo.
	 */
	public void crearObs(Board board, Piece p){
		 Random rand = new Random();	 
		for(int i = 0; i < numObst; i++){
			int row = rand.nextInt((dim/2));
			int col = rand.nextInt((dim/2));
			while(board.getPosition(row,col) != null){
				row = rand.nextInt((dim/2));
				col = rand.nextInt((dim/2));
			}
			board.setPosition(row, col, p);
			board.setPosition(dim-row-1, col, p);
			board.setPosition(row, dim-col-1, p);
			board.setPosition(dim-row-1, dim-col-1, p);
		}
	}
	
	public boolean soloQuedaUno(Board board, List<Piece> playersPieces){
		Piece p;
		int cont = 0;
		for(int i = 0; i < playersPieces.size(); i++){
			p = playersPieces.get(i);
			if(contaPieza(board, p) > 0){
				cont++;
			}
		}
		
		if(cont == 1){
			return true;
		} else {
			return false;
		}
	}
}