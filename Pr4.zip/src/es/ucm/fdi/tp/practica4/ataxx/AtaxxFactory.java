package es.ucm.fdi.tp.practica4.ataxx;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import es.ucm.fdi.tp.basecode.bgame.model.*;
import es.ucm.fdi.tp.basecode.bgame.views.GenericConsoleView;
import es.ucm.fdi.tp.basecode.bgame.control.*;
import es.ucm.fdi.tp.basecode.connectN.ConnectNMove;
import es.ucm.fdi.tp.basecode.connectN.ConnectNRandomPlayer;
import es.ucm.fdi.tp.basecode.connectN.ConnectNRules;
/**
 * Factoria para la creacion de juegos Ataxx. Vease {@link AtaxxRules}
 * para la descripcion del juego.*/
public class AtaxxFactory implements GameFactory{
	private int dim;
	private int numObst;
	
	public AtaxxFactory() {
		this(7,1);
	}
	
	public AtaxxFactory(int dim, int obst) {
		if (dim < 5) {
			throw new GameError("Dimension debe ser al menos 5: " + dim);
		} else {
			if(dim%2 == 1){
				this.dim = dim;
			}else{
				throw new GameError("Dimension debe ser numero impar: " + dim);
			}
		}
		numObst = obst;
	}
	
	@Override
	public GameRules gameRules() {
		return new AtaxxRules(dim, numObst);
	}
	
	@Override
	public Player createConsolePlayer() {
		ArrayList<GameMove> possibleMoves = new ArrayList<GameMove>();
		possibleMoves.add(new AtaxxMove());
		return new ConsolePlayer(new Scanner(System.in), possibleMoves);
	}
	
	@Override
	public Player createRandomPlayer() {
		return new AtaxxRandomPlayer();
	}
	
	@Override
	public Player createAIPlayer(AIAlgorithm alg) {
		return new DummyAIPlayer(createRandomPlayer(), 1000);
	}
	
	/**
	 * Por defecto, hay dos jugadores, X y O.
	 * */
	@Override
	public List<Piece> createDefaultPieces() {
		List<Piece> pieces = new ArrayList<Piece>();
		pieces.add(new Piece("X"));
		pieces.add(new Piece("O"));
		
		return pieces;
	}
	
	@Override
	public void createConsoleView(Observable<GameObserver> g, Controller c) {
		new GenericConsoleView(g, c);
	}
	
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		throw new UnsupportedOperationException("There is no swing view");
	}
}
