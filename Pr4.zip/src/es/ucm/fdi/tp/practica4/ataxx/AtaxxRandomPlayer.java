package es.ucm.fdi.tp.practica4.ataxx;
import java.util.ArrayList;
import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.Utils;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.*;
import es.ucm.fdi.tp.basecode.connectN.ConnectNMove;

/**
 * Un jugador aleatorio para Ataxx
 * 
 */
public class AtaxxRandomPlayer extends Player{
	
	private static final long serialVersionUID = 1L;
	
	@Override
	public GameMove requestMove(Piece p, Board board, List<Piece> pieces, GameRules rules) {
		if (board.isFull() || !movible(board,p)) {
			throw new GameError("El tablero est�� lleno o no hay pieza movible ");
		}
		
		List<GameMove> moves = rules.validMoves(board, pieces, p);
		int i = Utils.randomInt(moves.size());
		return moves.get(i);
		
	}
	
	/*protected GameMove createMove(int row, int col, Piece p) {
		return new AtaxxMove(row, col, p);
	}*/
	
	/**
	 * Funci�n que devuelve si una pieza es movible o no.
	 * 
	 * @param board Tablero sobre el que se desarrolla la partida.
	 * 
	 * @param row Fila en la que se encuentra la pieza.
	 * @param col Columna en la que se encuentra la pieza.
	 * 
	 * @return True si la pieza es movible, false si no.
	 */
	public boolean piezaMovible(Board board, int row, int col){
		
		for(int i = -2; i < 3; i++){
			for(int j = -2; j < 3; j++){
				if(row+i>=0 && col+j>=0 && row+i<board.getRows() && col+j<board.getCols() 
						&& board.getPosition(row + i, col+j) == null)
					return true;
			}
		}
		return false;
	}
	
	/**
	 * Funci�n que devuelve si un jugador puede moverse.
	 * 
	 * @param board Tablero sobre el que se desarrolla la partida.
	 * 
	 * @param p Jugador que queremos saber si puede moverse.
	 * 
	 * @return True si el jugador puede realizar alg�n movimiento y false si no.
	 */
	public boolean movible(Board board, Piece p){
		
		for(int i = 0; i < board.getRows(); i++){
			for(int j = 0; j < board.getCols(); j++){
				if( p.equals(board.getPosition(i, j))){
					if(piezaMovible(board, i, j)){
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Funci�n que comprueba si una casilla vac�a es alcanzable para un jugador.
	 * 
	 * @param board Tablero sobre el cual se realiza la partida.
	 * 
	 * @param f Filla de la casilla vac�a.
	 * @param c Columna de la casilla vac�a.
	 * 
	 * @param p Jugador que queremos saber si puede alcanzar la casilla.
	 * 
	 * @return True si el jugador puede alcanzar la casilla, false si no.
	 */
	public boolean tieneVecino(Board board, int f, int c, Piece p){
	for(int i = -2; i < 3; i++){
		for(int j = -2; j < 3;j++){
			if(f+i >= 0&& f+i< board.getRows() && c+j >=0 && c+j<board.getCols() && !(i==0 && j==0)){
				//if(board.getPosition(f+i, c+j).equals(p))
				if(p.equals(board.getPosition(f+i, c+j)))
					return true;
			}
		}
	}
	return false;
}
}
