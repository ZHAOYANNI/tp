package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

import java.awt.*;
import java.util.List;
import java.util.Random;


public class Windows extends JPanel implements GameObserver, PanelDer.SettingListener{

	private BoardUI ui;
	private PanelDer der;
	private StatusPanel status;
	private PlayerInfor playerInfor;

	public Windows(Controller c,Piece viewPiece,List<Piece> pieces, int rows, int cols,
			int numObs) {
		setPiecesAux(pieces);
		
		playerInfor = new PlayerInfor(pieces);
		status = new StatusPanel();
		ui = new BoardAtaxx();
		der = new PanelDer(this);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		der.initComponents(this,c, viewPiece, pieces, this);
		add(der, BorderLayout.EAST);
		

		ui.setPieces(pieces);
		Board board = createBoard(pieces, rows, cols, numObs);
		ui.setStatusPanel(status);
		ui.setBoard(board);
	}
	
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces,
			Piece turn) {
		status.append("bienvenido a " + gameDesc+ System.getProperty("line.separator"));
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		ui.update();
		status.append("ha ganado " + winner+ System.getProperty("line.separator"));
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		ui.update();
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		ui.update();
		status.append(""+ System.getProperty("line.separator"));
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		ui.update();
		status.append("turno de" + turn+ System.getProperty("line.separator"));
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}

	@Override
	public void ColorChangeChoose(Piece p, Color c) {
		System.out.println(p + "el color es: " + c);
		
	}

	@Override
	public void PlayerModeChange(Piece p, PlayerMode m) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void AutomaticChoose(Piece p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void RandomChoose(Piece p) {
		// TODO Auto-generated method stub
		
	}
	
	public Board createBoard(List<Piece> pieces, int rows, int cols, int numObs) {
        Board board = new FiniteRectBoard(rows, cols);
        board.setPosition(0, 0, pieces.get(0));
        board.setPosition(0, cols-1, pieces.get(1));
        board.setPosition(rows-1, 0, pieces.get(1));
        board.setPosition(rows-1, cols-1, pieces.get(0));
        if(pieces.size() >= 3){
            board.setPosition((rows-1)/2,0,pieces.get(2));
            board.setPosition((rows-1)/2,cols-1,pieces.get(2));
            if(pieces.size()==4){
                board.setPosition(0,(cols-1)/2,pieces.get(3));
                board.setPosition(rows-1,(cols-1)/2,pieces.get(3));
            }
        }
        Piece p = new Piece("*");
        crearObs(board, p, numObs);
        return board;
    }
    
    public void crearObs(Board board, Piece p, int numObs){
         Random rand = new Random();     
        for(int i = 0; i < numObs; i++){
            int row = rand.nextInt((board.getRows()/2));
            int col = rand.nextInt((board.getRows()/2));
            while(board.getPosition(row,col) != null){
                row = rand.nextInt((board.getRows()/2));
                col = rand.nextInt((board.getCols()/2));
            }
            board.setPosition(row, col, p);
            board.setPosition(board.getRows()-row-1, col, p);
            board.setPosition(row, board.getCols()-col-1, p);
            board.setPosition(board.getRows()-row-1, board.getCols()-col-1, p);
        }
    }
    
    public void setPiecesAux(List<Piece> pieces){
        pieces.clear();
        Piece o = new Piece("O");
        pieces.add(o);
        Piece x = new Piece("X");
        pieces.add(x);
        Piece a = new Piece("A");
        pieces.add(a);
        Piece b = new Piece("B");
        pieces.add(b);
        
        //setTurno(pieces.get(0));
    }
}
