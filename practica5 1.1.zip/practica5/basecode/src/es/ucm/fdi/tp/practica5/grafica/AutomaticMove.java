package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class AutomaticMove extends JPanel {

	public AutomaticMove(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Automatic Moves", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	public void setBoton(){
		JButton btnNewButton_1 = new JButton("Intelligent");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnRandom = new JButton("Random");
		add(btnRandom);
		add(btnNewButton_1);
		
	}
}
