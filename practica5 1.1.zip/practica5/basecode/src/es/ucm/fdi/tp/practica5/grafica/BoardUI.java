package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class BoardUI extends JPanel implements MouseListener, GameObserver{
	private JLabel[][] squares;
	private Board board;
	private List<Piece> pieces;
	private Piece turno;
	private int lastRow; //Guarda ��ltima fila clicada
	private int lastCol; //Guarda ��ltima columna clicada
	private StatusPanel status; //Panel de texto del estado de la partida
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendr��a los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardUI(){
		lastRow = -1;
		lastCol = -1;
		//lastPiece = null;
		pieces = new ArrayList();
	}
	
	public void setPieces(List<Piece> pieces){
		this.pieces = pieces;
	}

	public void setTurno(Piece turno){
		this.turno = turno;
	}
	
	public void setStatusPanel(StatusPanel status){
		this.status = status;
	}
	
	public void setBoard(Board board){
		
		if(board != this.board){
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
				for (int i=0; i<board.getRows(); i++) {
					for (int j=0; j<board.getCols(); j++) {
						squares[i][j] = new Square(i,j);
						squares[i][j].addMouseListener(this);
						paintSquare(board.getPosition(i, j), i, j);
						add(squares[i][j]);
					}
				}
		} else{
			update();
		}
		setTurno(pieces.get(0));
	}

	public void setColors(PieceColorMap colorMap){};
	
	public void update(){//Queda ver en qu?momentos se llama a esto dentro del programa.
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}
	
	//Pinta un cuadrado.
	//Queda actualizarla para que acepte pintar listas de distintos tama�os
	public void paintSquare(Piece p, int i, int j){

		Piece obs = new Piece("*");
		
		if(pieces.get(0).equals(p)){
			squares[i][j].setBackground(Color.RED);
		} else if(pieces.get(1).equals(p)){
			squares[i][j].setBackground(Color.BLUE);
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else if(p == null) {//Si es una casilla vac��a
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		
		if(pieces.size() == 3){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			}
		} else if(pieces.size() == 4){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			} else if(pieces.get(3).equals(p)){
				squares[i][j].setBackground(Color.GREEN);
			}
		}
		
		squares[i][j].setOpaque(true);
		
	}
	
	private int abs(int num){
		if(num >= 0){
			return num;
		}
		return -num;
	}
	
	private void cosasDeMover(int row, int col){//Voy a necesitar saber a d�nde me muevo (s?de d�nde vengo por lastRow, lastCol)
		
			Piece p = board.getPosition(lastRow, lastCol);
			board.setPosition(row, col, p);
			
			if(abs(row-lastRow) > 1 || abs(col-lastCol) > 1){//Si se ha movido dos casillas
				board.setPosition(lastRow, lastCol, null);
			}
			convertirAdyacentes(row, col);
			
			update();
	}
	
	//��sta es la funci��n que va a convertir las piezas adyacentes a la que est?en (row, col)
	private void convertirAdyacentes(int row, int col){
		
		Piece obs = new Piece("*");
		
		
		for(int i = -1; i < 2; i++){
			for(int j = -1; j < 2; j++){
				if(row+i >= 0 && row+i < board.getRows() && col+j >= 0 && col+j < board.getCols()){
					if(board.getPosition(row+i, col+j) != null && !obs.equals(board.getPosition(row+i, col+j))
							/*&& board.getPosition(row, col).equals(board.getPosition(row+i, col+j))*/){
						board.setPosition(row+i, col+j, board.getPosition(row, col));
					}
				}
			}
		}
		
	}
	
	private void turnoSiguiente() {
		
		int i = pieces.indexOf(turno);
		i++;
		Piece p = pieces.get((i)%pieces.size());
		boolean mover = movible(p);//Cuando nadie es movible se mete en un bucle infinito
		if(mover){
			turno = p;
		}else{
			while(!mover){
				i++;
				 p = pieces.get((i)%pieces.size());
				 mover = movible(p);
			}
			 turno = p;
		}	
		
		status.append("Es el turno de " + p + System.getProperty("line.separator"));
		status.append("Seleccione la casilla de origen." + System.getProperty("line.separator"));
	}
	
	private int contaPieza(Piece p){
		int n = 0;
		for(int i = 0; i < board.getRows(); i++){
			for(int j = 0; j < board.getCols(); j++){
				if(p.equals(board.getPosition(i, j)))
					n++;
			}
		}
		return n;
	}
	
	private boolean piezaMovible(int row, int col){
		
		for(int i = -2; i < 3; i++){
			for(int j = -2; j < 3; j++){
				if(row+i>=0 && col+j>=0 && row+i<board.getRows() && col+j<board.getCols() 
						&& board.getPosition(row + i, col+j) == null)
					return true;
			}
		}
		return false;
	}
	
	private boolean movible(Piece p){
		
		for(int i = 0; i < board.getRows(); i++){
			for(int j = 0; j < board.getCols(); j++){
				if( p.equals(board.getPosition(i, j))){
					if(piezaMovible(i, j)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private boolean soloQuedaUno(){
		Piece p;
		int cont = 0;
		for(int i = 0; i < pieces.size(); i++){
			p = pieces.get(i);
			if(contaPieza(p) > 0){
				cont++;
			}
		}
		return cont == 1;
	}
	
	private boolean nadieMovible(){
		Piece p;
		for(int i = 0; i < pieces.size(); i++){
			p = pieces.get(i);
			if(movible(p))
				return false;
		}
		return true;
	}
	
	private boolean gameIsDone(){
		return(soloQuedaUno() || nadieMovible());
	}
	
	public Piece quienGana(){
		int max = 0;
		Piece p;
		int cont; 
		Piece gana = null;
		for(int i = 0; i < pieces.size(); i++){
			p = pieces.get(i);
			cont = contaPieza(p);
			if(cont>max){
				max = cont;
				gana = p;
			}
			else if(cont == max){
				gana = null;
			}
		}
		return gana;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		Piece obs = new Piece("*");
		Square square = (Square)e.getSource();

		//Si es una lastRos/lastCol de verdad
		if(lastRow != -1){
			
			//Si la pieza que se mueve no es obs/null.
			//Si la casilla a la que movemos no es de la que venimos
			//Si la casilla a la que vamos est?vac�a
			//Si la casilla a la que vamos est� "cerca"
			if(pieces.contains(board.getPosition(lastRow, lastCol)) && (square.getRow() != lastRow || square.getCol() != lastCol)
					&& board.getPosition(square.getRow(), square.getCol()) == null
					&& abs(lastRow-square.getRow()) <= 2 && abs(lastCol-square.getCol()) <= 2){
				
				status.append("Has seleccionado la casilla (" + square.getRow() + ", " + square.getCol() 
				+ ") como casilla de destino." + System.getProperty("line.separator"));
				
				cosasDeMover(square.getRow(), square.getCol());
				if(!gameIsDone()){
					turnoSiguiente();
				} else {
					String wonnered;
					if(quienGana() == null){
						wonnered = "Ha habido un empate.";
					} else {
						wonnered = quienGana() + " wonnered";
					}
					
					onError(wonnered);
				}
			
			} else {
				onError("Movimiento no permitido.");
			}
			
			lastRow = -1;
			lastCol = -1;
			
			//Si no tenemos ninguna seleccionada y seleccionamos una ficha de que es su turno
		} else if(lastRow == -1 && pieces.contains(board.getPosition(square.getRow(), square.getCol()))
				&& board.getPosition(square.getRow(), square.getCol()).equals(turno)){
			//turnoSiguiente();
			
			lastRow = square.getRow();
			lastCol = square.getCol();
			status.append("Has seleccionado la casilla (" + lastRow + ", " + lastCol + ") como casilla de origen." 
					+ System.getProperty("line.separator"));
			status.append("Seleccione su casilla de destino." + System.getProperty("line.separator"));
		} else {
			onError("Seleccione una casilla de origen v�lida." + System.getProperty("line.separator"));
		}
			
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}
	

}

/*
 *
 * Toca hacer m�s claro qu� est� seleccionado y hacer m�s intuitivo el proceso de selecci�n/deselecci�n
 * 
 * 
 * Los parsers ir�n en el main y tal. Me toca crear en windows una funci�n que cree un tablero en fuci�n de 
 * los datos acerca de �l (dimensi�n, num Piezas, nombre Piezas, obst�culos) y luego meterlo en el setter de BoardUI
 * 
 * LO �LTIMO QUE HE ESTADO HACIENDO HA SIDO IR PONIENDO COSAS EN MAIN PARA VER SI LOS TABLEROS VAN BIEN CUANDO SE 
 * LOS PASAS YA HECHOS (PARA CUANDO YA TENGAMOS ARGS Y TODA LA PESCA)
 * 
 * PARA LAS COSAS DE BoardUI EN VEZ DE COPIAR/PEGAR LAS FUNCIONES DE ATAXX TENGO QUE LLAMARLAS
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general. (cambio turno, etc)
 */
