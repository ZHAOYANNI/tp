package es.ucm.fdi.tp.practica5.grafica;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

	public class MiModel extends AbstractTableModel {

		private String[] columnNames = {"Speed", "Pressure",
		    "Force"};

		public void setColumnName(int i, String name) {
			columnNames[i] = name;
		}
		@Override
		public int getRowCount() {
		    return 0;
		}

		@Override
		public int getColumnCount() {
		    return columnNames.length;
		}

		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
		    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
		}
	}
