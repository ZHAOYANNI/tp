package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.List;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;


public class PanelDer extends JPanel {
	
	
	private PieceColor pieceColor;
	private PlayerMode playerMode;
	private AutomaticMove move;
	private Salir salir;
	private SettingListener list;
	private boolean hasRandom;
	private boolean hasAutomatic;
	
	
	  public PanelDer(SettingListener list) {
		  this.list = list;
		  hasRandom = false;
		  hasAutomatic = false;
	    }
	  
	  public interface SettingListener{

			public void ColorChangeChoose(Piece p, Color c);
			public void PlayerModeChange(Piece p, Main.PlayerMode m);
			public void AutomaticChoose(Piece p);
			public void RandomChoose(Piece p);
			
		}
	  public void initComponents(GameObserver g,Controller c, Piece viewPiece, List<Piece> pieces,
			  SettingListener list){
		pieceColor = new PieceColor();
		playerMode = new PlayerMode();
		move = new AutomaticMove();
		salir = new Salir();
		
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		panel.add(pieceColor);
		pieceColor.setTit();
		pieceColor.setBoton(g,pieces, list);
		
		panel.add(playerMode);
		playerMode.setTit();
		playerMode.setBoton(pieces);
		
		
		panel.add(move);
		move.setTit();
		move.setBoton();
		
		
		panel.add(salir);
		salir.setBoton(g,c,viewPiece);
		
		add(panel);
		
	}
}
