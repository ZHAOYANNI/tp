package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class PlayerMode extends JPanel{

	public PlayerMode(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Player Modes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
	
	public void setBoton(List<Piece> pieces){
		Vector<Piece> v = new Vector();
		for(int i =0; i < pieces.size();i++){
			v.add(pieces.get(i));
		}
		
		JComboBox Piece = new JComboBox();
		Piece.setModel(new DefaultComboBoxModel(v));
		add(Piece);
		
		JComboBox Modo = new JComboBox();
		Modo.setModel(new DefaultComboBoxModel(new String[]{"Manual", "Random", "Intelligent"}));
		add(Modo);
		
		JButton btnSet = new JButton("Set");
		add(btnSet);
	}
}
