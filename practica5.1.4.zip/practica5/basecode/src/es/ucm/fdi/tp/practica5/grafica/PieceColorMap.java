package es.ucm.fdi.tp.practica5.grafica;



import java.awt.Color;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class PieceColorMap {
	
	Color getColorFor(Piece p){
		return Color.red;
	};

}
