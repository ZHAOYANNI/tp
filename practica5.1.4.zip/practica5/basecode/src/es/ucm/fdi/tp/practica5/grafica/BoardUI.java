package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public abstract class BoardUI extends JPanel implements MouseListener, GameObserver{
	private JLabel[][] squares;
	private Board board;
	private List<Piece> pieces;
	private Piece turno;
	private StatusPanel status; //Panel de texto del estado de la partida
	private GameMove movimiento;
	private GameRules rules;
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendr��a los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardUI(){
		pieces = new ArrayList();
	}
	
	public abstract void setRules(int dim, int numObs);
	
	public abstract GameRules getRules();
	
	public void setPieces(List<Piece> pieces){
		this.pieces = pieces;
	}

	public void setTurno(Piece turno){
		this.turno = turno;
	}
	
	public void setStatusPanel(StatusPanel status){
		this.status = status;
	}
	
	public void setBoard(Board board){
		
		if(board != this.board){
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
				for (int i=0; i<board.getRows(); i++) {
					for (int j=0; j<board.getCols(); j++) {
						squares[i][j] = new Square(i,j);
						squares[i][j].addMouseListener(this);
						paintSquare(board.getPosition(i, j), i, j);
						add(squares[i][j]);
					}
				}
		} else{
			update();
		}
		setTurno(pieces.get(0));
	}

	public void setColors(PieceColorMap colorMap){};
	
	public void update(){//Queda ver en qu?momentos se llama a esto dentro del programa.
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}
	
	//Pinta un cuadrado.
	//Queda actualizarla para que acepte pintar listas de distintos tama�os
	public void paintSquare(Piece p, int i, int j){

		Piece obs = new Piece("*");
		
		if(pieces.get(0).equals(p)){
			squares[i][j].setBackground(Color.RED);
		} else if(pieces.get(1).equals(p)){
			squares[i][j].setBackground(Color.BLUE);
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else if(p == null) {//Si es una casilla vac��a
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		
		if(pieces.size() == 3){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			}
		} else if(pieces.size() == 4){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			} else if(pieces.get(3).equals(p)){
				squares[i][j].setBackground(Color.GREEN);
			}
		}
		
		squares[i][j].setOpaque(true);
		
	}
	
	public abstract void cosasDeMover(int row, int col);
	
	public abstract void turnoSiguiente(); 
	
	public abstract boolean gameIsDone();

	@Override
	public abstract void mouseClicked(MouseEvent e); 

	@Override
	public abstract void mouseEntered(MouseEvent e) ;

	@Override
	public abstract void mouseExited(MouseEvent e) ;
	
	@Override
	public abstract void mousePressed(MouseEvent e);

	@Override
	public abstract void mouseReleased(MouseEvent e) ;

	@Override
	public abstract void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn);

	@Override
	public abstract void onGameOver(Board board, State state, Piece winner);

	@Override
	public abstract void onMoveStart(Board board, Piece turn);

	@Override
	public abstract void onMoveEnd(Board board, Piece turn, boolean success);

	@Override
	public abstract void onChangeTurn(Board board, Piece turn) ;

	@Override
	public abstract void onError(String msg); 

}

/*
 *
 * Toca hacer m�s claro qu� est� seleccionado y hacer m�s intuitivo el proceso de selecci�n/deselecci�n
 * 
 * 
 * Los parsers ir�n en el main y tal. Me toca crear en windows una funci�n que cree un tablero en fuci�n de 
 * los datos acerca de �l (dimensi�n, num Piezas, nombre Piezas, obst�culos) y luego meterlo en el setter de BoardUI
 * 
 * LO �LTIMO QUE HE ESTADO HACIENDO HA SIDO IR PONIENDO COSAS EN MAIN PARA VER SI LOS TABLEROS VAN BIEN CUANDO SE 
 * LOS PASAS YA HECHOS (PARA CUANDO YA TENGAMOS ARGS Y TODA LA PESCA)
 * 
 * PARA LAS COSAS DE BoardUI EN VEZ DE COPIAR/PEGAR LAS FUNCIONES DE ATAXX TENGO QUE LLAMARLAS
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general. (cambio turno, etc)
 * 
 * Pasar a BoardUI el GameObserver de Windows en vez de crear uno nuevo.
 * 
 * CUANDO ACTUA WINDOWS TIENEN QUE ACTUAL PANEL DERECHA Y BOARD (POR EJEMPLO CUANDO CAMBIAMOS EL COLOR DE UNA FICHA)
 * 
 * Voy a hacer el muy necesario cambio de que BoardUI pase a ser BoardAtaxx y viceversa
 */
