package es.ucm.fdi.tp.practica5.attt;

import es.ucm.fdi.tp.practica5.ttt.TicTacToeFactoryExt;

public class AdvancedTTTFactoryExt extends TicTacToeFactoryExt {

}
