package es.ucm.fdi.tp.practica5.grafica;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.connectn.ConnectNMove;
import es.ucm.fdi.tp.practica5.grafica.BoardUI.StatusListener;

/**Crea un jugador manual del juego connectN*/
public class ConnectNGraphicalPlayer extends BoardUI.GraphicalPlayer{

	@Override
	public void clickedInCell(Board board, int row, int col, Piece turn,
			Piece clicked, StatusListener status) {
		if(clicked == null){
			status.showDestination(row, col);
			move = new ConnectNMove(row, col, turn);
		} else{
			status.showError();
			status.selectOrigen();
		}
		
	}

}
