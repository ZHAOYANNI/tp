package es.ucm.fdi.tp.practica6.ttt;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.ConsolePlayerFromListOfMoves;
import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.AIAlgorithm;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.views.GenericConsoleView;
import es.ucm.fdi.tp.practica6.connectn.ConnectNFactoryExt;
import es.ucm.fdi.tp.practica6.grafica.Controller2;
import es.ucm.fdi.tp.practica6.grafica.Windows;

public class TicTacToeFactoryExt extends ConnectNFactoryExt {
	
	protected List<Piece> pieces;
	
	public TicTacToeFactoryExt(){
		super();
		pieces = new ArrayList();
	}
	
	public TicTacToeFactoryExt(List<Piece> pieces) {
		super(3, pieces);
		this.pieces = pieces;

	}
	
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {

				String gameDesc = new String("TicTAcToe ");
				if(viewPiece != null){
					gameDesc += " (" + viewPiece + ")";
				}
				Windows window = new Windows(c, viewPiece, pieces, dim, 0, true, true, gameDesc);
				window.setTitle(gameDesc);
				window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				((Controller2)c).addWindow(window);
				window.setSize(600, 400);
				window.setVisible(true);
			}
		});
	}
}
