package es.ucm.fdi.tp.practica6.grafica;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Controller2 extends Controller implements GameObserver {

	protected Windows[] windows;// Array de ventanas (para multiview) En single
								// view usaremos s楂刼 el primero
	protected Piece turn; // A quien le toca
	protected boolean multiview = false; // Probablemente lo haga m閱� elegante
											// luego
	private int contador; //Cantidad de ventanas que tenemos (servir锟� principalmente en multiview)
	private int currentWindowIndex; //铓絛ice en el array de ventanas de la ventana que nos interesa en el momento
	private Board board;

	public Controller2(Game game, List<Piece> pieces, Windows[] windows) {
		super(game, pieces);
		this.windows = windows;
		contador = 0;
		currentWindowIndex = 0;
	}
	
	public void addWindow(Windows window){
		windows[contador] = window;
		contador++;
		if(contador > 1){
			multiview = true;
		}
	}
	
	public Board getBoard(){
		return board;
	}
	
	public boolean getMultiview(){
		return multiview;
	}
	
	public int getWindowIndex(){
		return currentWindowIndex;
	}

	public void makeMove(Player player, Piece turn) {
		game.makeMove(player); 
	}

	public void start() {
		if (game != null) {
			game.start(pieces);
		}
	}

	public void stop() {
		if (game != null) {
			game.stop();
		}
	}

	public void restart() {
		if (game != null) {
			game.restart();
		}
	}

	public void changePM(){
		for(int i = 0; i < contador; i++){
			windows[i].changePm(windows[currentWindowIndex].pm);
			windows[i].playerInfor.actualiza();
		}
	}
	
	// Cuando Game nos dice que va a empezar la partida seteamos el turno y el tablero.
	@SuppressWarnings("deprecation")
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		this.turn = turn;
		this.board = board;//Setear el board tambi閚 en los otros sitios. Este es el board que me pasa game
		if(contador > 0){//Si venimos de restart
			//windows[0].newBoard(pieces, board);
			windows[0].dispose();
			Main.startGame();
		}
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		for(int i = 0; i < contador; i++){
			windows[i].onGameOver(board, state, winner);
		}
	}


	@Override
	public void onMoveStart(Board board, Piece turn) {
		if (!multiview) {
			//currentWindowIndex = 0; //este Index nos dice la ventana que nos importa ahora mismo (es la del turno al que le toca)
		} else { // A partir de la posici楂� de turn en pieces tengo que elegir
					// la ventana a la que le toca
			//currentWindowIndex = pieces.indexOf(turn); //La ventana que nos interesa est锟� en el array de ventanas
													   //En la misma pos que la pieca en la lista de piezas
		}
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		for(int i = 0; i < contador; i++){
			windows[i].updateBoard();
		}
	}

	// Lo que vamos a hacer cuando se cambie el turno
	@Override
	public void onChangeTurn(Board board, Piece turn) {
		this.turn = turn; // turn pasa a ser la pieza siguiente.
		
		if(multiview){
			currentWindowIndex = pieces.indexOf(turn);
		}

		for(int i = 0; i < contador; i++){ 
			windows[i].ui.setTurno(turn);
		}
		
		if(windows[currentWindowIndex].getMode(turn) == Main.PlayerMode.AI){
			AiPlayer player = new AiPlayer();
			SwingUtilities.invokeLater(new Runnable(){
				public void run(){
					makeMove(player, turn);
				}
			});
		} else if (windows[currentWindowIndex].getMode(turn) == Main.PlayerMode.RANDOM) {
			AtaxxRandomPlayer player = new AtaxxRandomPlayer();
			SwingUtilities.invokeLater(new Runnable(){
				public void run(){
					makeMove(player, turn);
				}
			});
		}
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	public void onInfo(String msg){
		JOptionPane.showMessageDialog(null, msg, "Game Ended", JOptionPane.INFORMATION_MESSAGE);
		stop();
		System.exit(0);
	}

}

/* 
 * Cuando seteas un playerMode en una ventana se desactivan las opciones de hacer un movimiento random/inteligent en 
 * TODA ESA VENTANA
 * 
 * En ataxx se tiene que poder cancelar la selecci髇 de una ficha.
 * (Esto se puede hacer poniendo
 * 	lastRow y lastCol a -1 si seleccionamos algo en el panelDer)
 * 
 * Hay que hacer que funcionen los otros juegos
 */
