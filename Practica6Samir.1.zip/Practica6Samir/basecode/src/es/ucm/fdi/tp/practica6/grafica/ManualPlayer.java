package es.ucm.fdi.tp.practica6.grafica;

import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class ManualPlayer extends Player {

	private String juego;
	
	public void setJuego(String juego){
		this.juego = juego;
	}
	@Override
	public GameMove requestMove(Piece p, Board board, List<Piece> pieces, GameRules rules) {
		if(juego.equals("Ataxx"))
			return BoardAtaxx.getMove();
		else if(juego.equals("ConnectN"))
			return BoardConnectN.getMove();
		else if(juego.equals("Attt"))
			return BoardAttt.getMove();
		else {
			return BoardTTT.getMove();
		}
	}

}

/*
 * Esta funci�n y clase s�lo existen porque makeMove de Game usa como argumento un Player
 * y a ese player le pide un movimiento. Ese player no lo usamos para nada m�s (no es un playerMode, es un Player
 * con lo cual no puedes coger el valor del HashMap de modos asociado a la pieza).
 * Para solucionar esto lo que hacemos es, cuando pase algo que tenga que dar lugar a un movimiento
 * (movemos una pieza, clicamos en aleatorio, clicamos en autom�tico/inteligente/c�mo se llame)
 * creamos un player de la clase correspondiente (Manual, Random, AI) y llamamos a makeMove(player, turn) del controlador.
 * 
 * Puedes ver el ejemplo en cosasDeMover en BoardAtaxx.
 *  
 */
