package es.ucm.fdi.tp.practica6.net;

import java.awt.Dimension;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.control.commands.Command;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.grafica.Controller2;

public class Server extends Controller2 implements GameObserver{
	
	private int port;
	private int numPlayers;
	private int numOfConnectedPlayers;
	private GameFactory gameFactory;
	private List<Connection> clients;
	
	volatile private ServerSocket server;
	volatile private boolean stopped;
	volatile private boolean gameOver;
	
	public Server(GameFactory gameFactory, List<Piece> pieces, int port){
		super(new Game(gameFactory.gameRules()), pieces, null);
		
		this.numPlayers = pieces.size();
		this.numOfConnectedPlayers = 0;
		this.stopped = false;
		this.gameOver = false;
		
		//Me queda inicializar port, clients, server;
		
		game.addObserver(this);
	}
	
	//...
	
	@Override
	public synchronized void makeMove(Player player){
	try{
		super.makeMove(player);;
	} catch(GameError e){}
	
	}
	
	@Override
	public synchronized void stop(){
		try{super.stop();} catch(GameError e){}
	}
	
	@Override
	public synchronized void restart(){
		try{super.restart();}catch(GameError e){}
	}
	
	@Override
	public void start(){
		//controlGUI() //El m�todo que crea la ventana
		startServer();
	}
	
	private void controlGUI(){
		try{
			SwingUtilities.invokeAndWait(new Runnable(){
				@Override
				public void run(){ constructGUI();}
			});
		} catch(InvocationTargetException | InterruptedException e){
			throw new GameError("Something went wrong when constructing the GUI");
		}
	}
	
	private void constructGUI(){
		JFrame window = new JFrame("Game Server");
		//Crear textArea para escribir mensages (mirar en prac5 para hacerlo)
		//infoArea = ...
		
		JButton quitButton = new JButton("Stop Server");
		//...
		window.setPreferredSize(new Dimension(640, 480));
		window.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		window.pack();
		window.setVisible(true);
		
	}
	
	private void log(String msg){
		//show the message in infoArea, use invokeLater!!
	}
	
	private void startServer() throws IOException{
		
		server = new ServerSocket(port);
		stopped = false;
		
		while(!stopped){
			try{
				//aceptar una conexi�n into a socket s
				//log corresponding message
				//call handleRequest(s) to handle the request
			} catch(IOException e){
				if(!stopped){
					log("error while waiting for a connection: " + e.getMessage());
				}
			}
		}
	}
	
	private void handleRequest(Socket s){
		try{
			Connection c = new Connection(s);
			
			Object clientRequest = c.getObject();
			if(!(clientRequest instanceof String) && !((String)clientRequest).equalsIgnoreCase("Connect")){
				c.sendObject(new GameError("Invalid Request"));
				c.stop();
				return;
			}
			
			//1) Si el ya se han conectado el num m�ximo de clientes respondemos con GameError adecuado
			//2) Incrementamos el n�m de clientes conectados y a�adimos 'c' a la lista de clientes.
			
			//3) Enviamos "OK" al cliente seguido de la GameFactory Y el Piece a usar
			//Asignamos al i�simo cliente la i�sima pieca de la lista
			
			//4) Si hay un num suficiente de clientes empezamos el juego
			//(la primera vez con start() luego con restart()
			
			//5) Invocamos a startClientListener(c) para iniciar una hebra para escuchar al cliente
		}catch (IOException | ClassNotFoundException e){}
		
	}
	
	private void startClientListener(Connection c){
		gameOver = false;
		Thread t = ...; //Iniciar una hebra para ejecutar el bucle de abajo
		//...
		t.start();
		while(!stopped && !gameOver){
			try{
				Command cmd;
				//1. read a Command (Recibir Object del client y castearlo a Command
				//2. Execute the commando ejecutar cml.exec, pas�ndole el Controller, GameServer.this
			} catch(ClassNotFoundException | IOException e){
				if(!stopped && !gameOver){
					//stop the game(not the server);
				}
			}
		}
	}
	
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn){
		forwardNotification(new GameStartResponse(board, gameDesc, pieces, turn));
	}
	
	void forwardNotification(Response r){
		//call c.sendObject(r) for each client connection 'c'
	}
	
	public interface Response extends java.io.Serializable{
		public void run(GameObserver o);
	}
	
	public class GameStartResponse implements Response{
		private Board board;
		private String gameDesc;
		private List<Piece> pieces;
		private Piece turn;
		
		public GameStartResponse(Board board, String gameDesc, List<Piece> pieces, Piece turn){
			this.board = board;
			this.gameDesc = gameDesc;
			this.pieces = pieces;
			this.turn = turn;
		}
		
		@Override
		public void run(GameObserver o){
			o.onGameStart(board, gameDesc, pieces, turn);
		}
	}
	
	//Mirar diapositiva 16
		
}
