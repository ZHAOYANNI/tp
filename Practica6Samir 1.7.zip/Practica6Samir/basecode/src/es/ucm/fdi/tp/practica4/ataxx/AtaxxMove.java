package es.ucm.fdi.tp.practica4.ataxx;
import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.model.*;

/**
 * Clase para representar un movimiento del juego Ataxx.
 * */
public class AtaxxMove extends GameMove{
	
	private static final long serialVersionUID = 1L;
	/**
	 * Fila de la pieza que vamos a mover.
	 * */
	protected int row1;
	/**
	 * Columna de la pieza que vamos a mover.
	 * */
	protected int col1;
	/**
	 * Fila de la casilla a la que la pieza va a mover.
	 * */
	protected int row2;
	/**
	 * Columna de la casilla a la que la pieza va a mover.
	 * */
	protected int col2;
	
	/**Solo se debe usar este constructor para obtener objetos de
	 * {@link AtaxxMove} para generar movimientos a partir de strings usando
	 * el metodo {@link #fromString(String)}
	 * 
	 */
	public AtaxxMove() {
	}
	
	/**
	 * Construye un movimiento para colocar la ficha de la posicion({@code row1},{@code col1})del tipo 
	 * referenciado por {@code p} en la posicion ({@code row2},{@code col2}).
	 * 
	 * @param row1
	 *            Numero de fila de la posicion de la ficha.
	 * @param col1
	 *            Numero de columna de la posicion de la ficha.
	 * @param row2
	 *            Numero de fila de la posicion a la que vamos a colocar (@code p).
	 * @param col2
	 *            Numero de columna de la posicion a la que vamos a colocar (@code p).
	 * @param p
	 *            Ficha a colocar en ({@code row2},{@code col2}).
	 */
	public AtaxxMove(int row1, int col1, int row2, int col2, Piece p) {
		super(p);
		this.row1 = row1;
		this.col1 = col1;
		this.row2 = row2;
		this.col2 = col2;
	}
	
	@Override
	public void execute(Board board, List<Piece> pieces) {
		Piece p = new Piece("*");  // Obstaculo
		if(!getPiece().equals(board.getPosition(row1,col1))){
			// Si la ficha que mueve no coincide con la ficha del turno, lanza exception
			throw new GameError("Uknown move: " + row1 + " " + col1 + " " +row2+" " + col2);
		}
		
		if (board.getPosition(row2, col2) == null) {
			board.setPosition(row2, col2, getPiece());
			//Si la ficha ha movido 2 casillas, se mueve a la casilla de destino.
			if(!contiguas(row1, col1, row2, col2)){
				board.setPosition(row1, col1, null);
			}
			
			//Comprueba si en el alrededor de la ficha movida hay fichas de otros jugadores.
			//En caso afirmativo, todas las fichas de los oponentes adyacentes 
			//se convierten al color del jugador.
			for(int i = -1; i < 2; i++){
				for(int j = -1; j < 2; j++){
					if(row2+i >= 0 && row2+i < board.getRows() && col2+j >= 0 && col2+j < board.getCols()){
						if(board.getPosition(row2+i, col2+j) != null && !p.equals(board.getPosition(row2+i, col2+j))
								&& !getPiece().equals(board.getPosition(row2+i, col2+j))){
							board.setPosition(row2+i, col2+j, getPiece());
						}
					}
				}
			}
			
		} else {
			//throw new GameError("position (" + row2 + "," + col2 + ") is already occupied!");
		}
		
	}

	@Override
	public GameMove fromString(Piece p, String str) {
		String[] words = str.split(" ");
		if (words.length != 4) {
			return null;
		}

		try {
			int row1, col1, row2, col2;
			row1 = Integer.parseInt(words[0]);
			col1 = Integer.parseInt(words[1]);
			row2 = Integer.parseInt(words[2]);
			col2 = Integer.parseInt(words[3]);
			if(esVecino(row1,col1,row2,col2))
				return createMove(row1, col1, row2, col2, p);
			else 
				return null;
		} catch (NumberFormatException e) {
			return null;
		}

	}
	
	/**
	 * Crea un nuevo movimiento con la misma ficha utilizada en el movimiento
	 * actual. Llamado desde {@link #fromString(Piece, String)}; se separa este
	 * metodo del anterior para permitir utilizar esta clase para otros juegos
	 * similares sobrescribiendo este metodo.
	 * @param row1
	 *            Fila de ({@code p})
	 * @param col1
	 *            columna de ({@code p})
	 * @param row2
	 *            Fila del nuevo movimiento.
	 * @param col2
	 *            Columna del nuevo movimiento.
	 * @param p
	 *            La ficha que queremos mover.
	 * */
	protected GameMove createMove(int row1, int col1, int row2, int col2, Piece p) {
		return new AtaxxMove(row1, col1, row2, col2, p);
	}
	
	@Override
	public String help() {
		return "'row1 column1 row2 column2', to move the piece at row1 column1 to the corresponding position.";
	}
	
	@Override
	public String toString() {
		if (getPiece() == null) {
			return help();
		} else {
			return "Place a piece '" + getPiece() + "' at (" + row2 + "," + col2 + ")";
		}
	}
	
	/**
	 * Comprueba si las dos casillas son adyacentes. En caso afirmativo, devuelve true.
	 * @param row1
	 *             Fila de la casilla 1.
	 * @param col1 
	 *             Columna de la casilla 1.
	 * @param row2
	 *             Fila de la casilla 2.
	 * @param col2
	 *             Columna de la casilla 2.
	 * @return true
	 *             Si las dos casillas son adyacentes.
	 **/
	public boolean contiguas(int row1, int col1, int row2, int col2){
		if(row2-row1 > 1  || row2-row1 < -1 || col2-col1 > 1 || col2-col1 < -1){
			return false;
		}
		return true;
	}
	
	/**
	 * Comprueba si 2 casillas son vecinos, es decir, la distancia entre ellas es menor que 2.
	 * En caso afirmativo, devuelve true.
	 * @param row1
	 *             Fila de la casilla 1.
	 * @param col1
	 *             Columna de la casilla 1.
	 * @param row2
	 *             Fila de la casilla 2.
	 * @param col2
	 *             Columna de la casilla 2.
	 * @return true
	 *             Si las dos casillas son vecinos.
	 **/
	public boolean esVecino(int row1,int col1, int row2, int col2){
		int i=0;
		if(row2>row1){
			while(row1 + i < row2){
				i++;
			}
		}else{
			while(row2 + i < row1){
				i++;
			}
		}
		int j = 0;
		if(col2>col1){
			while(col1 + j < col2){
				j++;
			}
		}else{
			while(col2 + j < col1){
				j++;
			}
		}
		if(i<=2 && j <=2)
			return true;
		else 
			return false;
	}
}
