package es.ucm.fdi.tp.practica6.responses;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
/**respuesta de un gameOver*/
public class GameOverResponse implements Response{
	private static final long serialVersionUID = -5279418504650952671L;

	/**la tabla donde desarrollamos el juego*/
	private Board board;
	/**el estado de la partida*/
	private State state;
	/**el ganador de la partida*/
	private Piece winner;
	
	/**
	 * Constructor
	 * @param board
	 *        la tabla donde desarrollamos el juego
	 * @param state
	 *        el estado de la partida
	 * @param winner
	 *        el ganador de la partida*/
	public GameOverResponse(Board board, State state, Piece winner){
		this.board = board;
		this.state = state;
		this.winner = winner;
	}
	
	@Override
	public void run(GameObserver o){
		o.onGameOver(board, state, winner);
	}
}