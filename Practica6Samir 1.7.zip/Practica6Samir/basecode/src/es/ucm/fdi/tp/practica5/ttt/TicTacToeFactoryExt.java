package es.ucm.fdi.tp.practica5.ttt;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.ttt.TicTacToeRules;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxRules;
import es.ucm.fdi.tp.practica5.connectn.ConnectNFactoryExt;
import es.ucm.fdi.tp.practica5.grafica.GameWindow;
import es.ucm.fdi.tp.practica5.grafica.TTTGraphicalPlayer;
/**
 * Factoria para la creacion de juegos TicTacToe en vista Window.
 *  Vease {@link AtaxxRules} para la descripcion del juego.
 */
public class TicTacToeFactoryExt extends ConnectNFactoryExt {
	
	/**constructor*/
	public TicTacToeFactoryExt() {
		super(3);

	}
	
	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		try{
		SwingUtilities.invokeAndWait(new Runnable() {
			public void run() {

				String gameDesc = new String("TicTAcToe ");
				if(viewPiece != null){
					gameDesc += " (" + viewPiece + ")";
				}
				GameWindow window = new GameWindow(c, new TTTGraphicalPlayer(),viewPiece, random, ai, gameDesc,
						new TicTacToeRules());
				g.addObserver(window);
				window.setTitle(gameDesc);
				window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				window.setSize(600, 400);
				window.setVisible(true);
			}
		});
	}catch (InvocationTargetException e) {
		e.printStackTrace();
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	}
}
