package es.ucm.fdi.tp.practica6.responses;

import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;

/**interfaz de respuestas, hereda de java.io.Serializable*/
public interface Response extends java.io.Serializable{
	
	/**ejecuta  un gameObserver
	 * @param o
	 *        el gameObserver que va a ser ejecutado*/
	public void run(GameObserver o);
	
}
