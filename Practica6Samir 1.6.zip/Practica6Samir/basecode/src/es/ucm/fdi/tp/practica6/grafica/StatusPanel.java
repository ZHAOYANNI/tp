package es.ucm.fdi.tp.practica6.grafica;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

/**
 * panel donde aparece los mensajes
 * */
public class StatusPanel extends JPanel{
	/**area del texto*/
	private JTextArea textPrueba;
	
	/**Constructor*/
	public StatusPanel(){
		setBorder(new TitledBorder(null, "Status Menssages", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
		textPrueba = new JTextArea();
		textPrueba.setEditable(false);
		textPrueba.setRows(50);
		add(new JScrollPane(textPrueba), BorderLayout.CENTER);
	}
	
	/**
	 * funci��n que sirve para mostrar un texto
	 * @param txt
	 *         el texto que queremos mostrar por el panel de estado
	 *         */
	public void append(String txt){
		textPrueba.append(txt + System.getProperty("line.separator"));
		textPrueba.setCaretPosition(textPrueba.getDocument().getLength());
	}
}
