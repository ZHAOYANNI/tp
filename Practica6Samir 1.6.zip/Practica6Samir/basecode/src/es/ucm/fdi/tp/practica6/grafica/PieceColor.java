package es.ucm.fdi.tp.practica6.grafica;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.grafica.PanelDer.SettingListener;

/**
 * clase que nos permiter cambiar el color de un jugador
 * */
public class PieceColor extends JPanel {
	
	/**el jugador que queremos cambiar su color*/
	Piece p;
	
	/**
	 * constructor*/
	public PieceColor(){
		super();
	}
	
	/**
	 * Configura el titulo
	 * */
	public void setTit(){
		setBorder(new TitledBorder(null, "Piece Colors", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	/**
	 * Inicia los componentes de panel
	 * @param list
	 *           es un listener
	 * @param pieces
	 *           lista de jugadores
	 **/
	public void setBoton(List<Piece> pieces,SettingListener list){
		Vector<Piece> v = new Vector(); 
		for(int i =0; i < pieces.size();i++){
			v.add(pieces.get(i));
		}
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(v));
		add(comboBox);
		comboBox.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	p = (Piece)comboBox.getSelectedItem();
		     }
		   	});
		
		JButton btnChoose = new JButton("Choose Color");
		add(btnChoose);
		btnChoose.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		 	JColorChooser Selectorcolor=new JColorChooser();
		 	Color color=Selectorcolor.showDialog(null, "Seleccione un Color", Color.BLUE);
		 		if(p == null){
	            	list.ColorChangeChoose(pieces.get(0), color);
	            } else
	            	list.ColorChangeChoose(p, color);
		     }
			});
	}
}
