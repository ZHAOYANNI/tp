package es.ucm.fdi.tp.practica6.net;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.control.commands.Command;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica6.grafica.StatusPanel;
import es.ucm.fdi.tp.practica6.responses.*;

/**el servidor del juego*/
public class Server extends Controller implements GameObserver{
	
	/**indica el n��mero de puerto*/
	private int port;
	/**m��ximo jugadores que puede conectar*/
	private int numPlayers;
	/**n��mero de jugadores conectados*/
	private int numOfConnectedPlayers;
	/**la factor��a del juego*/
	private GameFactory gameFactory;
	/**lista de conecciones*/
	private List<Connection> clients;
	/**la tabla donde desarrollamos el juego*/
	private Board board;
	/**indica si es primera vez que inicia un juego*/
	private boolean firstGame = true;
	
	/***/
	volatile private ServerSocket server;
	/**indica si el juego est�� en stop*/
	volatile private boolean stopped;
	/**indica si el juego est�� terminado*/
	volatile private boolean gameOver;
	
	/**donde mostraremos los mensajes del servidor*/
	private StatusPanel status;
	
	/**constructor
	 * @param gameFactory
	 *        factor��a del juego
	 * @param pieces
	 *        lista de jugadores
	 * @param port
	 *        el n��mero del puerto*/
	public Server(GameFactory gameFactory, List<Piece> pieces, int port) throws IOException{
		super(new Game(gameFactory.gameRules()), pieces);
		
		this.port = port;
		this.numPlayers = pieces.size();
		this.numOfConnectedPlayers = 0;
		this.clients = new ArrayList<Connection>();
		this.gameFactory = gameFactory;
		this.stopped = false;
		this.gameOver = false;
		
		game.addObserver(this);
	}
	
	@Override
	public synchronized void makeMove(Player player){
	try{
		super.makeMove(player);
	} catch(GameError e){}
	
	}
	
	@Override
	public synchronized void stop(){
		try{super.stop();} catch(GameError e){}
	}
	
	@Override
	public synchronized void restart(){
		try{super.restart();}catch(GameError e){}
	}
	
	@Override
	public void start(){
		controlGUI();
		try {
			startServer();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**constuye una ventana para el servidor*/
	private void controlGUI(){
		try{
			SwingUtilities.invokeAndWait(new Runnable(){
				@Override
				public void run(){ constructGUI();}
			});
		} catch(InvocationTargetException | InterruptedException e){
			throw new GameError("Something went wrong when constructing the GUI");
		}
	}
	
	/**construye una ventana para el servidor*/
	private void constructGUI(){
		JFrame window = new JFrame("Game Server");
		StatusPanel status = new StatusPanel();
		this.status = status;

		JButton quitButton = new JButton("Stop Server");
		quitButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//Parar el server y salir de la app
				for(Connection c: clients){
					try {
						c.stop();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				stopped = true;
				stop();
				System.exit(0);
			}
		});
		window.setLayout(new BorderLayout());
		window.add(quitButton, BorderLayout.EAST);
		window.add(status, BorderLayout.CENTER);
		window.setPreferredSize(new Dimension(640, 480));
		window.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		window.pack();
		window.setVisible(true);
	}
	
	/**muestra el mensaje
	 * @param msg 
	 *        el mensaje que queremos mostrar*/
	private void log(String msg){
		SwingUtilities.invokeLater(new Runnable(){
			@Override
			public void run(){
				status.append(msg + System.getProperty("line.separator"));
			}
		});
	}
	
	/**inicia el servidor*/
	private void startServer() throws IOException{
		
		server = new ServerSocket(port);
		stopped = false;
		
		while(!stopped){
			try{
				Socket s = server.accept();
				log("Connection was successfull.");//Me queda ver cu�l es el mensage correspondiente
				handleRequest(s);
			} catch(IOException e){
				if(!stopped){
					log("error while waiting for a connection: " + e.getMessage());
				}
			} catch (InterruptedException e) {
				log("Connection was interrupted. " + e.getMessage());
			}
		}
	}
	
	/**ejecuta las pediciones del cliente
	 * @param s
	 *        inicia el atributo socket s de un elemento de coneccion*/
	private void handleRequest(Socket s) throws InterruptedException{
		try{
			Connection c = new Connection(s);
			
			Object clientRequest = c.getObject();
			if(!(clientRequest instanceof String) && !((String)clientRequest).equalsIgnoreCase("Connect")){
				c.sendObject(new GameError("Invalid Request"));
				c.stop();
				return;
			}
			
			if(numOfConnectedPlayers == numPlayers){
				throw new GameError("Error: No more players can connect to the game.");
			}
			numOfConnectedPlayers++;
			clients.add(c);

			c.sendObject("OK");
			c.sendObject(gameFactory);
			int i = clients.indexOf(c);
			c.sendObject(pieces.get(i));
		
			if(numOfConnectedPlayers == numPlayers){
				log("Se acaba de alcanzar el n�mero necesario de jugadores.");
				if(firstGame == true){
					super.start();
					firstGame = false;
				} else{
					restart();
				}
			}

			startClientListener(c);
			
		}catch (IOException | ClassNotFoundException e){}
		
	}
	
	/**empieza el juego
	 * @param c
	 *        el elmento que conecta el servidor con un cliente*/
	private void startClientListener(Connection c){
		gameOver = false;
		Thread t = new Thread(){ //Iniciar una hebra para ejecutar el bucle de abajo

		@SuppressWarnings("deprecation")
		public void run(){
			while(!stopped && !gameOver){
				try{
						Command cmd;
						//1. read a Command (Recibir Object del client y castearlo a Command
						cmd = (Command)c.getObject();
						//2. Execute the commando ejecutar cml.exec, pas�ndole el Controller, GameServer.this (no s?cu�l es ese m�todo
						cmd.execute(Server.this);
						
				} catch(ClassNotFoundException | IOException e){
					if(!stopped && !gameOver){
						//stop the game(not the server);
						stop();
					}
				}
			}
		}};
		t.start();
	}
	
	/**envia un mensaje
	 * @param s
	 *        el mensaje que queremos enviar*/
	public void forwardString(String s){
		try {
			for(Connection c: clients){
				c.sendObject(s);
			} 
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn){
		try {
			this.board = board;
			forwardNotification(new GameStartResponse(board, gameDesc, pieces, turn));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void onGameOver(Board board, State state, Piece winner){
		try {
			log("Game has ended. The server is now waiting to host another game.");
			forwardNotification(new GameOverResponse(board, state, winner));
			numOfConnectedPlayers = 0;
			this.clients = new ArrayList<Connection>();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop();
	}
	
	@Override
	public void onMoveStart(Board board, Piece turn){
		try {
			forwardNotification(new MoveStartResponse(board, turn));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success){
		try {
			forwardNotification(new MoveEndResponse(board, turn, success));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void onChangeTurn(Board board, Piece turn){
		try {
			forwardNotification(new ChangeTurnResponse(board, turn));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void onError(String msg) {
		try {
			forwardNotification(new ErrorResponse(msg));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**envia una respuesta
	 * @param r
	 *        la respuesta que vamos a enviar*/
	void forwardNotification(Response r) throws IOException{
		for(Connection c: clients){
			c.sendObject(r);
		}
	}
		
}