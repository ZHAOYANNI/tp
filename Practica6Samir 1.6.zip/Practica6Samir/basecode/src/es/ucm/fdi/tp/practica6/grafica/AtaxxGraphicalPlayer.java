package es.ucm.fdi.tp.practica6.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;

import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica6.ataxx.AtaxxRules;
import es.ucm.fdi.tp.practica6.grafica.BoardUI.StatusListener;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**Crea un jugador manual del juego Ataxx*/
public class AtaxxGraphicalPlayer extends BoardUI.GraphicalPlayer {

	/**Fila de la ��ltima pieza seleccionada*/
	private int lastRow = -1; 
	/**Columna de la ��ltima pieza seleccionada*/
	private int lastCol = -1; 

	/**Deseleccion una pieza*/
	public void deseleccionar(){
		lastRow = -1;
		lastCol = -1;
	}
	
	@Override
	public void clickedInCell(Board board,int row, int col, Piece turn, Piece clicked, 
			StatusListener status) {
		
				if (lastRow != -1) {
					if ((row != lastRow || col != lastCol) && clicked == null) {
						status.showDestination(row, col);
						move = new AtaxxMove(lastRow, lastCol, row, col, turn);
						lastRow = -1;
						lastCol = -1;
						
					} else {
						status.showError();
						status.selectOrigen();
					}
				} else if (lastRow == -1 && turn.equals(clicked) ) {
					
					lastRow = row;
					lastCol = col;
					status.selectDestiny(lastRow, lastCol);
				} else {
					status.showError();
					status.selectOrigen();
				}
			}

}

