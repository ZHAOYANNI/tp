
package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class BoardUI extends JPanel {
	protected JLabel[][] squares;
	protected Board board;
	protected List<Piece> pieces;
	protected Piece turno;
	private GameRules rules;
	protected Piece viewPiece;
	protected Controller c;
	protected HashMap<Piece, Color>pc;
	protected HashMap<Piece, Main.PlayerMode>pm;
	protected StatusListener statusListener;
	
	protected GraphicalPlayer graphicalPlayer;

	public abstract static class GraphicalPlayer extends Player {
		protected GameMove move = null;
		/**
		 * Handles mouse-clicks in board cells. Disabled for non-manual players
		 * @param row clicked
		 * @param col clicked
		 * @param turn of current player
		 * @param clicked piece
		 * @return string to display to user to explain what is expected
		 */
		public abstract void clickedInCell(int row, int col, Piece turn, Piece clicked);
		public boolean hasValidMove(List<? extends GameMove> moves) {
			if (move == null) return false;
			for (GameMove m : moves) {
				if (m.toString().equals(move.toString())) return true;
			}
			return false;
		}
		@Override
		public GameMove requestMove(Piece p, Board board, List<Piece> pieces,
				GameRules rules) {
			return move;
		}
		public void resetMove() {
			move = null;
		}
	}
	
	public interface StatusListener{
		public void selectOrigen();
		public void selectDestiny(int i, int j);
		public void showDestination(int i, int j);
		public void changeTurn(Piece p);
	}
	 
	public BoardUI(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm, Controller c, 
			StatusListener list, Piece viewPiece, GraphicalPlayer graphicalPlayer, GameRules rules) {
		this.pc = pc;
		this.pm = pm;
		this.c = c;
		this.rules = rules;
		this.statusListener = list;
		this.viewPiece = viewPiece;
		this.graphicalPlayer = graphicalPlayer;
	}

	public void setPieces(List<Piece> pieces) {
		this.pieces = pieces;
	}
	
	public void setTurno(Piece turno) {
		this.turno = turno;
		statusListener.changeTurn(turno);
		if (viewPiece == null || turno.equals(viewPiece)){
			statusListener.selectOrigen();
		}
		
	}
	
	public void setBoard(Board board) {
		if (board == null) throw new IllegalArgumentException();
		if (board != this.board) {
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
			for (int i = 0; i < board.getRows(); i++) {
				for (int j = 0; j < board.getCols(); j++) {
					Square s = new Square(i, j);
					s.addMouseListener(new MouseAdapter() {
						@Override
						public void mouseClicked(MouseEvent e) {
							if (viewPiece != null && !viewPiece.equals(turno)) return;
							graphicalPlayer.clickedInCell(s.getRow(), s.getCol(), turno,
									board.getPosition(s.getRow(), s.getCol()));
							if (graphicalPlayer.hasValidMove(rules.validMoves(BoardUI.this.board, pieces, turno))) {
								c.makeMove(graphicalPlayer);
							
								graphicalPlayer.resetMove();
							} else {
								return;
							}
						}
					});
					squares[i][j] = s;
					paintSquare(board.getPosition(i, j), i, j);
					add(s);
				}
			}
			update(this.pc, this.pm);
		} else {
			update(this.pc, this.pm);
		}
		if(turno == null)
			setTurno(pieces.get(0));
	}

	public void update(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm) {
																				
		this.pc = pc;
		this.pm = pm;
		
		for (int i = 0; i < board.getRows(); i++) {
			for (int j = 0; j < board.getCols(); j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
		
	}

	// Pinta un cuadrado.
	// Queda actualizarla para que acepte pintar listas de distintos tamaño
	public void paintSquare(Piece p, int i, int j) {

		Piece obs = new Piece("*");

		if(p!=null && !p.equals(obs)){
			squares[i][j].setBackground(pc.get(p));
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else {
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		squares[i][j].setOpaque(true);
	}
}