package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

public class PlayerMode extends JPanel{

	private Piece p;
	private Main.PlayerMode m;

	
	public void setTitulo(){
		setBorder(new TitledBorder(null, "Player Modes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
	}
	
	public void initComponent(List<Piece> pieces, SettingListener list, boolean hasRandom, 
			boolean hasAi){
		Vector<Piece> v = new Vector();
		for(int i =0; i < pieces.size();i++){
			v.add(pieces.get(i));
		}
		
		JComboBox<Piece> Piece = new JComboBox();
		Piece.setModel(new DefaultComboBoxModel(v));
		add(Piece);
		Piece.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	 	p = (Piece)Piece.getSelectedItem();
		     }
		   	});
		Vector<Main.PlayerMode> x = new Vector();
		x.add(Main.PlayerMode.MANUAL);
		if(hasRandom)
			x.add(Main.PlayerMode.RANDOM);
		if(hasAi)
			x.add(Main.PlayerMode.AI);
		JComboBox<Main.PlayerMode> Modo = new JComboBox();
		Modo.setModel(new DefaultComboBoxModel(x));
		add(Modo);
		Modo.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		    	  m = (Main.PlayerMode)Modo.getSelectedItem();
		     }
		   	});
		
		JButton btnSet = new JButton("Set");
		add(btnSet);
		btnSet.addActionListener(new ActionListener() {
		     @Override
		 		public void actionPerformed(ActionEvent e) {
		       	 	list.PlayerModeChange(p, m);
		    	}
		   	});
	}
}
