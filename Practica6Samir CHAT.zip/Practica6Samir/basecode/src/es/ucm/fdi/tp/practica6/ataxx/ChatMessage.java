package es.ucm.fdi.tp.practica6.ataxx;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class ChatMessage implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String text;
	private Piece p;
	
	public ChatMessage(String text, Piece p){
		this.text = text;
		this.p = p;
	}
	
	public String getText(){
		return this.text;
	}
	
	public Piece getPiece(){
		return this.p;
	}

}
