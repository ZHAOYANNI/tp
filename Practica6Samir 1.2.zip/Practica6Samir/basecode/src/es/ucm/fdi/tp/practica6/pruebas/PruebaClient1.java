package es.ucm.fdi.tp.practica6.pruebas;

import es.ucm.fdi.tp.practica6.grafica.Main;

public class PruebaClient1 {
	
	public static void main(String[] args) {
		String[] as = { "-am", "client", "-aialg", "minmax", "-md","5" };
		Main.main(as);
	}
}
