package es.ucm.fdi.tp.practica6.ataxx;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import es.ucm.fdi.tp.basecode.bgame.control.ConsolePlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.AIAlgorithm;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.views.GenericConsoleView;
import es.ucm.fdi.tp.practica6.grafica.GameWindow;

/**
 * Factoria para la creacion de juegos Ataxx. Vease {@link AtaxxRules} para la
 * descripcion del juego.
 */

public class AtaxxFactoryExt implements GameFactory {
	private static final long serialVersionUID = 1L;
	private int dim;
	private int numObst;
	private List<Piece> pieces;

	public AtaxxFactoryExt() {
		this(7, 1, new ArrayList());
	}

	public AtaxxFactoryExt(int dim, int obst, List<Piece> pieces) {
		if (dim < 5) {
			throw new GameError("Dimension debe ser al menos 5: " + dim);
		} else {
			if (dim % 2 == 1) {
				this.dim = dim;
			} else {
				throw new GameError("Dimension debe ser numero impar: " + dim);
			}
		}
		numObst = obst;
		this.pieces = pieces;

	}

	@Override
	public GameRules gameRules() {
		return new AtaxxRules(dim, numObst);
	}

	@Override
	public Player createConsolePlayer() {
		ArrayList<GameMove> possibleMoves = new ArrayList<GameMove>();
		possibleMoves.add(new AtaxxMove());
		return new ConsolePlayer(new Scanner(System.in), possibleMoves);
	}

	@Override
	public Player createRandomPlayer() {
		return new AtaxxRandomPlayer();
	}

	@Override
	public Player createAIPlayer(AIAlgorithm alg) {
		return new DummyAIPlayer(createRandomPlayer(), 1000);
	}

	/**
	 * Por defecto, hay dos jugadores, X y O.
	 */
	@Override
	public List<Piece> createDefaultPieces() {
		List<Piece> pieces = new ArrayList<Piece>();
		pieces.add(new Piece("X"));
		pieces.add(new Piece("O"));

		return pieces;
	}

	@Override
	public void createConsoleView(Observable<GameObserver> g, Controller c) {
		new GenericConsoleView(g, c);
	}

	@Override
	public void createSwingView(final Observable<GameObserver> g, final Controller c, final Piece viewPiece,
			Player random, Player ai) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				//JFrame jf = new JFrame();
				
				String gameDesc = new String("Ataxx " + dim + "x" + dim);
				if(viewPiece != null){
					gameDesc += " (" + viewPiece + ")";
				}
				boolean hasRandom = false;
				boolean hasAI = false;
				if(random != null)
					hasRandom = true;
				if(ai != null)
					hasAI = true;
				GameWindow window = null; //new GameWindow(c, viewPiece, pieces, dim, numObst, hasRandom, hasAI, gameDesc);
				window.setTitle(gameDesc);
				window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				//Windows window = new Windows(c, viewPiece, pieces, dim, numObst, true, true, gameDesc);
				window.setSize(600, 400);
				window.setVisible(true);
				//La raz楂� por la que no le paso a Windows el tablero por aqu锟� es porque no podemos cambiar los argumentos
				//de createSwingView. Por lo dem閱� esta funci楂� no requiere explicaci楂�. Lo siento por traerte aqu锟�, lol.
			}
		});
	}
}