
package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**
 * es una clase abstracta, clase padre de los boards de cada juego
 * */
public abstract class BoardUI extends JPanel implements MouseListener {
	protected JLabel[][] squares;
	protected Board board;
	protected List<Piece> pieces;
	protected Piece turno;
	protected StatusPanel status; // Panel de texto del estado de la partida
	private GameMove movimiento;
	private GameRules rules;
	protected Controller2 c;
	protected HashMap<Piece, Color>pc;
	protected HashMap<Piece, Main.PlayerMode>pm;
	protected StatusListener list;

	/**
	 * Interfaz de listener
	 * */
	public interface StatusListener{
		/**
		 * pide al jugador elige una pieza de orige
		 * */
		public void selectOrigen();
		/**
		 * pide al jugadore elige una posición como destino
		 * */
		public void selectDestiny();
		/**
		 * informa el turno de jugador
		 * @param p
		 *       el siguiente jugador a jugar
		 **/
		public void changeTurn(Piece p);
	}
	 
	/**
	 * Constructor
	 * */
	public BoardUI(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm, Controller2 c, 
			StatusListener list) {
		pieces = new ArrayList();
		this.pc = pc;
		this.pm = pm;
		this.c = c;
		this.list = list;
		turno = null;
	}
	
	/**
	 * Inicializa rules
	 * @param dim  
	 *          la dimension del tablero
	 * @param numObs
	 *          el número de obstáculos
	 **/
	public abstract void setRules(int dim, int numObs);

	/**
	 * devuelve rules
	 * */
	public abstract GameRules getRules();

	/**Inicializa la lista de piezas
	 * @param pieces
	 *           lista de piezas que llega al tablero
	 **/
	public void setPieces(List<Piece> pieces) {
		this.pieces = pieces;
	}
	
	/**
	 * devuelve el HashMap donde la clave es pieza y el valor es un color
	 * */
	public HashMap<Piece, Color> getPC(){
		return this.pc;
	}

	/**
	 * devuelve el HashMap donde la clave es pieza y el valor es el modo de jugador
	*/
	public HashMap<Piece, Main.PlayerMode> getPM(){
		return this.pm;
	}
	
	/**
	 * cambia el turno
	 * @param turno
	 *          la pieza que va a jugar
	 **/
	public void setTurno(Piece turno) {
		this.turno = turno;
		list.changeTurn(turno);
		list.selectOrigen();
	}

	/**
	 * inicializa el panel de estado
	 * @param status
	 *           es el panel de estado
	 **/
	public void setStatusPanel(StatusPanel status) {
		this.status = status;
	}

	/**
	 * Inicializa un controlador
	 * @param c
	 *        es el controlador que creamos para jugar el juego
	 **/
	public void setController(Controller2 c) {
		this.c = c;
	}

	/**
	 * Inicializa el tablero
	 * @param board
	 *          si el board no ha cambiado, actualizamos, en otro caso, copiamos el board
	 **/
	public void setBoard(Board board) {

		if (board != this.board) {
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
			for (int i = 0; i < board.getRows(); i++) {
				for (int j = 0; j < board.getCols(); j++) {
					squares[i][j] = new Square(i, j);
					squares[i][j].addMouseListener(this);
					paintSquare(board.getPosition(i, j), i, j);
					add(squares[i][j]);
				}
			}
		} else {
			update(this.pc, this.pm);
		}
		if(turno == null)
			setTurno(pieces.get(0));
	}

	/**
	 * Actualizamos el tablero
	 * @param pc
	 *         HashMap donde la clave es pieza y el valor es un color
	 * @param pm
	 *         HashMap donde la clave es pieza y el valor es el modo de juego del jugador
	 * */
	public void update(HashMap<Piece, Color>pc, HashMap<Piece, Main.PlayerMode>pm) {
																				
		this.pc = pc;
		this.pm = pm;
		
		for (int i = 0; i < board.getRows(); i++) {
			for (int j = 0; j < board.getCols(); j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}

	/**
	 * Pinta un cuadrado para representar una pieza
	 * */
	public void paintSquare(Piece p, int i, int j) {

		Piece obs = new Piece("*");

		if(p!=null && !p.equals(obs)){
			squares[i][j].setBackground(pc.get(p));
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else {
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		squares[i][j].setOpaque(true);
	}
	
	/**
	 * A esta función la llamamos cuando movemos una pieza del tablero nosotros
	 * Sólo viene aquí si el movimiento es válido.
	 * @param row
	 *          número de la fila de la casilla a la cual va a llegar una pieza
	 * @param col
	 *          número de la columna de la casilla a la cual va a llegar una pieza  
	 **/
	public abstract void cosasDeMover(int row, int col);

	/**
	 * Nos informa que el juego está terminado
	 * */
	public abstract boolean gameIsDone();

	/**
	 * Genera un movimiento aleatorio
	 * */
	public abstract void movimientoAleatorio();
	
	/**
	 * Genera un movimiento inteligente
	 * */
	public abstract void movimientoAi();
	
	@Override
	public abstract void mouseClicked(MouseEvent e);

	@Override
	public abstract void mouseEntered(MouseEvent e);

	@Override
	public abstract void mouseExited(MouseEvent e);

	@Override
	public abstract void mousePressed(MouseEvent e);

	@Override
	public abstract void mouseReleased(MouseEvent e);

}