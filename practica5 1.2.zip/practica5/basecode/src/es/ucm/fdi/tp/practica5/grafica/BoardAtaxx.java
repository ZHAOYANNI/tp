package es.ucm.fdi.tp.practica5.grafica;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.practica4.ataxx.AtaxxMove;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public class BoardAtaxx extends BoardUI{

	private JLabel[][] squares;
	private Board board;
	private List<Piece> pieces;
	private Piece turno;
	private int lastRow; //Guarda ��ltima fila clicada
	private int lastCol; //Guarda ��ltima columna clicada
	private StatusPanel status; //Panel de texto del estado de la partida
	private AtaxxMove movimiento;
	private AtaxxRules rules;
	
	//LastRow y lastCol van a estar a -1 si no hay ninguna ficha seleccionada.
	//Si hay alguna seleccionada tendr��a los valores de esta.
	//Lo mismo para lastPiece;
	
	public BoardAtaxx(){
		super();
		lastRow = -1;
		lastCol = -1;
	}
	
	public void setRules(int dim, int numObs){
		AtaxxRules rules = new AtaxxRules(dim, numObs);
		this.rules = rules;
	}
	
	public AtaxxRules getRules(){
		return rules;
	}
	
	public void setPieces(List<Piece> pieces){
		this.pieces = pieces;
	}

	public void setTurno(Piece turno){
		this.turno = turno;
	}
	
	public void setStatusPanel(StatusPanel status){
		this.status = status;
	}
	
	public void setBoard(Board board){
		
		if(board != this.board){
			removeAll(); // descartamos squares antiguos
			this.board = board;
			squares = new JLabel[board.getRows()][board.getCols()];
			setLayout(new GridLayout(board.getRows(), board.getCols(), 5, 5));
				for (int i=0; i<board.getRows(); i++) {
					for (int j=0; j<board.getCols(); j++) {
						squares[i][j] = new Square(i,j);
						squares[i][j].addMouseListener(this);
						paintSquare(board.getPosition(i, j), i, j);
						add(squares[i][j]);
					}
				}
		} else{
			update();
		}
		setTurno(pieces.get(0));
	}

	public void setColors(PieceColorMap colorMap){};
	
	public void update(){//Queda ver en qu?momentos se llama a esto dentro del programa.
		for (int i=0; i<board.getRows();i++) {
			for (int j=0; j<board.getCols();j++) {
				Piece p = board.getPosition(i, j);
				paintSquare(p, i, j);
			}
		}
		repaint();
	}
	
	//Pinta un cuadrado.
	//Queda actualizarla para que acepte pintar listas de distintos tama�os
	public void paintSquare(Piece p, int i, int j){

		Piece obs = new Piece("*");
		
		if(pieces.get(0).equals(p)){
			squares[i][j].setBackground(Color.RED);
		} else if(pieces.get(1).equals(p)){
			squares[i][j].setBackground(Color.BLUE);
		} else if(obs.equals(p)){
			squares[i][j].setBackground(Color.BLACK);
		} else if(p == null) {//Si es una casilla vac��a
			squares[i][j].setBackground(Color.LIGHT_GRAY);
		}
		
		if(pieces.size() == 3){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			}
		} else if(pieces.size() == 4){
			if(pieces.get(2).equals(p)){
				squares[i][j].setBackground(Color.YELLOW);
			} else if(pieces.get(3).equals(p)){
				squares[i][j].setBackground(Color.GREEN);
			}
		}
		
		squares[i][j].setOpaque(true);
		
	}
	
	private int abs(int num){
		if(num >= 0){
			return num;
		}
		return -num;
	}
	
	public void cosasDeMover(int row, int col){//Voy a necesitar saber a d�nde me muevo (s?de d�nde vengo por lastRow, lastCol)
			Piece p = board.getPosition(lastRow, lastCol);
			movimiento = new AtaxxMove(lastRow, lastCol, row, col, p);
			movimiento.execute(board, pieces);
			
			update();
	}
	
	//��sta es la funci��n que va a convertir las piezas adyacentes a la que est?en (row, col)
	
	public void turnoSiguiente() {
		Piece p = rules.nextPlayer(board, pieces, turno);
		turno = p;
		
		status.append("Es el turno de " + p + System.getProperty("line.separator"));
		status.append("Seleccione la casilla de origen." + System.getProperty("line.separator"));
	}
	
	public boolean gameIsDone(){
		return(rules.soloQuedaUno(board, pieces) || rules.nadieMovible(board, pieces));
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		Piece obs = new Piece("*");
		Square square = (Square)e.getSource();

		//Si es una lastRos/lastCol de verdad
		if(lastRow != -1){
			
			//Si la pieza que se mueve no es obs/null.
			//Si la casilla a la que movemos no es de la que venimos
			//Si la casilla a la que vamos est?vac�a
			//Si la casilla a la que vamos est� "cerca"
			if(pieces.contains(board.getPosition(lastRow, lastCol)) && (square.getRow() != lastRow || square.getCol() != lastCol)
					&& board.getPosition(square.getRow(), square.getCol()) == null
					&& abs(lastRow-square.getRow()) <= 2 && abs(lastCol-square.getCol()) <= 2){
				
				status.append("Has seleccionado la casilla (" + square.getRow() + ", " + square.getCol() 
				+ ") como casilla de destino." + System.getProperty("line.separator"));
				
				cosasDeMover(square.getRow(), square.getCol());
				if(!gameIsDone()){
					turnoSiguiente();
				} else {
					String wonnered;
					if(rules.quienGana(board, pieces) == null){
						wonnered = "Ha habido un empate.";
					} else {
						wonnered = rules.quienGana(board, pieces) + " wonnered";
					}
					
					onError(wonnered);
				}
			
			} else {
				onError("Movimiento no permitido.");
			}
			
			lastRow = -1;
			lastCol = -1;
			
			//Si no tenemos ninguna seleccionada y seleccionamos una ficha de que es su turno
		} else if(lastRow == -1 && pieces.contains(board.getPosition(square.getRow(), square.getCol()))
				&& board.getPosition(square.getRow(), square.getCol()).equals(turno)){
			//turnoSiguiente();
			
			lastRow = square.getRow();
			lastCol = square.getCol();
			status.append("Has seleccionado la casilla (" + lastRow + ", " + lastCol + ") como casilla de origen." 
					+ System.getProperty("line.separator"));
			status.append("Seleccione su casilla de destino." + System.getProperty("line.separator"));
		} else {
			onError("Seleccione una casilla de origen v�lida." + System.getProperty("line.separator"));
		}
			
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveStart(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onChangeTurn(Board board, Piece turn) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}
	

}

/*
 *
 * Toca hacer m�s claro qu� est� seleccionado y hacer m�s intuitivo el proceso de selecci�n/deselecci�n
 * 
 * 
 * Los parsers ir�n en el main y tal. Me toca crear en windows una funci�n que cree un tablero en fuci�n de 
 * los datos acerca de �l (dimensi�n, num Piezas, nombre Piezas, obst�culos) y luego meterlo en el setter de BoardUI
 * 
 * LO �LTIMO QUE HE ESTADO HACIENDO HA SIDO IR PONIENDO COSAS EN MAIN PARA VER SI LOS TABLEROS VAN BIEN CUANDO SE 
 * LOS PASAS YA HECHOS (PARA CUANDO YA TENGAMOS ARGS Y TODA LA PESCA)
 * 
 * PARA LAS COSAS DE BoardUI EN VEZ DE COPIAR/PEGAR LAS FUNCIONES DE ATAXX TENGO QUE LLAMARLAS
 * 
 * Hacer un settings listeners que informe cuando pasan cosas as� en general. (cambio turno, etc)
 * 
 * Pasar a BoardUI el GameObserver de Windows en vez de crear uno nuevo.
 * 
 * CUANDO ACTUA WINDOWS TIENEN QUE ACTUAL PANEL DERECHA Y BOARD (POR EJEMPLO CUANDO CAMBIAMOS EL COLOR DE UNA FICHA)
 * 
 * Voy a hacer el muy necesario cambio de que BoardUI pase a ser BoardAtaxx y viceversa
 */
