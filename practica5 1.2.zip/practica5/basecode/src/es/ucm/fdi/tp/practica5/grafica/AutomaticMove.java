package es.ucm.fdi.tp.practica5.grafica;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

public class AutomaticMove extends JPanel {

	public AutomaticMove(){
		
	}
	
	public void setTit(){
		setBorder(new TitledBorder(null, "Automatic Moves", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	}
	
	public void setBoton(HashMap<Piece, Main.PlayerMode> pm, Piece turn, SettingListener list){
		Main.PlayerMode m = pm.get(turn);
		JButton AI = new JButton("Intelligent");
		setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnRandom = new JButton("Random");
		
		
		if(m != Main.PlayerMode.MANUAL){
			AI.setEnabled(false);
			btnRandom.setEnabled(false);
		}else {
			AI.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					list.AIMoveChoose(turn);
				}
			});
				btnRandom.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						list.RandomMoveChoose(turn);
					}
				});
		}
		
			add(btnRandom);
			add(AI);
	}
}
