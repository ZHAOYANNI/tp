package es.ucm.fdi.tp.practica5.grafica;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import es.ucm.fdi.tp.basecode.bgame.model.Piece;

import java.util.List;
import java.util.Vector;

public class PlayerInfor extends JPanel{

	public PlayerInfor(List<Piece> pieces ){
		setBorder(new TitledBorder(null, "Player Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		setLayout(new BorderLayout());
		JTable table= new JTable();
		

		/*Vector<Piece> vector1 = new Vector();
		for(int i = 0; i < pieces.size();i++){
			vector1.add(pieces.get(i));
		}
		Vector<Piece> vector2 = new Vector();
		for(int i = 0; i < pieces.size();i++){
			vector2.add(pieces.get(i));
		}
		
		
		Vector<Piece> vector3 = new Vector();*/
		
		AbstractTableModel tabla = new AbstractTableModel(){
			@Override
			public int getRowCount() {
				// TODO Auto-generated method stub
				return pieces.size();
			}

			@Override
			public int getColumnCount() {
				// TODO Auto-generated method stub
				return 3;
			}

			@Override
			public Object getValueAt(int rowIndex, int columnIndex) {
				// TODO Auto-generated method stub
				return null;
			}
			
		};
		/*
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		};
		tableAux.addColumn("Player",vector1);
		tableAux.addColumn("Mode", vector1);
		tableAux.addColumn("#Piece", vector1);*/
		table.setModel(tabla);
		add( new JScrollPane(table));
	}
}
