package es.ucm.fdi.tp.practica5.grafica;

import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.Utils;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.*;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRandomPlayer;
import es.ucm.fdi.tp.practica5.ataxx.AtaxxRules;

public class AiPlayer extends Player implements AIAlgorithm{

	public AiPlayer(){
		new DummyAIPlayer(new AtaxxRandomPlayer(), 1000);
	}
	@Override
	public GameMove requestMove(Piece p, Board board, List<Piece> pieces,
			GameRules rules) {
		if (board.isFull() || !movible(board,p)) {
			throw new GameError("El tablero est�� lleno o no hay pieza movible ");
		}else
			getMove(p, board, pieces, rules);
		return null;
	}
	
	@Override
	public GameMove getMove(Piece p, Board board, List<Piece> pieces, GameRules rules){
		int max = 0;
		List<GameMove> moves = rules.validMoves(board, pieces, p);
		return moves.get(max);
	}
	
	public boolean movible(Board board, Piece p){
			
			for(int i = 0; i < board.getRows(); i++){
				for(int j = 0; j < board.getCols(); j++){
					if( p.equals(board.getPosition(i, j))){
						if(piezaMovible(board, i, j)){
							return true;
						}
					}
				}
			}
			return false;
		}
	
	public boolean piezaMovible(Board board, int row, int col){
		
		for(int i = -2; i < 3; i++){
			for(int j = -2; j < 3; j++){
				if(row+i>=0 && col+j>=0 && row+i<board.getRows() && col+j<board.getCols() 
						&& board.getPosition(row + i, col+j) == null)
					return true;
			}
		}
		return false;
	}
}
