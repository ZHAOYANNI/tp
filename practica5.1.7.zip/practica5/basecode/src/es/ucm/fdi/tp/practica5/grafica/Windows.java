package es.ucm.fdi.tp.practica5.grafica;

import javax.swing.*;
import javax.swing.plaf.PanelUI;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.grafica.Main.PlayerMode;
import es.ucm.fdi.tp.practica5.grafica.PanelDer.SettingListener;

import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Windows extends JPanel implements PanelDer.SettingListener, BoardUI.StatusListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4192014945426749947L;
	protected BoardUI ui;
	protected PanelDer der;
	private StatusPanel status;
	private PlayerInfor playerInfor;
	private List<Piece> pieces;
	private HashMap<Piece, Color> pc;
	private HashMap<Piece, Main.PlayerMode> pm;
	private Board boardPlz;
	private boolean terminado; 
	private Controller2 c;
	private int dim;
	private int numObs;
	private boolean hasRandom;
	private boolean hasAi;
	private Piece viewPiece;
	private String gameDesc;
	
	public Windows(Controller c, Piece viewPiece, List<Piece> pieces, int dim, int numObs,
			boolean hasRandom, boolean hasAi, String gameDesc) {
		pc = new HashMap();
		pm = new HashMap();
		terminado = false;
		this.dim = dim;
		this.numObs = numObs;
		this.hasRandom = hasRandom;
		this.hasAi = hasAi;
		this.viewPiece = viewPiece;
		this.gameDesc = gameDesc;
		for (int i = 0; i < pieces.size(); i++) {
			pc.put(pieces.get(i), new Color((int)(Math.random() * 0x1000000)));
		}
		for (int i = 0; i < pieces.size(); i++) {
			pm.put(pieces.get(i), Main.PlayerMode.MANUAL);
		}
		
		boardPlz = ((Controller2)c).getBoard();//Este es el tablero que cojo de Controller2 y que es el bueno.

		ui = new BoardAtaxx(pc, pm, (Controller2) c, this, terminado);
		this.pieces = pieces;
		ui.setRules(dim, numObs);
		ui.setPieces(pieces);
		Board board = ui.getRules().createBoard(pieces); //Este es el tablero que no usamos pero que 
														//La ventana est� en blanco si no creamos.
		
		
		playerInfor = new PlayerInfor(pieces, pm, pc, boardPlz);
		status = new StatusPanel();
		gameStart(gameDesc);
		der = new PanelDer(this, pc, pm, hasRandom, hasAi);
		ui.setStatusPanel(status);
		ui.setBoard(boardPlz);
		setLayout(new BorderLayout());
		add(ui, BorderLayout.CENTER);
		der.setLayout(new BoxLayout(der, BoxLayout.Y_AXIS));
		der.add(status);
		der.add(playerInfor);
		der.initComponents((Controller2)c, viewPiece, pieces, this, pieces.get(0));
		add(der, BorderLayout.EAST);



		//((Controller2) c).onGameStart(board, " ", pieces, pieces.get(0));
	}

	/*public void cosasDeMover(Piece turn) {
		status.append("Turno de " + turn + System.getProperty("line.separator"));
		ui.setTurno(turn);
	}*/

	/*
	 * public BoardUI getUI(){ return ui; }
	 */

	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		status.append("bienvenido a " + gameDesc + System.getProperty("line.separator"));
	}

	public void onGameOver(Board board, State state, Piece winner) {
		if (state == Game.State.Won) {
			status.append( winner + " is the winner ! ");
		} else if (state == Game.State.Draw) {
			status.append("empate");
		} else if (state == Game.State.Stopped) {
			status.append("ha sido interrupido el juego");
		}
		terminado = true;
	}

	/*public void onMoveStart(Board board, Piece turn) {
		ui.update(pc, pm);
		status.append("" + System.getProperty("line.separator"));
	}

	public void onMoveEnd(Board board, Piece turn, boolean success) {
		ui.update(pc, pm);
		status.append("" + System.getProperty("line.separator"));
	}

	public void onChangeTurn(Board board, Piece turn) {
		ui.update(pc, pm);
		status.append("turno de" + turn + System.getProperty("line.separator"));

	}

	public void onError(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
	}*/

	public void ColorChangeChoose(Piece p, Color c) {
		this.pc.put(p, c);
		actualiza(p);
	}

	public void PlayerModeChange(Piece p, PlayerMode m) {
		if(p != null){
			if(m == Main.PlayerMode.RANDOM){
				this.pm.put(p, Main.PlayerMode.RANDOM);
			
	   	 	}else if(m == Main.PlayerMode.AI){
	   	 		this.pm.put(p, Main.PlayerMode.AI);
	   	 	}else
	   	 		this.pm.put(p, Main.PlayerMode.MANUAL);
		}else{
			if(m == Main.PlayerMode.RANDOM){
				this.pm.put(pieces.get(0), Main.PlayerMode.RANDOM);
	   	 	}else if(m == Main.PlayerMode.AI){
	   	 		this.pm.put(pieces.get(0), Main.PlayerMode.AI);
	   	 	}else
	   	 		this.pm.put(pieces.get(0), Main.PlayerMode.MANUAL);
		}
		actualiza(p);
		
	}

	public void AIMoveChoose(Piece p) {
		// TODO Auto-generated method stub

	}

	public void RandomMoveChoose(Piece p) {

	}

	public void actualiza(Piece turn) {
			der.actualiza(pm, turn);
			playerInfor.actualiza();
			ui.update(pc, pm, terminado);
	}

	public void gameStart(String gameDesc){
		status.append("bienvenido a " + gameDesc);
	}
	
	@Override
	public void changeTurn(Piece p) {
		if(p != null)
			status.append("turn of " + p);
	}

	@Override
	public void selectOrigen() {
		status.append("Click on an origin piece.");
	}
	@Override
	public void selectDestiny() {
		status.append("Click on the destination position. ");
	}
	
	public void reset(){

		terminado = false;
		for (int i = 0; i < pieces.size(); i++) {
			pc.put(pieces.get(i), new Color((int)(Math.random() * 0x1000000)));
		}
		for (int i = 0; i < pieces.size(); i++) {
			pm.put(pieces.get(i), Main.PlayerMode.MANUAL);
		}
        gameStart(gameDesc);
        Board board = ui.getRules().createBoard(pieces);
        der.actualiza(pm, pieces.get(0));
		playerInfor.actualiza();
	}
}
