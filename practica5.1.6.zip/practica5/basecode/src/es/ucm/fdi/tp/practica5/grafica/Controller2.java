package es.ucm.fdi.tp.practica5.grafica;

import java.util.List;

import javax.swing.JOptionPane;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class Controller2 extends Controller implements GameObserver {

	protected Windows[] windows;// Array de ventanas (para multiview) En single
								// view usaremos s髄o el primero
	protected Piece turn; // A quien le toca
	protected boolean multiview = false; // Probablemente lo haga m醩 elegante
											// luego
	private int contador; //Cantidad de ventanas que tenemos (servir� principalmente en multiview)
	private int currentWindowIndex; //蚽dice en el array de ventanas de la ventana que nos interesa en el momento
	private Board board;

	public Controller2(Game game, List<Piece> pieces, Windows[] windows) {
		super(game, pieces);
		this.windows = windows;
		contador = 0;
	}
	
	public void addWindow(Windows window){
		windows[contador] = window;
		contador++;
	}
	
	public Board getBoard(){
		return board;
	}

	public void makeMove(Player player, Piece turn) {
		if (game != null && player != null) {
			game.makeMove(player); // Tendr� que cambiar este m閠odo para que le
									// diga que le toca a la ventana adecuada
									// La ventana adecuada ser� la que se
									// corresponda con turno (en caso de
									// multiview)
		}
		
	}

	public void start() {
		if (game != null) {
			game.start(pieces);
		}
	}

	public void stop() {
		if (game != null) {
			game.stop();
		}
	}

	public void restart() {
		if (game != null) {
			for(int i = 0; i < contador; i++){
				windows[i].reset();
			}
		}
		
	}

	// Cuando Game nos dice que va a empezar la partida seteamos el turno y el tablero.
	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		this.turn = turn;
		this.board = board;
		System.out.println("onGameStart " + turn);//Vas a ver cosas como estas. Las tengo para ver cu醤do/d髇de fallan las 
												//cosas porque antes me estaban dando muchos problemas los turnos.
	}

	@Override
	public void onGameOver(Board board, State state, Piece winner) {
		windows[0].onGameOver(board, state, winner);
	}


	@Override
	public void onMoveStart(Board board, Piece turn) {
		if (!multiview) {
			currentWindowIndex = 0; //este Index nos dice la ventana que nos importa ahora mismo (es la del turno al que le toca)
		} else { // A partir de la posici髇 de turn en pieces tengo que elegir
					// la ventana a la que le toca
			currentWindowIndex = pieces.indexOf(turn); //La ventana que nos interesa est� en el array de ventanas
													   //En la misma pos que la pieca en la lista de piezas
		}
		System.out.println("onMoveStart " + turn);
	}

	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		//No estoy muy seguro qu� hacer aqu�. A lo mejor habr韆 que actualizar, pero no creo porque eso queda muy bien
		//en la funci髇 que llama al propio movimiento porque sabe mejor cuando acaba del todo el turno.
		System.out.println("onMovEnd " + turn);
	}

	// Lo que vamos a hacer cuando se cambie el turno
	@Override
	public void onChangeTurn(Board board, Piece turn) {
		this.turn = turn; // turn pasa a ser la pieza siguiente.
		for(int i = 0; i < contador; i++){ //No s� por qu� he hecho esto. No creo que sirva para nada.
											//Estoy muy cansado para comprobar si sirve o no as� que por ahora no lo borro.
			windows[currentWindowIndex].ui.setTurno(turn);
		}
		System.out.println("onChangeTurn " + turn);
	}

	@Override
	public void onError(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
	}

}

/*
 * 
 */
